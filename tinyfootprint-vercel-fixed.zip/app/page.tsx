'use client';

import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { Leaf, Plus, Minus, Trash2, Upload, X, ChevronLeft, Check, AlertCircle, MapPin, ExternalLink, Settings } from "lucide-react";
// Auto-generated product seed data from Tinyfootprint_Price_List_2026.pdf
// Isopod/Springtail items with multiple pack tiers are modeled as one product
// with a `packs` array; everything else is a flat single-price product.

const SEED_PRODUCTS = [
  // ===== ISOPODS (pack-tiered) =====
  { id: "iso-little-sea", name: "Cubaris murina (Little Sea)", category: "Isopod", unit: "pcs", image: "",
    desc: "A calm blue-grey isopod, easygoing and great for beginner bioactive setups.",
    care: { temperature: "22–28 °C", humidity: "70–80 %", substrate: "Coco fibre + leaf litter", food: "Leaf litter, decaying wood, calcium supplement", notes: "Tolerates a range of conditions; hardy and prolific. Keep one side of enclosure moist, one dry." },
    packs: [{ label: "1 pc", qty: 1, price: 2 }, { label: "5 +1 free", qty: 6, price: 9 }, { label: "10 +2 free", qty: 12, price: 17 }] },
  { id: "iso-powder-blue", name: "Porcellionides pruinosus (Powder Blue)", category: "Isopod", unit: "pcs", image: "",
    desc: "Soft powder-blue dusting over a hardy, prolific cleanup crew.",
    care: { temperature: "20–28 °C", humidity: "60–75 %", substrate: "Coco fibre + sphagnum moss", food: "Leaf litter, vegetables, fish flakes, calcium", notes: "Very fast breeder. Great starter species. Provide both moist and dry zones." },
    packs: [{ label: "1 pc", qty: 1, price: 2 }, { label: "5 +1 free", qty: 6, price: 10 }, { label: "10 +2 free", qty: 12, price: 20 }] },
  { id: "iso-papaya", name: "Cubaris sp. (Papaya)", category: "Isopod", unit: "pcs", image: "",
    desc: "Warm orange tones reminiscent of ripe papaya, active and easy to keep.",
    care: { temperature: "24–28 °C", humidity: "75–85 %", substrate: "Coco fibre + sphagnum + leaf litter", food: "Leaf litter, fruit, calcium supplement", notes: "Tropical species — keep warm and humid. Avoid temperature drops below 20 °C." },
    packs: [{ label: "1 pc", qty: 1, price: 4 }, { label: "5 +1 free", qty: 6, price: 20 }, { label: "10 +2 free", qty: 12, price: 37 }] },
  { id: "iso-jupiter", name: "Cubaris sp. (Jupiter)", category: "Isopod", unit: "pcs", image: "",
    desc: "Bold swirling patterning named for the planet's storm bands — a collector favorite.",
    care: { temperature: "24–28 °C", humidity: "75–85 %", substrate: "Coco fibre + sphagnum + leaf litter", food: "Leaf litter, decaying wood, calcium", notes: "Slower breeder than common species. Keep consistently warm and humid for best results." },
    packs: [{ label: "1 pc", qty: 1, price: 10 }, { label: "5 +1 free", qty: 6, price: 50 }, { label: "10 +2 free", qty: 12, price: 100 }] },
  { id: "iso-officinalis", name: "Armadillidium officinalis", category: "Isopod", unit: "pcs", image: "",
    desc: "A robust pillbug species with attractive mottled coloration.",
    care: { temperature: "20–26 °C", humidity: "55–70 %", substrate: "Coco fibre + calcium-rich substrate", food: "Leaf litter, vegetables, cuttlefish bone", notes: "Pillbug species — rolls into a ball when disturbed. Needs adequate calcium for exoskeleton moulting." },
    packs: [{ label: "1 pc", qty: 1, price: 6 }, { label: "5 +1 free", qty: 6, price: 30 }, { label: "10 +2 free", qty: 12, price: 60 }] },
  { id: "iso-cappucino", name: "Porcellio scaber (Cappuccino)", category: "Isopod", unit: "pcs", image: "",
    desc: "Rich coffee-and-cream coloring, a sought-after premium morph.",
    care: { temperature: "18–26 °C", humidity: "60–75 %", substrate: "Coco fibre + leaf litter + bark", food: "Leaf litter, bark, decaying wood, calcium", notes: "Robust and adaptable. Needs hiding spots and good ventilation. One of the hardiest isopod species." },
    packs: [{ label: "1 pc", qty: 1, price: 15 }, { label: "5 +1 free", qty: 6, price: 60 }, { label: "10 +2 free", qty: 12, price: 120 }] },
  { id: "iso-gestroi", name: "Porcellio gestroi (Gestroi)", category: "Isopod", unit: "pcs", image: "",
    desc: "Large, hardy, and a great waste-processor for bigger enclosures.",
    care: { temperature: "22–28 °C", humidity: "65–80 %", substrate: "Coco fibre + bark + leaf litter", food: "Leaf litter, decaying wood, vegetables, calcium", notes: "One of the larger Porcellio species. Very effective clean-up crew for bigger vivariums." },
    packs: [{ label: "1 pc", qty: 1, price: 6 }, { label: "5 +1 free", qty: 6, price: 30 }, { label: "10 +2 free", qty: 12, price: 60 }] },
  { id: "iso-magic-potion", name: "Cubaris sp. (Magic Potion)", category: "Isopod", unit: "pcs", image: "",
    desc: "A striking purple-blue morph that looks dipped in something magical.",
    care: { temperature: "24–28 °C", humidity: "75–85 %", substrate: "Coco fibre + sphagnum + leaf litter", food: "Leaf litter, calcium supplement, occasional fruit", notes: "Tropical Cubaris — keep humid and warm. Avoid cold drafts. Mist one side daily." },
    packs: [{ label: "1 pc", qty: 1, price: 6 }, { label: "5 +1 free", qty: 6, price: 30 }, { label: "10 +2 free", qty: 12, price: 60 }] },
  { id: "iso-orange-laevis", name: "Porcellio laevis (Orange)", category: "Isopod", unit: "pcs", image: "",
    desc: "Vivid orange — fast breeders, great for new bioactive tanks.",
    care: { temperature: "20–28 °C", humidity: "60–75 %", substrate: "Coco fibre + leaf litter", food: "Leaf litter, vegetables, fish flakes, calcium", notes: "Extremely fast breeder. Excellent for quickly establishing a cleanup crew. Tolerant of varied conditions." },
    packs: [{ label: "1 pc", qty: 1, price: 3 }, { label: "5 +1 free", qty: 6, price: 14 }, { label: "10 +2 free", qty: 12, price: 26 }] },
  { id: "iso-panda-king", name: "Cubaris sp. (Panda King)", category: "Isopod", unit: "pcs", image: "",
    desc: "Bold black-and-white patterning, a premium display species.",
    care: { temperature: "24–28 °C", humidity: "75–85 %", substrate: "Coco fibre + sphagnum + leaf litter", food: "Leaf litter, calcium, occasional fruit", notes: "Slower breeder. Stunning display species. Keep consistently warm and very humid." },
    packs: [{ label: "1 pc", qty: 1, price: 10 }, { label: "5 +1 free", qty: 6, price: 40 }, { label: "10 +2 free", qty: 12, price: 75 }] },
  { id: "iso-peraccae", name: "Armadillidium peraccae", category: "Isopod", unit: "pcs", image: "",
    desc: "A compact, easy-care pillbug species suited to smaller terrariums.",
    care: { temperature: "20–26 °C", humidity: "55–70 %", substrate: "Coco fibre + calcium-rich substrate + leaf litter", food: "Leaf litter, cuttlefish bone, vegetables", notes: "Small pillbug, rolls up when handled. Needs ample calcium. Good in mixed terrariums." },
    packs: [{ label: "1 pc", qty: 1, price: 3 }, { label: "5 +1 free", qty: 6, price: 12 }, { label: "10 +2 free", qty: 12, price: 24 }] },
  { id: "iso-rubber-ducky", name: "Cubaris sp. (Rubber Ducky)", category: "Isopod", unit: "pcs", image: "",
    desc: "A rare bright-yellow morph named for its unmistakable rubber-duck hue.",
    care: { temperature: "24–28 °C", humidity: "80–90 %", substrate: "Coco fibre + sphagnum + leaf litter + limestone", food: "Leaf litter, calcium, decaying wood, occasional fruit", notes: "Rare and sensitive — requires high humidity and warmth. Limestone or coral sand helps buffer pH. Slow breeder." },
    packs: [{ label: "1 pc", qty: 1, price: 20 }, { label: "5 +1 free", qty: 6, price: 100 }, { label: "10 +2 free", qty: 12, price: 200 }] },

  // ===== SPRINGTAILS =====
  { id: "spr-white-jumping", name: "White Jumping Springtails", category: "Springtail", unit: "colony", image: "",
    desc: "Active surface-dwelling culture (50+), a reliable cleanup crew for damp substrate.",
    care: { temperature: "18–26 °C", humidity: "70–85 %", substrate: "Moist coco fibre or sphagnum moss", food: "Yeast, mould, decaying plant matter", notes: "Active jumpers — keep lid secure. Thrives in damp, well-aerated substrate. Great mould control." },
    packs: [{ label: "50+ culture", qty: 1, price: 25 }] },
  { id: "spr-white-nonjumping", name: "White Non-Jumping Springtails", category: "Springtail", unit: "colony", image: "",
    desc: "A calmer surface culture (30+), great for humid bioactive setups.",
    care: { temperature: "18–25 °C", humidity: "70–85 %", substrate: "Moist coco fibre", food: "Yeast, fungi, decaying organic matter", notes: "Stays on and near the substrate surface. Ideal for terrariums with plants. Does not jump — easy to manage." },
    packs: [{ label: "30+ culture", qty: 1, price: 25 }] },
  { id: "spr-orange", name: "Orange Springtails", category: "Springtail", unit: "colony", image: "",
    desc: "Visible orange-toned culture (30+) that adds activity to display tanks.",
    care: { temperature: "20–28 °C", humidity: "75–85 %", substrate: "Moist coco fibre + sphagnum", food: "Yeast, mould, decaying plant matter", notes: "Highly visible orange coloring. Surface-dwelling — great for naturalistic display setups." },
    packs: [{ label: "30+ culture", qty: 1, price: 35 }] },
  { id: "spr-red", name: "Red Springtails", category: "Springtail", unit: "colony", image: "",
    desc: "Striking red culture (30+), a favorite for naturalistic vivarium display.",
    care: { temperature: "20–26 °C", humidity: "75–85 %", substrate: "Moist coco fibre + leaf litter", food: "Yeast, fungi, algae, decaying plant matter", notes: "Vivid red coloration makes colonies easy to spot. Sensitive to drying out — keep substrate consistently moist." },
    packs: [{ label: "30+ culture", qty: 1, price: 55 }] },
  { id: "spr-red-thai-spiky", name: "Red Springtails (Thai Spiky)", category: "Springtail", unit: "colony", image: "",
    desc: "A rare spiky-bodied red variant from Thailand, sold in small founder groups of 10.",
    care: { temperature: "24–28 °C", humidity: "80–90 %", substrate: "Moist sphagnum + coco fibre", food: "Yeast, fungi, decaying matter", notes: "Rare and less commonly kept. Tropical — needs warmth and high humidity. Handle starter group with care to establish colony." },
    packs: [{ label: "10 pcs", qty: 1, price: 250 }] },

  // ===== ADD-ON: SLIME MOLD =====
  { id: "slime-mold", name: "Physarum polycephalum (Slime Mold)", category: "Culture", unit: "culture", image: "",
    desc: "A living single-celled organism that creeps across substrate hunting microbes — fascinating to observe and culture, popular for education and bioactive curiosity setups.",
    care: { temperature: "18–25 °C", humidity: "85–95 %", substrate: "Damp agar plate or moistened oat flakes on paper towel", food: "Oat flakes (rolled oats), bacteria, fungi spores", notes: "Keep in dark or dim conditions — bright light slows activity. Mist lightly daily. Can be dried and revived with water." },
    packs: [{ label: "1 culture", qty: 1, price: 15 }] },

  // ===== WOOD =====
  { id: "wood-cork-10x15", name: "Cork Bark 10x15 cm", category: "Wood", unit: "pcs", image: "", desc: "Natural cork bark piece for climbing, hiding, and humidity retention.", price: 7, stock: 50 },
  { id: "wood-cork-15x20", name: "Cork Bark 15x20 cm", category: "Wood", unit: "pcs", image: "", desc: "Natural cork bark piece for climbing, hiding, and humidity retention.", price: 12.5, stock: 40 },
  { id: "wood-cork-20x30", name: "Cork Bark 20x30 cm", category: "Wood", unit: "pcs", image: "", desc: "Large cork bark slab, ideal as a centerpiece hide or background.", price: 17.5, stock: 25 },
  { id: "wood-cork-small", name: "Cork Bark Small Pieces 100g", category: "Wood", unit: "pack", image: "", desc: "Mixed small cork pieces, perfect for filling gaps and microhabitats.", price: 10, stock: 30 },
  { id: "wood-driftwood-10-15", name: "Driftwood 10-15 cm", category: "Wood", unit: "pcs", image: "", desc: "Naturally weathered driftwood for terrarium hardscaping.", price: 9, stock: 30 },
  { id: "wood-driftwood-15-25", name: "Driftwood 15-25 cm", category: "Wood", unit: "pcs", image: "", desc: "Naturally weathered driftwood for terrarium hardscaping.", price: 12.5, stock: 25 },
  { id: "wood-driftwood-25-35", name: "Driftwood 25-35 cm", category: "Wood", unit: "pcs", image: "", desc: "Larger driftwood centerpiece for bigger enclosures.", price: 16.5, stock: 18 },

  // ===== TERRARIUM GLASS =====
  { id: "terra-egg-small", name: "Dinosaur Egg Terrarium (Small)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Egg-shaped glass terrarium, a charming compact enclosure.", price: 30, stock: 12 },
  { id: "terra-egg-large", name: "Dinosaur Egg Terrarium (Large)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Egg-shaped glass terrarium in a larger size for bigger colonies.", price: 40, stock: 10 },
  { id: "terra-square-door", name: "Square Terrarium with Door (A)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Front-opening square glass enclosure for easy access.", price: 90, stock: 8 },
  { id: "terra-geometric-b", name: "Geometric Terrarium (B)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Modern faceted glass terrarium design.", price: 80, stock: 8 },
  { id: "terra-triangle-c", name: "Triangle Terrarium (C)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Triangular glass enclosure for a distinctive display.", price: 70, stock: 8 },
  { id: "terra-ball-d", name: "Ball Geometric Terrarium (D)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Spherical faceted glass terrarium.", price: 80, stock: 8 },
  { id: "terra-square-horizontal-e", name: "Square Horizontal Terrarium (E)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Wide horizontal layout, good for floor-dwelling species.", price: 80, stock: 8 },
  { id: "terra-square-stand-f", name: "Square Stand Terrarium (F)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Square enclosure on a raised stand base.", price: 70, stock: 8 },
  { id: "terra-geometric-g", name: "Geometric Terrarium (G)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Faceted glass terrarium, alternate geometric design.", price: 70, stock: 8 },
  { id: "terra-cloche-small", name: "Wood Cloche & Glass (Small)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Glass cloche on a wooden base for an elegant tabletop display.", price: 80, stock: 6 },
  { id: "terra-cloche-large", name: "Wood Cloche & Glass (Large)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Larger glass cloche on a wooden base for a statement display.", price: 120, stock: 5 },
  { id: "terra-round-lid-hole", name: "Big Round Terrarium with Lid & Hole", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Large round glass enclosure with ventilated lid.", price: 85, stock: 6 },
  { id: "terra-round-aquarium", name: "Round Tank Aquarium with Lid", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Classic round glass tank with fitted lid.", price: 40, stock: 10 },
  { id: "terra-cylinder-small", name: "Cylinder Terrarium with Hole & Lid (Small)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Cylindrical glass enclosure, compact size.", price: 50, stock: 8 },
  { id: "terra-cylinder-big", name: "Cylinder Terrarium with Hole & Lid (Big)", category: "Terrarium Glass", unit: "pcs", image: "", desc: "Cylindrical glass enclosure, larger size.", price: 60, stock: 6 },

  // ===== TERRARIUM LAMP =====
  { id: "lamp-3w-a", name: "Terrarium Lamp 3W (USB) A", category: "Terrarium Lamp", unit: "pcs", image: "", desc: "Compact USB-powered terrarium lighting, style A.", price: 50, stock: 15 },
  { id: "lamp-5w-a", name: "Terrarium Lamp 5W (USB) A", category: "Terrarium Lamp", unit: "pcs", image: "", desc: "USB-powered terrarium lighting, style A.", price: 60, stock: 15 },
  { id: "lamp-7w-a", name: "Terrarium Lamp 7W (USB) A", category: "Terrarium Lamp", unit: "pcs", image: "", desc: "USB-powered terrarium lighting, style A.", price: 70, stock: 12 },
  { id: "lamp-9w-a", name: "Terrarium Lamp 9W (USB) A", category: "Terrarium Lamp", unit: "pcs", image: "", desc: "USB-powered terrarium lighting, style A.", price: 85, stock: 10 },
  { id: "lamp-3w-b", name: "Terrarium Lamp 3W (USB) B", category: "Terrarium Lamp", unit: "pcs", image: "", desc: "Compact USB-powered terrarium lighting, style B.", price: 40, stock: 15 },
  { id: "lamp-5w-b", name: "Terrarium Lamp 5W (USB) B", category: "Terrarium Lamp", unit: "pcs", image: "", desc: "USB-powered terrarium lighting, style B.", price: 50, stock: 15 },

  // ===== SPHAGNUM MOSS =====
  { id: "moss-20g", name: "Sphagnum Moss 20g", category: "Substrate & Moss", unit: "pack", image: "", desc: "Natural sphagnum moss for humidity retention and microhabitats.", price: 4, stock: 40 },
  { id: "moss-50g", name: "Sphagnum Moss 50g", category: "Substrate & Moss", unit: "pack", image: "", desc: "Natural sphagnum moss for humidity retention and microhabitats.", price: 8, stock: 35 },
  { id: "moss-100g", name: "Sphagnum Moss 100g", category: "Substrate & Moss", unit: "pack", image: "", desc: "Natural sphagnum moss for humidity retention and microhabitats.", price: 15, stock: 25 },

  // ===== CUTTLEFISH BONE =====
  { id: "cf-bone-7-8", name: "Cuttlefish Bone 7-8 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 1.2, stock: 60 },
  { id: "cf-bone-9-10", name: "Cuttlefish Bone 9-10 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 1.4, stock: 60 },
  { id: "cf-bone-11-12", name: "Cuttlefish Bone 11-12 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 1.7, stock: 50 },
  { id: "cf-bone-13-14", name: "Cuttlefish Bone 13-14 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 2.5, stock: 50 },
  { id: "cf-bone-15-16", name: "Cuttlefish Bone 15-16 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 4, stock: 40 },
  { id: "cf-bone-17-18", name: "Cuttlefish Bone 17-18 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 6, stock: 35 },
  { id: "cf-bone-19-20", name: "Cuttlefish Bone 19-20 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 8, stock: 30 },
  { id: "cf-bone-21-22", name: "Cuttlefish Bone 21-22 cm", category: "Calcium & Feeders", unit: "pcs", image: "", desc: "Calcium supplement for isopods and reptiles.", price: 10, stock: 25 },
  { id: "cf-bone-crack", name: "Cuttlefish Bone Crack 100g", category: "Calcium & Feeders", unit: "pack", image: "", desc: "Crushed cuttlefish bone pieces, economical calcium source.", price: 9, stock: 30 },
  { id: "cf-powder-50", name: "Cuttlefish Powder 50g", category: "Calcium & Feeders", unit: "pack", image: "", desc: "Fine cuttlefish bone powder for dusting feed.", price: 6, stock: 30 },
  { id: "cf-powder-100", name: "Cuttlefish Powder 100g", category: "Calcium & Feeders", unit: "pack", image: "", desc: "Fine cuttlefish bone powder for dusting feed.", price: 10, stock: 25 },
  { id: "cf-powder-350", name: "Cuttlefish Powder ~350g (1 bottle)", category: "Calcium & Feeders", unit: "bottle", image: "", desc: "Bulk cuttlefish bone powder in a resealable bottle.", price: 20, stock: 18 },
  { id: "cf-powder-500", name: "Cuttlefish Powder 500g", category: "Calcium & Feeders", unit: "pack", image: "", desc: "Bulk cuttlefish bone powder for larger collections.", price: 40, stock: 12 },

  // ===== MIXED SUBSTRATE =====
  { id: "substrate-500g", name: "Mixed Substrate 500g", category: "Substrate & Moss", unit: "pack", image: "", desc: "Pre-mixed bioactive substrate blend, ready to use.", price: 8, stock: 35 },
  { id: "substrate-1kg", name: "Mixed Substrate 1kg", category: "Substrate & Moss", unit: "pack", image: "", desc: "Pre-mixed bioactive substrate blend, ready to use.", price: 15, stock: 30 },
  { id: "substrate-3kg", name: "Mixed Substrate 3kg", category: "Substrate & Moss", unit: "pack", image: "", desc: "Bulk pre-mixed bioactive substrate for larger setups.", price: 44, stock: 15 },

  // ===== LOTUS PODS =====
  { id: "lotus-7-10", name: "Lotus Pods 7-10 cm", category: "Decor & Hardscape", unit: "pcs", image: "", desc: "Natural dried lotus seed pod for enrichment and decor.", price: 4, stock: 30 },
  { id: "lotus-10-13", name: "Lotus Pods 10-13 cm", category: "Decor & Hardscape", unit: "pcs", image: "", desc: "Natural dried lotus seed pod for enrichment and decor.", price: 4.5, stock: 30 },
  { id: "magnolia-pod", name: "Magnolia Seed Pods", category: "Decor & Hardscape", unit: "pcs", image: "", desc: "Natural magnolia seed pod, decorative enrichment piece.", price: 6.5, stock: 20 },

  // ===== REPTILE BOX =====
  { id: "box-xxs", name: "Reptile Box XXS", category: "Reptile Box", unit: "pcs", image: "", desc: "Compact ventilated enclosure box, smallest size.", price: 5.5, stock: 40 },
  { id: "box-xs", name: "Reptile Box XS", category: "Reptile Box", unit: "pcs", image: "", desc: "Compact ventilated enclosure box.", price: 6.5, stock: 35 },
  { id: "box-s", name: "Reptile Box S", category: "Reptile Box", unit: "pcs", image: "", desc: "Small ventilated enclosure box.", price: 6.8, stock: 35 },
  { id: "box-m", name: "Reptile Box M", category: "Reptile Box", unit: "pcs", image: "", desc: "Medium ventilated enclosure box.", price: 14, stock: 25 },
  { id: "box-l", name: "Reptile Box L", category: "Reptile Box", unit: "pcs", image: "", desc: "Large ventilated enclosure box.", price: 19, stock: 20 },
  { id: "box-xl", name: "Reptile Box XL", category: "Reptile Box", unit: "pcs", image: "", desc: "Extra-large ventilated enclosure box.", price: 22, stock: 15 },
  { id: "box-s-2gen", name: "Reptile Box S (2nd Gen)", category: "Reptile Box", unit: "pcs", image: "", desc: "Updated small enclosure box design, 2nd generation.", price: 7.8, stock: 30 },
  { id: "box-m-2gen", name: "Reptile Box M (2nd Gen)", category: "Reptile Box", unit: "pcs", image: "", desc: "Updated medium enclosure box design, 2nd generation.", price: 19, stock: 22 },
  { id: "box-l-2gen", name: "Reptile Box L (2nd Gen)", category: "Reptile Box", unit: "pcs", image: "", desc: "Updated large enclosure box design, 2nd generation.", price: 25, stock: 15 },

  // ===== FEEDING DISH =====
  { id: "feed-leaf", name: "Feeding Dish — Leaf", category: "Feeding Dish", unit: "pcs", image: "", desc: "Leaf-shaped feeding dish for a naturalistic look.", price: 5, stock: 30 },
  { id: "feed-cart", name: "Feeding Dish — Cart", category: "Feeding Dish", unit: "pcs", image: "", desc: "Cart-shaped novelty feeding dish.", price: 5, stock: 30 },
  { id: "feed-jt01", name: "Feeding Dish JT-01", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-01 style.", price: 12, stock: 20 },
  { id: "feed-jt02", name: "Feeding Dish JT-02", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-02 style.", price: 14, stock: 20 },
  { id: "feed-jt03", name: "Feeding Dish JT-03", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-03 style.", price: 32, stock: 12 },
  { id: "feed-jt04", name: "Feeding Dish JT-04", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-04 style.", price: 38, stock: 10 },
  { id: "feed-jt05", name: "Feeding Dish JT-05", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-05 style.", price: 16, stock: 18 },
  { id: "feed-jt06", name: "Feeding Dish JT-06", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-06 style.", price: 28, stock: 12 },
  { id: "feed-jt07", name: "Feeding Dish JT-07", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-07 style.", price: 38, stock: 10 },
  { id: "feed-jt08", name: "Feeding Dish JT-08", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-08 style.", price: 11, stock: 20 },
  { id: "feed-jt09", name: "Feeding Dish JT-09", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Designer feeding dish, JT-09 style.", price: 13, stock: 20 },
  { id: "feed-glass-45", name: "Glass Feeder 45mm", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Small glass feeding dish, 45mm diameter.", price: 5, stock: 25 },
  { id: "feed-glass-52", name: "Glass Feeder 52mm", category: "Reptile Feeder", unit: "pcs", image: "", desc: "Small glass feeding dish, 52mm diameter.", price: 5, stock: 25 },

  // ===== ORNAMENTS =====
  { id: "orn-stair-straight", name: "Stair Case — Straight", category: "Ornament", unit: "pcs", image: "", desc: "Decorative miniature staircase, straight design.", price: 5, stock: 25 },
  { id: "orn-stair-curve", name: "Stair Case — Curve", category: "Ornament", unit: "pcs", image: "", desc: "Decorative miniature staircase, curved design.", price: 5, stock: 25 },
  { id: "orn-totoro-a", name: "Totoro Ornament A", category: "Ornament", unit: "pcs", image: "", desc: "Whimsical Totoro-style decorative figure, style A.", price: 5, stock: 20 },
  { id: "orn-totoro-b", name: "Totoro Ornament B", category: "Ornament", unit: "pcs", image: "", desc: "Whimsical Totoro-style decorative figure, style B.", price: 5, stock: 20 },
  { id: "orn-totoro-c", name: "Totoro Ornament C", category: "Ornament", unit: "pcs", image: "", desc: "Whimsical Totoro-style decorative figure, style C.", price: 5, stock: 20 },
  { id: "orn-totoro-d", name: "Totoro Ornament D", category: "Ornament", unit: "pcs", image: "", desc: "Whimsical Totoro-style decorative figure, style D.", price: 5, stock: 20 },
  { id: "orn-totoro-e", name: "Totoro Ornament E", category: "Ornament", unit: "pcs", image: "", desc: "Whimsical Totoro-style decorative figure, style E.", price: 5, stock: 20 },
  { id: "orn-totoro-f", name: "Totoro Ornament F", category: "Ornament", unit: "pcs", image: "", desc: "Whimsical Totoro-style decorative figure, style F.", price: 5, stock: 20 },
  { id: "orn-bench-brown", name: "Wood Bench — Brown", category: "Ornament", unit: "pcs", image: "", desc: "Miniature decorative bench, brown finish.", price: 5, stock: 20 },
  { id: "orn-bench-orange", name: "Wood Bench — Orange", category: "Ornament", unit: "pcs", image: "", desc: "Miniature decorative bench, orange finish.", price: 5, stock: 20 },
  { id: "orn-bench-cream", name: "Wood Bench — Cream", category: "Ornament", unit: "pcs", image: "", desc: "Miniature decorative bench, cream finish.", price: 5, stock: 20 },
  { id: "orn-door-a", name: "Door Ornament A", category: "Ornament", unit: "pcs", image: "", desc: "Decorative miniature door, style A.", price: 5, stock: 20 },
  { id: "orn-door-b", name: "Door Ornament B", category: "Ornament", unit: "pcs", image: "", desc: "Decorative miniature door, style B.", price: 5, stock: 20 },
  { id: "orn-door-c", name: "Door Ornament C", category: "Ornament", unit: "pcs", image: "", desc: "Decorative miniature door, style C.", price: 5, stock: 20 },
  { id: "orn-skull-human-small", name: "Human Skull (Small, Resin)", category: "Ornament", unit: "pcs", image: "", desc: "Decorative resin human skull, small size.", price: 20, stock: 10 },
  { id: "orn-skull-human-medium", name: "Human Skull (Medium, PVC)", category: "Ornament", unit: "pcs", image: "", desc: "Decorative PVC human skull, medium size.", price: 18, stock: 10 },
  { id: "orn-skull-human-large", name: "Human Skull (Large, Resin)", category: "Ornament", unit: "pcs", image: "", desc: "Decorative resin human skull, large size.", price: 25, stock: 8 },
  { id: "orn-skull-animal-a", name: "Animal Skull A", category: "Ornament", unit: "pcs", image: "", desc: "Decorative animal skull replica, style A.", price: 25, stock: 8 },
  { id: "orn-skull-animal-b", name: "Animal Skull B", category: "Ornament", unit: "pcs", image: "", desc: "Decorative animal skull replica, style B.", price: 12, stock: 10 },
  { id: "orn-skull-animal-c", name: "Animal Skull C", category: "Ornament", unit: "pcs", image: "", desc: "Decorative animal skull replica, style C.", price: 12, stock: 10 },
  { id: "orn-skull-animal-d", name: "Animal Skull D", category: "Ornament", unit: "pcs", image: "", desc: "Decorative animal skull replica, style D.", price: 15, stock: 10 },

  // ===== KITS =====
  { id: "kit-springtail-a", name: "Springtails Kit — Set A", category: "Starter Kit", unit: "set", image: "", desc: "Complete springtail starter set with everything needed to begin a culture.", price: 25, stock: 15 },
  { id: "kit-springtail-b", name: "Springtails Kit — Set B", category: "Starter Kit", unit: "set", image: "", desc: "Complete springtail starter set, expanded version.", price: 30, stock: 12 },
  { id: "kit-isopod-starter", name: "Isopod Starter Kit + White Springtails", category: "Starter Kit", unit: "set", image: "", desc: "Full starter bundle for beginning a bioactive cleanup crew, includes a springtail culture.", price: 79, stock: 10 },

  // ===== FOOD =====
  { id: "leaf-catappa-20", name: "Catappa Leaves 20g", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Dried catappa (Indian almond) leaf litter for naturalistic substrate and microfauna food.", price: 4, stock: 30 },
  { id: "leaf-catappa-50", name: "Catappa Leaves 50g", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Dried catappa (Indian almond) leaf litter for naturalistic substrate and microfauna food.", price: 8, stock: 25 },
  { id: "leaf-mulberry-20", name: "Mulberry Leaves 20g", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Dried mulberry leaf litter, a favorite forage for isopods.", price: 5, stock: 25 },
  { id: "leaf-mulberry-50", name: "Mulberry Leaves 50g", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Dried mulberry leaf litter, a favorite forage for isopods.", price: 10, stock: 20 },
  { id: "eggshell-20", name: "Eggshell Powder 20g", category: "Calcium & Feeders", unit: "pack", image: "", desc: "Ground eggshell calcium supplement for isopod colonies.", price: 2, stock: 30 },
  { id: "eggshell-50", name: "Eggshell Powder 50g", category: "Calcium & Feeders", unit: "pack", image: "", desc: "Ground eggshell calcium supplement for isopod colonies.", price: 5, stock: 25 },
  { id: "eggshell-100", name: "Eggshell Powder 100g", category: "Calcium & Feeders", unit: "pack", image: "", desc: "Ground eggshell calcium supplement for isopod colonies.", price: 8, stock: 20 },
  { id: "chow-25", name: "Isopod Chow 25g", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Balanced nutritional chow formulated for isopod colonies.", price: 10, stock: 25 },
  { id: "chow-25x2", name: "Isopod Chow 25g x2", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Twin-pack of balanced nutritional chow for isopod colonies.", price: 18, stock: 18 },
  { id: "shrimp-20", name: "Freeze-Dried Shrimp 20g", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Protein-rich freeze-dried shrimp treat for isopods and reptiles.", price: 10, stock: 25 },
  { id: "shrimp-80", name: "Freeze-Dried Shrimp 1200mL (80g)", category: "Food & Leaf Litter", unit: "pack", image: "", desc: "Bulk protein-rich freeze-dried shrimp treat.", price: 18, stock: 15 },

  // ===== TOOLS =====
  { id: "tweezer-straight-12", name: "Tweezer Straight 12.5 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision straight tweezer for handling small livestock and feed.", price: 4.13, stock: 30 },
  { id: "tweezer-straight-16", name: "Tweezer Straight 16 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision straight tweezer for handling small livestock and feed.", price: 4.7, stock: 30 },
  { id: "tweezer-straight-20", name: "Tweezer Straight 20 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision straight tweezer for handling small livestock and feed.", price: 5.26, stock: 25 },
  { id: "tweezer-straight-25", name: "Tweezer Straight 25 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision straight tweezer for handling small livestock and feed.", price: 6.51, stock: 20 },
  { id: "tweezer-straight-30", name: "Tweezer Straight 30 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision straight tweezer for handling small livestock and feed.", price: 7.13, stock: 18 },
  { id: "tweezer-curve-12", name: "Tweezer Curve 12.5 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision curved tweezer for handling small livestock and feed.", price: 4.13, stock: 30 },
  { id: "tweezer-curve-16", name: "Tweezer Curve 16 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision curved tweezer for handling small livestock and feed.", price: 4.7, stock: 30 },
  { id: "tweezer-curve-20", name: "Tweezer Curve 20 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision curved tweezer for handling small livestock and feed.", price: 5.26, stock: 25 },
  { id: "tweezer-curve-25", name: "Tweezer Curve 25 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision curved tweezer for handling small livestock and feed.", price: 6.51, stock: 20 },
  { id: "tweezer-curve-30", name: "Tweezer Curve 30 cm", category: "Tools", unit: "pcs", image: "", desc: "Precision curved tweezer for handling small livestock and feed.", price: 7.13, stock: 18 },
];

const CATEGORIES = [
  "All",
  "Isopod",
  "Springtail",
  "Culture",
  "Starter Kit",
  "Wood",
  "Terrarium Glass",
  "Terrarium Lamp",
  "Substrate & Moss",
  "Decor & Hardscape",
  "Reptile Box",
  "Feeding Dish",
  "Reptile Feeder",
  "Ornament",
  "Food & Leaf Litter",
  "Calcium & Feeders",
  "Tools",
];

const LOGO_BASE64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAADwCAYAAAA+VemSAACuHUlEQVR42ux9d3wU1fr+856Z2ZpCOjWh9957ERRQVCxg7xV7u/aG7VquvV2Va7s2QMWCUkREkN57T4BAIL1unZnz/v7YTbKbbMiC4MXvL6+fmLA7c2bmzHnO298XaKAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqAGaqBTlahhCv6eJITA9ddfr61YscLStGlTR2lpqePAgQOWsvx8wRaLYGYl+H4lEcm4uDgzwZFgpiXHesnp9LpcLreudzfWr5+mS8kAuGFSGwDcQCfsxRDhrLPOcuzfvz/x0KFDzTRNa1VRUdHYYrG0crlcjVVVTdN1PVVKaVUUxQHAIU1pkdIkEBEzi5CxmEhIIcgkIi8ze0zT9CiK4ldVtUDX9SN2u71Y1/U9MTExRYqiZDmdzgKbzXbozjvvLL/55pt15gaANwC4gerkpn369Ek6dOhQ+4qKih6GYXSUhtEZQmlpGHqSlDKRmfFXgIhIAGCoiuqTLAtVVc1VVXUvkbLFbrduTklJ2dG6det9P/30k7sB1A0A/v+SmFnp0KFDeklJSQ+/3z/Q5/P1NQyjk5SyiZSSTlVgCCEghPAoipKtKupmi2pZ44h1rGjcuPGWdevWFTQAugHA/2fF4Q4dOjQpLSoa4Pb5Rvl8vsGGYbSXUsZJKf/20oOiKIcVRdlss9n+SEiIXdStW68NP/74Y3kDoBsA/Lde2B07dmybm5s72u12TzAMfaBpyuS/O2DrI1VVIISyx2axLI6NiZnTNDHxjzXbtx9pAHMD/S1A26ZNm7aNGjW63W63/apqajkRVZp4/7/7EUKwpmlHYmJjZqSkpFzRsU+fJkQNPKOBTjHq1q1bQlJS6uUxMTE/qapa+v8zaOv6ISLWNO1IbEzMF02bNj170qRJ9oaV00D/U26bkZHRKyYu5hVN07IaQBv9j6IobLPZNjWKi3uoTZs2bRu4cgP9ZfTee+9pjRs3Hu90Omepqub9u4CmadOmPHDgIB4yZAgPGjyYW6S3YEVR/sdcGayqanFMjPOTJk2aDGPmBiQ30MmhCRMmOFJSUq6y2awrhSJO5sKWmqbJJk2ayGbNmsmEhISqz491rEaNGvHNN9/ECxcu5MLCQg6lkuISXr16NT/91NPcvn37U4Ermw6749eUlJTz33vvPa1hxTXQCaERI0bEJCcn32C1WjcIcfKAm5SUxFdffTXPmD6DN27ayAWFhbK4tIQPHMjmRYsW8XPPPcc9e/aMerwzzjiDt2zdytFQSUkJP/nkk2yz2eocLy4ujtu1a/eXGL5sNtuKpKSky26//XZrwwpsoOOiSZMmWVJSEq+02WybicRJ1QenTLmFs7Ky6gWax+Ph9957j9PS0o7Kja+77jr2er3VJ8qocMyzZ8/mxMSkOscsLy/nJX/8wU899RSPHDmSnU7nyQbyqpSUlAtnzJihNKzIBoraOJWWljbBbrf/IcTJNUzFxsbyV9On1wKSZGaWMvhXbfRt2bKFO3bsGBHEY8aMYZ/PVz1QNOCV1Yf9/PPP0m631xr322+/rXXajp07+e233+Zx48ZxXFzcSQOy3W5fmJqaOkaQaFigDRSZiAitW7fu63Q6v6shKsuTsTDtdjt///33HA2bjPTNrl27OCMjI2zMhIQEuWvX7jrHyczM5Llz5vLixYu5tLQ0/BohF3n88cdl6HMnJSfLI0eOHHUPyMzM5I8//lhOnjSJmzZtdlJ05BiHY3rr5q27NazWBgqjzp07N46Li3tJVVXXiVpwbdu25fSM9Dq/f/LJqXWCwTRN3pe1j/ft38+madZ53KxZszh0s7n//n9EPC4vL4+vuupqjo+Pr9qU2rVrxx98MC1kk5BhOnHr1q2rxj377HP4WCg/P59nz57NN954I7dt2/aEAllV1ZL4+NipnTt3TmxYuf+fEzOLlJTEK0+kH7dbt+78zjvvcGlpKU+fPj0i927fvj2XlZXXAg4z81dfTedBgwZyXFwcx8fHc//+/eUH06ZF5sxS8rhx4xgAW61W3rx5cy1mXVxczIMHD67zft98682I3P7BBx+suve2bdryI48+KhctWlSDc8t6ZYXy8jJeuvQPvuKKK06YJENEbLVad6SkpFzQ4EP+/5RatWrV3W63/3iiLMvDhg7jL7/8il0uV9Xidblc3LFjx1rHPvvccxGX/NSpU+t0LT366GNVUm7oOTNnzmQA3KlTJ/Z6fbUA9M9//vOowElISODMCAa0X375JeLxrVq15quvvpp/+WXBMXHlhx56SJ5odUQIwQ6H4/N27dq1bljR/x9x3aSkpFs1TSv5swtI0zQ+99xzec6cOWzoRkRx9PU33gjTozVNkxs2bKi1wFesWHnUwAoi4vm//FKLxR3KOSQdDoc877zzan2n6zr369ev3ud48623at3Pvn37OC4uts5zHn300ajBW1payhktW9YaIyUl5YQAWdO0nEaNGl0lGrjx/21q06ZNW6fD+X0I1z0ujhATE8NXXnkVr1y5st7F+8uCBWy1WqvOTU9PlyXFJbWOu+eee+q97sUXX1wLpIZuyA4dO8orrryyFnfOy8vj5KTkese9/oYbIuqxycmRz9UsFl63bl0tA9i+ffv4mWee4VWrVrGu61Xff/fddxHBu337dv5u1nfcp2/fPxX4EuDGxA6744vWrVunN6z0/4MW5rS05Is0Tcv5Mzt9SkoK33nXXbxt+/Z6zcRr1qzhyy67TNb0lfbp20dKWfuEESNH1Hv9rl27Sp/fV+vkHj16yMuvuFxGAnBSUlK941573XXHBOCu3bqy3++vdc57770ng4Ym7tOnj3z44YflsmXL5CWXXFJro3zxxRerbtXtdvObb7wpW7Ro8ae5scVi2de0adNzGnTj/yM0YcIER1xc3CuKoph/ZmGMHTuWDx48WK97Z+XKlXzJpZfKUK4b+tOvX7+I/qLhI0bUKw106NBBut3uWuf36tVLjh49ptbnfr+f+/TtU++zvRVBhN61axc7HJEDNe68866I0sbEiRNrcUcikkJRwp6tc+fOXFZWVst/dejQIb7nnns4Jibmz7qc9Pj42OdHjBhha0DA35jS09Nb2W32hSfCwty3X7+IXIeZ2ZSSly5dyhddfDFbLJajg7BjB+lyu2uNcettt9V7D8NHDI8I0s6dO8tmzZpxeUVFrXGDOnidP02aNOGcwzm1zvvhhx/q1MUXLlxYawM7fPgIJycn17sJERHPmjXrqGrHhg0b+JxzzvnTlmq7zfZLRkZGywYk/A0pLS1tlKZpmSfS6vnVV1/JSD7b62+4gVVVq+mv5PHjx/PXX3/NbVq3kSH6s6y0+oYONmfOnPqNTW++WWuxZ2dnc1xcHBMRL168uJZ04PZ4ePz48RHHs1qt/M2330R0Z9111111WqHLysvrtIbX9zNhwgSOpEJEcpF99NFHnJaW9mcNXHvS0tJGNiDi76TvJidfqypKGU5wNNDAgQPZ7/fL2q6a58MMXFdddRUvX7686vt7770vjDN9/vnntRasYRhy0qRJdV77tNGncXkQOOF+4y+rjrn88svDAFAJsdKyUv7H/f/gpk2bsqIobLfbediwYTx//vyI4CksLOQWLVpE5KZXXX11xHOuuPyKeufP4XDy+vUboogzq6atW7dy165d/6xIXdYosdGVDWrx38BFlBAf/7QQ4qSEPwLgH3/8sdYiKyoq4j59+/B1110nN23aVOv7TZs2hWX6jB49mqU0ay3h0tJSvvfee7lJ06ZVx6ampvLNN9/MhYVFtZa7aZo8YkS18ctms/Hvv/9+lAipPF69ejVv376DTaPuCK/777+/zuefOXNmxGym9PT0eufuH/dFjhRbsGABX3/9Dbyvhj+68ll3794dNifH6TM242Pjnwytl91ApxCNGzfO6nA43qOTnIAwevToqvDGUDBVGWXqoHEhYqwQgr/55pswG06oCJuXn8crV63iFStW8KFDh2SouyaEsfKXX33JNfX79u3bywMHDkTto63J/z77/DPWNC3isycnp3Bubm6tk+fNm8/12RkyMjI4Pz+/1vV9Ph8PGjSoUh+Xb7/9dsTN5T//+fDPB36QYIfD8d64ceMa0hRPJRozZky8w+H4muivKQezaNGiowJC1kgBnDFjBnfq3KnWgs7ct+8YhMkabqq1azm1Dv2wZ8+ecuvWbfJomUeRvpw2bdpRc4InTJgQ8dSbb55S77xN+89/It7Ohx/WBubd99wja8aAl5eX10reOF7jVmxM7Ixx48bFNSDnFKC2jdum2O32BcfzMlu3bn1cLotzzqk/uL+wsJDfe+892atXrzpDCLt168abN28+ZhD//vvv3Lwen2lKSop89dXXuCgoetenZ152+eX1qh3vvfderVssLy/ntm3aHD3MdPjw6hTHECooyOemTZvWuq7TGRNRijjnnHNPWCy1w+H4pU+fPskNCPofUosWLZpaLJYVx/ES5XXXXS+PHMnloUOHHrO+bLFY64zC2rlzJz/++OOyVatWUQeHvPvuu7KiwlUv0I4cOcKPPfqoPJZNp1WrVnz77bfzt99+y9u3b+f9+/fzvn37eOXKlfzhRx/xpEmTOCY2tt5xnE4n79mzp5bvdtGiRXw0ycdiscily5ZFfB6v18tvvPGGTExMDIuKS09P5+II0WqTJ08+obYNh92+pGurVmkNSPofUMuWLTMsFm3Nsb60hMRE/vjjT6oWxZQoxL9IP+eff37ERTl16pPHFaLZtVs3+dxzz8nlK1bw4SOH2ePxyIqKCs7KyuIff/yR77jzDm7WrNmfSgiwWq0yJiaGnU6nDBr6oh5r1GmnRTZ4/eMfR4/yuvbaeiWMrdu28VVXXc1NmzThjh078uzZsyNea+TIkRHvt02bNty4cePjmheLxbKkdevWqQ2I+gupefPmzaxW67pjfVnp6em8fv36sEXx7rvvHhfgNE3jVatW1VpkOYdzuEmTJscNMiLi1NRUbteunWzVurWMjYI7/hU/Z4wdy9u2basVRNKzV686z0lOTuZ9Wfsi+pkjoTk/Pz+iqyxQMCArYtWPdu3acWZmJm/ZsoU7deokj3NjW9oA4r+IMjIyGlssluXH86I6d+4cFmTPzLxkyRI+XrfTlVddGVFlffLJJ+SpALoT/eNwOHjkyJHy9ddf58zMTN62bRtbrdY6n/Vf/3pJRhadfUdlyZHSJm+/445a46c1bszrQzK79u3bx8OGDT+uZ7PZbL/16dMnvgFhJ5E6d+6caLVal+D4o3J448aN4Rwz5zAHdbBj/nE6nbw1QuXHnEM58s9GEJ3knz+9wSQkJBy1HG337t25oiq0U4YFmFx00UXy8ccfZ3dISKk8iog9c+bMWq6tpKSkiJFnpaWlfMUVVxzvBvVNg4vpJNGIESNsdrv9pz+78GbMnBmWtWMYBvfq1fu4x7vpppsiinwvvPhi3cXsLMTdUhS+sJ3Kd/Sx8Fsj7TxtlI2nj3fw3LMd/OvZdv7lTBvPOcvB34138Kej7fzeCDu/OcTK9/a28BWdNT49Q+XOyYKT7MSqcmptEFarlX/55ZeI8zJv3ryqzWPwkCG8cOFvRw2n/Pjjj2t5CpxOJ8+ZM+eoJYkeevjh4+XE0yZNmvS3qYKp/h1ukpkpJsbxpsfjOfPPjrVlyxZMuvBCRrAzo6Io6Ny5E9avX3dc43311Vf4x/3/QJvWbao+W7NmLf++aFFY4F7LeIHRGSrGN1PQI0GgmY1gF1Wab+B31QNX/o8Cd1l1twBE4DsJgk8y8v2MPB9jTwVjXb6JZUdMbC6QXOb733U5cDicsFptoXcNAPD7fHjssceqPlu2dClOP/10jBs3DpdccjH37NkLSYmJlJefh82bt+Cjjz7Er7/+Gja2oih45513MG7cuJBpCb+UEALPPfssEhMScP/99x9TY3Sfz3fd/PnzC4jowb9DR8W/BYAT4hMe8nh815+IvWDtmrWEGiurc+cuxz1gaWkpXn31Vbz15lvYtWsXXnzxRXzxxRfk8XgAAka0UHFbVw2npShIVAmQDEjANAAjDLE18UYgcPArAlciPHgSEcMKoIVCSHcS+sYSLm6mQmdgn5dpab6JmZk6Fu434TX+2oVYXFyEM844HZdddhkeeughtGkT2Nw+/OgjrFq1KuxY0zTw00+z8dNPs8lqtSI2NoZLS8tI1/Va4woh8Mabb+LKK6+sNVeR6L777oOqqrj33nsgZXRzwMwoLy//R3x8/IHS0tJ3TnUQn/KiQkpKyoWlZaVvSymjjmGdNGkSd+/eA6UlJVRWVhb2pg3DwHXXXQeLxVL1YX5BPmZMn3Hc97ht6zasX78BjzzyMC9btowMw0C/xgreH2nHU901dI0RsElAmlX4DS46Cll8FPL/auAG0QpC9d8IbkEc/JFEgXFNhjCBZAXomSBwWRsVZ7bRAJWws1jCb/51780wDFq/fj2++uorqKqGxo3TcMMNN3BpaWmdkoFpmnC7PVRXD+WpU6fivnvvjQjbTz/5FNt3bEfXrl3Dzhk4cCBUTcPChQuPSeIzDGNMWnLyygqXK/NUxscpnZ/RNKNpz/xDeb/ohhF1xMzYsePw/fffwWq1ori4COvWrcfChQuxYMECbN6yBR63mzdu3ETdu1eXF965ayd69ugJr9f7p+/ZogAP9bXhvi4WxDDDNBiolJA5KA8TwCAQAyAOfE41uHHYxs9VoK38N1dDupqBMwcAzlwleqsKARqwoUziqXV+zNqt/0/eZXJyMgoKCo77/FtuuQVvvfUWKBg1Erpw586di4kTJ8Lv9+Ppp5/GI488UmtjOPvss3nOnDnHtN41TctJTU0deejQod0NAD5G6tmzZ8q2bdsW+v3+rtGe06ljRyz49Vc0bdo04u6+a/duLPjlF4wYPgLde3Sv+s7jcaNHjx7YvXvPn9twYgXeH2nHWSkC0uAqTktgcBXIKrlnyORTCMetAh/VFq2rQIrQwcKAXfU3c+WlQABUAUADPtlv4t4lXhR6Tn39rpJuuulGvP3221AUNSCchOx3S5f+gfPPP5/z8vKrJurll1/GPffcEzbG8uXLMWLECEQSzY9GVqt1RZ8+fc5YtmxZeQOAoxdhhNPp/MLtdl8U7TlpaWn4deFC7tK5M4VyrjBOFXaNagkVAMaNH8fz5s477vlokygwc6yde9kF6XpARw03SgUmWwleVDKDOajbUoRXUnk+h4CVUBuwoaJ2GOBrA5QYUCyEdRUSly3wYEehPOXBe+WVV+LDDz+EokTW9h586EG88PwLYZ81atQIW7ZsQbNmzapmxOf3oU/vPti6deuxAYQIDpvt04r777+Gpk495SbslMyNTEpKusPj9V50LOfExsbhl/nzsW7dOvb5fCGGoMjLmUKMFgBw1plnHTd4WzZS8P04B3pZiXSDw/EUZIEEoMIE1hQa2Fpi4oiXUSEZUABFEFSFoIoQrsrVOjExB+63ytnBIcz36LfNIX8wAYaf0dtB+HGcA52TT20TyFkTJuCdd96tE7wMxtSpT2HKlCm1DIsVFRVh79lqsaJ58+bHw0zg8fmuTHj19SkNRqzojFaDS0pKPpJSWo7lvKKiIsybN48+/PBD+v6775C5bx8rqkopqamwWCy1uHClGFZZvXDAgAFQVRW//fbbsd2vg/D9ODt62gV0s1pkreakQWaqED7Y6MPc3QbWHDax4pCBFQdN7CmR8EpgwX4TpiA0d4qAuI0gaAXBD4IIglwIgiCCoOD2FKIyU02nCldvHlViZ9DglawCp2Vo+CnbQInv1BOnhw4dyjNmzKD4uLijCpCqouDMM89ETEwMli9fzn6/ny677HJcc83VYcBnZnzwwQc4cODAcYHYMI2hzdOazy+tKD3cIELXQT169Gi0ffv2xX6//0Q1sOKOHTvS6DFjcNZZZ2HwwEGIbxRfi0OFaqSPPvoonn322ejEFwI+HWvHZc0UGHpwOoMcnSvdQAQIBioYePYPL6QE0mIFyvyMch+jXaICRWHecNAkTQHfO8RG6XYBQ0oIQfhip46d+SbirIR4OyHBTkhyCCTbBZJthGQrYFUJhhmuH1Sp3FRbDql0M2sqsKCEcfaP7r/c1XQ06t+/P3788UdOTU2ttT79up+feupp3HjDDZSeHl4CesvWrZyfl0dDhw6FpoX3CD946BC6d+vGxcXFx73mbVbbqmHDh532yy+/uBoAHEnXcDjedblcN5+sa7Rq2QqjThuF008/HSNHjkTjxo0jGruuuuoqfP755/WOd21XDf8ZaIPpY3CIflq1KXA10I/4GC/94YXDQnhguAMOFfD4JZiAfy33weWR8Jngvs1VuqqLBcSM+QcMzNquw6kBpgS8BkOXAAmCIgKGqUQboUdTlc9prRFJrgYsc8gmQiGKf4gdDIBqIdy/0Y+X1vhOvr4mACnrO0Zg7tx5fPrpY2qtT2bGTTfdhGnTPsCu3XvQtk2bqK89depUPPnkk38SLITYGOe/yl2uf5wq/uFTRgdOSUmZ6PV6b4z2+IkTJ+Kjjz5Cq1bRt8XJ2peFDz/8EJdccgl69+7Nc+bMraUrKoqCDz74ABPPnXjUsZrFEp7qZQH7a4CXA95ZrpalIYhQ4WcYQRB+sMaDLzZ5sTnPhCkZbr8EEWBTibYcMVHsl9hdzvhptwGrCIx7RjsN1/e14oIuVqTGCFgVwKERcsolNhw2yJSVQnTg6kyVfwWBGwpkqvY/S53xQBcL2iWIk7oi+/dQsfLTWDx1s7WWkyyUpJR46KEHsXPnzlrM5Yknn8QHH3yArl27cXqLFlFfe9myZXjllVf+9PMxGC6P+47k5OQzGoxYIdS1a9e0kpLiV0zTjOp+WrZsyW+9/RZfffXVWLFiOe655x4ONqWOmg4fPkxXXXUVVq9eXS2KBNe53W7HRx9/hGBSfkR6tI8NzVQBMyQQg6uk6GqhNaBjM4o9AbeSZGB/scTi/QZmbPOjRAcgCRaV0K+VCpef8ct+EzO26ZCSkRAj4DMYBS6JPmkqRrdUoYqA4ev2gVb8Y6gdt/a1QqXwjYgQ5MZUx1IMWrlNBpIUxv19LCdNGktOFPjsYRv6phJuHWtBUsLRLW9r166l8ePHY82aNVWfvfrqa3jm6aer7BWhgThH44a/LvgVF1xwAcrKyk7I85mmtJSUlLwx8BRpb/o/BzARISsr6xm/X2+Fo+zMlWSxWvjtd95Bs6bNCABSU1Px8ssv0++Lfqczzzy2UOn8/DxMnnwRb922rdrwG3zNzz77LGdnZ0d86d2TFVzRSoM0Obgv19BHQlxAHPRXlfgYhgRnJCp4dKQddw2047reVrh9DJ/J0BRwnzQBp4WwbJ+O7BITXZso6NpYsM8ENDXAt/LdEqVeyXYNSNYIHWIFUq0iuHlw0GpNdShKoXcaQDdRIKxzUrqG9oknx6b59I02bpdIgJsRqxGap9a/7LKysnDOOefyihUr8Ol//4t777unCqhDhw2ruYiwdt067Nm7F26PByUlpdiwYQPuu+8+TDh7Ao4cORLxGnFx8Xj3nXfx73//m4+lFYthGB22HTj4yKnQvuV/DuCkRknjPR7PtVHq5Hz33ffgzPHjax3Xr38/zP5xNj7//HMEm0pHRfv2ZdHEc8/F/v37g3ESjPvuvQ//+te/yDCMiOdM6W6BU4QGalQDhEBBAHFItCSjNKBikkMFrArQMUGgW6qKIg/DlAynRtQiRkGiE/AagMNKuKCjhlJ3INMhzhoQyUt1wGeAYi2AJgBDBrh69e7DoQZwhIdrhk5x9cYjAcQTcGVH7Zjf37mjNbx4rx2n9VcRydszqr+K60dphKDZR9OAFqnRLbvDh3No7NixmHLzzeBgLLOmady7d68weYMAvPjCC+jVsyf69OqN7t27oX+//nj55ZfrjK7r0qULz58/DzdPuRk33XQTPfjgg1GvGWaGy+O6pUmTJoP+vwbwiBEjYspcZS8cQ5wz/bFkCdavX1/LkgwEjDuXXnop/li6lO644w622aJrjbNnzx5cffXVOHToEO5/4AG8/MrLdR6bES9wYboCWWW1rfk7hANXRUUR4qyAlIzNR0xMXeTB00s9eHO1F+tzTBAR2zWCVQBjW1uQGke4vJsFyTaBQnfArxxnDYCzwhcAfJxdQBHVruFKxZJRXaCqOlqrloyAELgHPjUY56WrcGjRc5WURoRpd1jxj7M0/PqsHYvfdOKac62Iiw2M4bAT/nWTDaoRHlHWOSP6a5SVlcHtdlerTxktqTrzKzCO1+vFli1bUFFRgR07dyA7Oxu6UXfE1aWXXopff/2VBgwYUPXZM88+Q1dcccUxiNKmraSk5IUbb7xR+/8WwGvXrr1d1/VjchktXbqURp92Gl57/TX4/f5a2AGAtNRUvP7667To90U444zo7A2LFi1C79698a+XXjrqcee30ZCsBnypEVTLcH04aIk2Tcaw5gpGtlWRGiugKIRiD2PLERNb8034TFB6IwGYQK8UBY8PtqN3ksIeP6PMxxAEJNsDr6rAI8EMtqqEyhSHmj/VS5tDgBzqI66O66z0DZtMaBdD6J4S/ZJwexm5pQy4GHABgzMEPrzdgtX/dmDKJCtenmLj3s0FoIdMlsno3vr4k+D69usHh8NRawPes6f+MNj4+EZ455138PnnnyMtLbyWnSCB995/j3v27Bl1tJXX6x026+uvL/tfYuh/lk7Yrl271llZWfcejzm+uKQEd991N2b/OBuvvvoqunXrViXaVBqNAMKA/gPw888/47///S+eeuopzsrKOurWn5eXd9TrKgI4v6UamgeIEFQE8coRgAQ4AFzWwQJdAhUmw6UDJV5GsZ+hqYTuCQKGrD7fAEgRhFgbQZcCKfbAqHluRrmfKVarweRRO3W4WsBn1AgvqT6Zqo1AGhFGNlOwIie6tCWXF/hmqYEuF1gAN8A6QDrQPk7gnRttgAGCm8OjOyWhTdrx645t2tZ2HW3cuKl6Mz8K8N9951307dunTsl40W+LUFBQGPXNSSlRWlExtXv37j9v2rQp73+Bo/9JJBYRQff53vB4vQP/zDhZWVn4avp02O0O7tOnDxRFoZqiohACPXv2xMUXX0zM4I0bN9CxBrRX6U3JAo/3tEEJhksqFIyMUgGhBH4rSkCuMQVgEkOqBKkAhgKYga0edpXQyCaQGiM4I56oeSxBo4C7SQFVWY4FgB6NFQxNVxGnEVgCiTECCU6Bwc1UOAWFMH6OkJgYSfcFmELAXGmpJoIAo4KB6buNqOfE5QWuOV2DkCHhIkwgnQMbXYg6wRQAcFIsoW0bFWMHa5gw1ILxgzWMGaCieZqCLZnmUX3FmZmZ6NatO7dp07rqgf4zbRqvXLWyTuBNmTIFn37yCVq3blU9X1WbPeDz+fD008/g1ltvpZKSYwv0kFLGezwe9vl8C/4nWPpfXDQ1NXVQYUHhIlOalhM0JA8dOpRefvll7tevH1HE4P4ArVmzBo8++ijmzZt3zBd5ZIAVz/S2wfRLFOvAIa/E/nKJHBcj28PI8Ur4/AGXUaEf8EvA4GpRVgBQiRCnAUk2gtNKcFiAdAch1SqQ5iQ0sxKSrQIJFkKMwhCCAsiXDJbBpxGBwA5mBP29ocIA1+C6XGWprflReLIHQxWEnX6J3jPdcOvRSUZ2K2HDB060TxRgoyp0JOQyXEMWCALHRuEpkMSAXWDEHRVYvO7oG4jdbsfL/3oZU24JhCcPGTIUy5YtrXVckyZN8Morr+Diiy8OWw6hiSyZmVmYcsvNmD9v/vGLsapamp6e3i8zM/MvTzv8y0VoZia73f7osYJXUVXExcYiJjYWaampsFqtSExMQkZGC8TExFJ6ejpcLhdM02RVUak64oiDFS0C66Vv3774+eef8Mmnn2LKzVNQnfhQ/07nMoA7VniwuUBiT4nEEbcMD2E8EUYJAhKshEY2QkYcoXWcgq6JhM4JClo4BJpagbigHxgmw+RqMxWF/Z/C3CzV8x+6dYeHWEpmNLMSmsUQdhdHB2CPj7Fos8ntRwuCUV05JHQbQQ27NwMgb9AFxwHwEjH2F5nYub/+CfV4PLjl1lv4UE4ObrrpRtq1a2etnXrs2LH85ptvUrt27cKMixwi4cyZMwc333zzccVH13Arxefn5z9ARNf/1RFafzmAU1NTx/r9/nHRHv/YY49h+PDhSEhMRLOmTWGz2RAbFwdFiHolCiJE1P2EUKD79WPKDWUAr62tDXYhAtw01kpo7iTEWAQcKqOpXSDeQlDUakYjg5FYJTqjTAfK/MwlPqbDbobXzyjyMXwGUOhlFHoZe0uAhahe0E4LoUUsoUeygqFpCgakqegQA8QpATCzCZhcGRlGtcBblVhRS1mmYKlKhlMhdEhQsLs4+sy5+etMuvEMS/UGQqiORgtV0kPeBVcZ0IIL3kF4+kMfcgujBgA9++wzmDFjOgoKCiiEG+KBBx/AY48+RlartdZzUgBweO655/DsM8/Cr/tPyLp2u92XpqWl/fvIkSNr/s+K0DMmzVCu+OGKX30+34hojh88eAiWLFkMIaKzjNbM8QWHxAaHiIv79+9H//796zVa1drtFKB1nEC3ZAU9UxR0ihdoGUtoaic4FEKMAJRQplZXDmMIa9KZ4ZIEn8nI8zOKfYzd5YwcF2NXqcT+UomsssjcXlWAto0UjGymYGwLFYMTCamWgDXblJUQ4TCDVSQxMpRDahrh/g3HFht939U2vHSZFXAxOFSArpqLmoElXGUDJ2bAQZixSsfFj3vAfyLjtlWrVnj9jddx9oSz6zwmOzsbt956K//444/1rv/x48cjJ+cwNm7cENX1HXbHTI/XM/mv5MJ/KYCTk5PPLCoqmi2lrPe6Qgj++eefaezYseEIjVSp8Rjpqquuwqeffhr18f2aKDi/tYrRTVV0jBGIVQPGGMjqhIXKP2u9O6o+JtQWzKGunyBbFKEAD5oXTQDFfuCQT2JriYlV+RIb8kxsK5LId4dfrGksYXS6hkvbahieJOAggHUOCfes/fZrTqOqAv/OMjBloSequbn9chteuVyD4gvfm2qo2iGgrnZfMQBSgCw3Y+htLuTkHf/CP+ecc/jdd99F06ZNqQ7zB+bOm4dbpkxBVlZW3aqaouD0M87AnXfcgXHjxmHRokUYc/rpMI36DXuqqvqapDcZmp2Z/Zdx4b9MhGZm4XDY740GvABw/vnnU6gPt8r4gbA8edTh0IHP54PL5YJhmtD9fhQVF6OkuBibt2zB559/HhX8BzRRcH8fK85MU2ALokmaDMMMsQkxwMRBfZtqb41hoiPXBhBXl9uptr5y0GQdGDEJjGQboUcTFZc2J5jEOOIDNpZI/HrYxKJsAxvzTeSUM/671Y//bvWjb2MF13XWMDldQ6ICSL2ymF6EHTzMzQO0jqn/FREBD19nx1OXWCBcsqrmF4dYnakytZKoBpqrQexXgdve9FaBV9EE2gxJxOHt5SjPrS0FkCC0H5kMW6yKzGVFKM8PHFNeXo74+PiIrMnv9+P555/Hc889V6fNw2q14pxzzsFtt92G4cOHV30+cuRInHvOufj222+i0YWtxUeK7yKiy/8qLvyXceC0tLRRBQX5v5imrNd1JYTAF198gYsuuigCNKtp546d/Nnnn1FFhQuapnJBQQEOHDhAfr8fJSUlKCgogK7rwWqH7qgNVg6N8HA/K+7uqMHBgGkwJIWHTIJq8hqKLMtzdbAEo0YlDUaEqK06Pgt7aQxBBBIBTu1jwoZSEz8cMPBjloHN+dWydrsEBbd0t+Ca1iriCTB1BguqQ8sHVALWuhn9v3bV6c7RNOD1e2yYcrolKDZXAhbVWSGVtatCKwuFVgsKih8+FTjjEQ8Wrw9wuA6jUzDg0uYoy/NiyXv7UbjPHXbtdiOSMeCy5pAG4KswsGTaPuTtClTfuPbaa/Cf/3xYy+10yy231Ol1iIuLwwUXXIBbbrkFffv2jaiSrVi5kkeOGEHRrB9FUdxNkpMHHMzN3fJX4Oov8QMTEaRhvOrX9c5RcmssWLCAi4uL0bdvX7Lb7RG3mri4ONJ1Hf/97FPMnDkTGzZsoKysLBw4cAB5eXmoqKiA2+2G1+uFaUZnLm4ZL/DlWAeuylCh6IARTJ4Nd81QldgbymHDV2cNC3AwS6nq/KrC7RRS0C7c7RLZmFZtaQ6UkgUUCbSwEEY3UXBlBw0DmikoNwhZpRIFHsa8/QZ+OmQiJV6ga4ICIQMW58oiehxStpYAeED4eKcOX4Qps1mB9x5y4IZRFqCCQ4PPaqr31XtYiAGNahjOVEEY2FvFjEU63B4gtZ0TqW2dABPSe8fj0KYy+F1m1Xh9JjeDZlWg+xhCE2jRPR6HNpfC5zKxfv0GpKWloV+/fgCA7777DhdffBHWratdtD8xMRHXX3893nvvPVx//fVVhRDD0j0qn0kI+uD996OqWsrMmsEMwzB+/j8D4IyMjF4lJSUvSOaor+f1emnp0qU0e/ZPaN6iOXfo0IFqcjdFUdCuXTtcc801aNasGa1du7aqFtLxUI8UBT+MtaNfjICuc0gVWAo3yFAkbS/UfRO5uBwFgV8tUHMEGzmFn8vhpuMa1aOrjpQIxFpbJNAxVsElrVWMbKmiSAd2FkvkuRgzd+vY5WEMaKqikQIEtJmQsjvBAU0F+HCnjvIIBtqB3VW8cYcVqAg6izjolpEhgSGVi5/Dg0mIUfs5JSMlkZDWWMF3v+soz/OjRc94qBYB1apwo+Y22r+mBGDAGqOi67i06jmQgMWhoFEzG/atChyz6LdF6NK1Cz799FPccccdKCkpDbv/Jk2a8J133ol33/03Lr30UqSkpFBNMY9qTO5rr76KuXPnHou62LZVq1ZfFBcXl/39AUwEaZqPeY8z6io/Pw/Tv5qOPXv2Us+ePZCQmFhr8Qoh0LdvX1xwwQUoLS3Fpk2bcKw6SL8mCn4eZ0eGQwASgYioyrxeprCo4khW3FCIURQaCldx4vDPqstEc4jfpx7th0KL5lCgC4EJtLIRLm6joXcTFTtKJI64GFsKTMw+YKBLqopWDoJkrtYGgqPqBLy/y0BZhFpZ5W6GpgEeBlgF/CqBBMEiQm2MdNS80Op6AkEoGoTubRXszGNs3KajLNeL1v0TYfhNimtiQ0W+HyWHvIhvbEO74cmQZsAeQgRIgxHX2IribA/Kcn3QdR3Tp0/HkiVLwtZA+/bt8MCDD+Htt96ic889lxISEqha4K8MQAmVjALn5eXl4YYbbkB5efmxANju9/vz/X7/H397AHfv3j31yJEjb0gpY/7MNrBp0ybMmDEDFquVe/ToQZpa2/7WqFEjTJw4Ef3798eWLVuRm3sk6gukxyo44JJYVcQ44geKTMAQATOfphI0QVBCCsopFAi6EEQAB0XQyhDFekxk4YEWoWJ15drhCNyYam0OlZ8Qaha1C5xncsDw1ilW4NJ2Gmx2wqpciVwX4+cDBq7oYEG8Eh6ESQD8YLy300BpBAB7fcD8lSY+navjw3kG/j1Hx1eLdYwdrCLRLsL2m2qEhHaVoCq1KlROJZMxrL+KWUsNZO/1QbEINO4YA9MvEd/Yhr1Li5CU4UDLfomQuqw0aAbiMohgi1eRtaq4lkW5d+/emPrUVLz22us47bTTEBsbW+e7qL0BA6+99hq+//774zDayhYdO3b8OD8/339S+ePJBnBSUtKUoqKiY+kxU6+FeMjgwfz8Cy/Q0KFD6zymrKwMb7/9Nl544XmUlpYd18Q4LIRkG5DoEGjpJCQ7BFrHEBo7Cc1shDS7QIwKJFkICgEOEeIKqvIDc1XzMg4Wm5NBjh5qBwsHNde4E0Zk83a12M5ViYQIC4+sMgwCEBrh9yLGrX94IE3Gb2c6kSIYJsJd1GUC6PmdGwdKonPKKgqwYVoMuiZRwL0Wcl2uw2dFhJBcuKBxzynwzWoDFz3sAmkC4x9uD1uMCtWmYPF7WbDFqBhwWQv43TIsSAdBd9TcF3ai7Ei1oem6667Du+++W6vAXSTasWMH2rVvHxYgVFRcjJ49eiA7O/uY148QhEaNEi4sKir65mTi66S6kWbMmKFcceUVV0YL3gcffBCJiYn44INpvHv3rjpBvHTZMjr99NNx6y234v4H7kdqampE6+I1117Lr732GgHHDmAG4PIzXH5gf5mJ9ZEmTwGcKiHRRrBbCOkOQqxNIMMJNHYIODVChoMQZyE0sjBSrQIKAKfCsAiqBjDXbKdSDfhQkggNRwkNnAyJcWIOMbBVi4ISDOlnjGhEWHKWA4bJSAoWmVOIQm1tsCmAIIra0940hdA8CVXZWOCgkU8EVYKqAvTB7UUQTBUo9jK8egDMdgugeBitmhE7HETlFRJleX44Gllg+iW6ndUYZbk+mEbtu2IwVE2gSec4lB3Jr/p82bKl8Ho94QCuofssWbIEzz73HJ838TxU2VmC9Plnnx0XeBG0R3jd3quI6JuT6VI6qRy4adOmg3Jzjyw2TVnvRpGWloat27YhKTERZWVlmD9vHj759FP8+uuv8HjqDipo27YtnnxyKi699BLULHFy881T8N57//5Tz2CzWdEqIwMlZeXs8/uouKQUXG3RjnqRO1Qg1kawKoQmdiDeJpBiJTSPEXBYgAwnIcUWyBW2ESPFSohRqsVQmyDEasHODhza44yCjCxEiWWq5mohzK+yE0RlV1MdgWQLlwT8JmBKCZfByPIB1/7iRZ47Og48uKeKJc87ILwhC9VOOOIGYi2AkwMBJZW6ukdlXPSiFyu3mjD0gCSiWQISgquMUVrBEArhzEc7wBEfKF0kgrq2qXNtcZcBYQFytpRhyQf7wu7ttddfw5133FmbCSxdipdfeQU/fP892rRpi/Xr14XlGQc9IJyZmXncGFEUxdWiRYs++/bt2/m35MDlZWWXRgNeAJg8eRInJSZSJfe8cNIkXDhpEjZv3oyPPvwQ02fMQE5OTq3z9uzZg8svvwwzZkznZ555Bt26dSMA2LxpEz799JM//QzdOnXkX2d8SH7dB4/Hi8MFJXD7fLx7zz4UlpVj995MFJWUYf+BgygpL0dJSSnKyitgGAZC4wLdBuCuCMjVB0or+Wndu6o9qHtTUN+OVQmJVsCiBpRkQSCFAjWhYxSCPRhzrYkAoCUYugkYkmEw4JGAxwhkSDEzTBnIaNIZKPYxXEag8IDfZHiMY5ujjukCotKwJwA4CP/8UcfLn/vQupnAN486uIUtWFFeIezOk5i9RK8dtRbccRLS7eh0egpiki0wfBw0hAZ3m8q9qUaMN0vAmVQ7P+b1117nq6+6huLjAwXi//jjD379jTfw/XffQdd1AoBHH32kVpGA/372GSKB1+FwwOGwo6CgsN55MU3TWVRUdCGAZ/92HLhPnz7xmzZt2qjrekZ9x1osFvyxdCn369uXOCRPM5Ryc3MxfcYMfPLxxxH9egHgx+P2227FlFtuwSOPPIJPPvnzAD73zLH47oOXAE9FYHUqQbYolEAmQ5Db+Xw6/AajuLQUJR4fyivc2J99CF6/juyDh3AwtxA+nzcA9AoXez1uKigshtfnZylN8oZLGYxTvHNkKD16vQ1PT7IETNOxAlO/9OLJadW66NkjNHz7iAOqhwEN+H6riYn/qF0bXaiEfhc3R6sBCYFNxl/Xkq1tMSDBcBX5Mee5XVX1syrp7bffRpcuXfDiiy9i/vz5CK111qNHDyxfvhx2u71q3JKSEvTp0weZmdWdRVNSUnDZZZfxtddeS1n7snDuOedGNTcWi2XdueeeO2jmzJknxZh10jjw/r17hxmGkRHNsf369Ue/vn2DEiFVhRbUFLHvuP123HzTTZg/fz4+/PBDnjt3LoWK12VlpXj2uef4/Q8+QElJyQnZoJwxMQziQN1lkuBgJUoiPYRpMDQiaAKITYpFOsUBJDCke5sgSwKgqIBkmLoOk4m8Pj9KyyvYL5kMw8SRI7koqvCwISWVFJdQXmERl1S4STLD7XIjNzcfhSWlCNR/DhjDTF2HX9dh6Ab8uh+GYYKEALMEgaAoAoqiwG6zQVFVqKoKEgF/j82iITE+DkkJ8bDHOANFy+02tMpowcUuL/7xyJMwDCOq+WucIAL5vQowdXoAvLGpVnQenYx13x3Gj7/reKevn+8YbyEYwM7syNKHUAhNu8QGOjuajFrZH5VGwZr+O4Q6oGuPe++997Jf95M0a1/3/vvvD4A3RDf+6MOPqsCbnp6Oa6+7jq+9+mpqEewE0aFDB+4/YACtWrmy3rkxDLP7smXLegNY8bcBMBHBpevnR6u8b9y4ARMmTMC1116LsWeMJWeM86jcesKECZgwYQJt3LQJ//30U8yYPoOzD1aVgKX8/PwT9SicmhAfkDUr107NzASq9BMHDCRm5bFkBipS1AisouCkxyiMuERnlfWoQ7PEgOkSCIC+0tFZGaFlykDJIKFABiVJKSUM04RpSpjShDRlVf9csASRgCIIFk2DUBQIIapK3rGUIEEBKYICx4MZUBTatCubzRpxlLY4FZ3PSGW/26TdvxfA56oO0/p4nh/pbQW++dmPT74PMJqOo5LR5cw0WONULH5/Px5+10td0hWM7qdgT3bkqDjDJ1FR4EdCc0ewPFINlNb4N1f6yTkwXaaPgxtsDdeX1xtxI+rfvz8uuOCCELM4cPjwYbz0r5fQpUsX3HjjTbjkkourgz2CSrfFYqFHHn4YEydOrDfeQEpTLSsrO/dkAfik+IH79+8fl3Po0EtSyvhojvf7/di9ezdmzJiB776fxWVlZdS8eXMkJCQcfedPS8MZZ5yBK668gtq0bctFRUWUl5cXddhkNHT+hLEY0rsLcXjzoWorMNWtkYTLwaGFbzhoVGKwDP6YEmwYYMMEmwakrkPqOtjvB+t+sGmADQMw/GDDDxh+kDSgsgmVJKwKYFUFrCKgF1f+rQmA2ACZOmD4wIYf0tAB0wQbgeuw7gf7dbBhQABYu2UPff7ND1UPJFTC8Cmt0WZAIqW1i0GLnvHI3V0Bb3lAFM3Jlfhyth8bd1bPUacxKdCsChKb2+D3mDi8y43f1huwxBJ//L2fyiJ0F1KtAp3PSIWiBqWW0EbAtWI2w8NYhSJQfMiD/WtKouUyeOedd9GlS3h075I//sDgIYPx6quvYujQoXA6nRFfb4cOHbDg1wXRFgNwXnfddR+uXbv2hLcnPSlVKbOz9w0wTbPF8Zy7bdt2evjhh9GnTx9cd911WL5sOY5aABKB7u833Xgj/fHHH7jsshNbJNAWatyo0Z+XjnpXNSW68IwkOppJgmucS+GVpxHifZLBjUAGNwLJAReGrPw7mO1UXXKWEJ4XxbWcuocKisNuMaWNE6ltYuApNeCrMOFIsGDU7W2Q0MJe98JSA5zd55boMaExkts4kJ0rcduzHjqYy0hu7cDga9JhcVTzkFYDE+BopAW5GoVILRQSvRWS0Ayu6sNMCqHogDvq9zp82DA+88zxtT4/c/x4XHnFlbWMWjWn6fffF8Pjji7l0jTNLrNnz+5yMrB2UgBcXu4eF03aYGJCIkaNGoWkpKRa3xUXF+PDDz/EsOHDMGbMGHz++ecoKyurhaWQcHp4PB6sWHlCJRXiGh39jo5ZioDFyCLWMXkG6yoOUIP7c7Rjhf1Zs18SweUKZ4+JLR1hu4rpZ1jsCkZMaYX4JpFrb/vdRsAYyYGNY9j1LZHa3gmhEpLbODH42gy07J+AEbe2QuMusWgzNBHdz20SsDojXMetdIFVxW1TpaGTqjc0yTi8Pbo4eBLEDz30EFRVrXeyQksQ+f1+zPpuFk4//XSMGjUKa9eujep60pSW8vLyMX8LAN94442aruujojl25KiRWLhwITZt2oR58+Zh6tSpaNasWc3dCwt//RWXX345+vXvj2eeeQYHDuwPWbbVL3vu3LnYtnXbCTbTh3JOrgd6lfoxQ5CA4nRAqSsKiKO+gXAU16g4Ep5ny0c321WlKnKNygMh0VNCYOeezLDTNJsI28EYARBbnSqGT2kJR2LtZyzL9YOUYNaUydBsKkbe0hrjH22Pkbe1gs2pwldhIqGpHSOntEa/i1rUbgmDEK5LXGM/46rvFI1QlO1G0f7oOPBZZ55FY8eOpbpeRlj6CQVyjT/55BMMGTIE5593PhYsWAA+htIhDIah62NORiuWEw7g2bNntzYMo2M0x3bv3h0A0LRpU5xxxhl4/PHH0bt37zqP37VzJx577DH07t2Hb7jhBixevBgyxNjy0UcfnfAJCuOgTNVBEhG13koblEB+hRf3v/BvrNi+D4rNdrQqr0dhq6EphlQlOlYmz9dZ0iDi7hCSRRXa9aymbimBvMLwmGLDK2vfW5ATOxtZMPT6ltAc4eaUgixXmL4pZaBmlzPeAjIDfl0K+ncNr4Thk0fZ1Kg6njr43CQoUMpXEBSLwI6F+bXcRxEXvBB48MEHa7gqKeKeeSQ3F6+88gr69+/PV199dViztWMl3TB6d+rUqfEpD2CXyzVYSmmP5tg+ffqELaKSkuJabVMiUWFhIU2bNg0jR47EqFGj8Pnnn2PVqlVYvHjxybCp11joIS07OfLeLSwaVm3ZiZfe+Dcm3XA39uQUQNHUmiUao5CVuZZAD1CEmOnqe1QUBYozBorNWqsrQ30CAAXFxL1Z+8M+Lznsg4yg34MAw89ITHdg6PUZUCwiBMBu+L1mwNIdck0pq9Of6zQA1ppyBomAkUt1KIBgeCsMlOX7UF7kQ9aaYhzcUBrdhsyM0pKjG7p2796NBx98EH379sW9996LHTt21JrARvGNcNppp2H8+PFRyVOmaabk5eX1PaXdSEQEv98YFY37yBkTg86du4S9sB07dkaMtjray1i8eDEWL17MTqeTaupuJ4IBcy0ARco24qArKRADzLqB3l06oF2b1ti9NxNX3/UoZn/8OuJUAZYyTDKs2Vkh9NnCuQSHF4ej2itdsVmRXViGJ554Bf16dsNNF44DV3UsCC82F1ZQoLJuNQmUu3woKioKB3C2G4ZPVkVbhTYJZwJ0r4nG7WMx6IoWWPbxAUiT4SnRUZjlQlr72PDwxwjF9ALjBGOoQ/ROClrAFU2gotCP3PXlOLytHMXZHnhKdZi6PGaDAjPjk08/xZlnnVXru9WrV+P999/HzJkzUVoaeUMYNmwYbrnlVgwaOBAZLTOwYcMGzJ07t153EjPD4/EMBzD7lOXAV155pU1Kf/9ojm3Xth1atGgeJvCtW78+TCQ+lr3jJIA3MPGVTbJq9gnj2mJr5bo0pYmmSbF478UnYbfbsXTFKvzz3U8h7PZqjliDidaya1PNv0MrPYYENQR/K1Yrth3IxdlX3Y6PPpuOT6Z/Bwg1aObhcJ25qpthiCmLGaQI5JeUIq9GmKC7WEfhfheEVpkuSWF+bUEE3SuR3icB/S9rXsV1968tgVCpqqxQZLdbiIRAoRU+CJpDQWm+F8s/3Y85z+7Aqs+ykb2uBBX5Pph+Wb9Jog6aM3cusrKyGAhIHD/88AOfddZZPGTIEEybNq1O8ALAJZdcgosvvggZLQMxSk2aNIlohI1EhjQGM/MJVYRPKAdetGhRK8OU6dEc27NnD2iaFpYUtjbYbPtUosLC4oAJq7K2FVNg26uZSRRcTYqiAlYrIE2MGtQDrzz9CB58+sUQfs4RpcaITcciybscUlSn0u6kKNh9KB8TrrgFWfv2IzU1Ff96/B8QUq+uSFkXh6jqHEGAUJB9ODdin6E9iwrRpGMcTL9ZrYsGJZJKbux3mWg1IAmkCKz67ACy15Wi+9l+WOxq2N5Ty8oQVvQuEJHFBGz4/jB2/ppX1QkyMSkJwwb2w6B+vZCWGAi39JoSS1eswS+//Y68/ILovCRlZXj1tVepS+cumDZtGq9ZsyZqUC39YymmTJlS9e+kpCS0bNmSCgrqv7Y0ZOeuXbs2B5B9SgLY43L15Cj131oFxADcdffdGDBwIFYsX44NGzdyZmYmSktL/6cxwYfzCwORUZV4UQlsmIGsAKsa8HcaAalBsVqxIzsX8/5YhcZJjTDxtMG4edJ4jBvWF2kJ8ZDBsM+qiMBQL04ttHKEvF6qjQBmkEXjtz/9Gln79lPrVq3wxb//hQGdW8H0eCLI5kFOx1SDGzKgCOzedyiiOHhoSxnyM11IauGA1AP+10qjNlWV5WHoHhMt+yXAHqdi2Yf7kbm8GF3HpgWMVLUFZ9TALoRK8Hsllv4nC/m7A1JV61YZuOnqyzD5rNFomZaEQBV7EJgBITBl8pk4mFeEt//7Nd5476OwdqR10ZtvvHlUc2JdtG79Onh9Ptis1gCAVBXdunWLysBlmmZCQUFBj1MWwG6vt6+M0hLYs2fPWp9369YN3bp1w4033gjTMOnQ4UPYsnkLVq9ejXXr1mHjxo04ePAgTNP8y4L9XV4fVfbuYYXg21YII7Mc0CVgV2Hp0AiW1vFQSGDNzn0484opyM8LhHLec8sNePnBW9AyuRGklFUSLKF2rfMIKAspvUVhTC8sOIQY7DfoorNOg1VTcONlF6JN62aAV4ficIK9HpimrD4nmJZXdRmjuiQASMGWXXsjM2rJ2Dgrh0ff3ZY4GCJaVVUjhMMTAbrbRFq7GJx+bzvk7i6Hacjqsrs1RWiuFp0VRcDnNvD7O5koORjY7Jo1a4qF336KjMbxgNsD0+MKSOQU3n+pebwd/7z/Jpw+fBAuu/leHMnNPSnrYcf27di/bx86dOhQ9VmPHj2iOldKCY/H0/NE6sEnDMBEBNM0e0VzbGJiEsJ61iB8HRABiqogvUU60luk48wzzwQAlJaWIjMzE5s2baKly5byxg0baefOnUfVWf7sY5WVljLrJpEq4FmTFwCvKgABkMdg78pcgmQ4ejTFv//7Nefn5Vct0U+mf4N/XHcJGsfbq+o/U1hRrcq5ExDBHV36vMGgBa6yKsNqBXz+YIhoaDG8APhMw8CgLm0wqGdngIBZP/3GH07/njq1b41Hbr4SsVrQeKYK6DkV0PeXMwuQ2tgJS3oMYAZDig0Tu2r4gEMpf6+Lts7NRdczG0N3m0BIH4bq/lMB45vulbDHa2g1MAmmX1Zze64WPapz/AN7pCkZf3ywDyUHPRAi4JY6fPgIvpo1mx+46TIyDFkVeRV2PigwN+VlOK1/N0yf9jrOvfJmlBSXnLCFEBsbi6ZNm6J9+w5VobqV1+/WrVvUDMU0zB5EhBOV5H/CADx8+PBGy5cvbxfNsW3btUVScnIE3Q8hL6im+keIj49Hr1690KtXL1x11VXEzLjyqqvw2X//e9I48MGcI+SHCT7ihpFVDrKqCK0WSRYFvl0lcHRpAkUJL7gsSEAoooazp1p0rNz4yg3GlIemok3LdDx95/WQXncgr8Bqwb7cIsz8+RecM3oY2jVLA5tGrYhrIsAwTKikY8mm3bjoxrtJ13XMnguUlpbj30/fBxhe+HYWw7u+AJXmbWNvOYy8eDj6pkJIoKTcg92Z+446H1vn5CKlbQzS2jqhB8XiKuDWuCcpGfCHfx4a3lxZwI+ZodkEVn1+EIVZLiiKgvde/ScKior4wSefp6kvvUUjBvbDwC6tYfh8Ia1ZatYFJZiuCgzv1wWP3Xs77n306WOyVwIgTdOQlpaGli1bomvXrujeowc6tG+PVq1aoWmTJrDabLWYTps2bSg2NjaqwneGaXS98MIL7TNnzvScUgDen5OTIaVMi+bYPr17V9UeilxWNcK/IuxxpjSxdevWkypCl1VUsNfQScv3VHUugKiU3wKdTKXPBLs9uPbi8zDzhzkoLg4EQlx/xUVITYyD6fVWWZ5rloIXioL9Bw7jy6+/BwBOS0nFbVefTzB1HMwrw3k33scbNm6iHXsP4D8vPAyjoiKkHlRomCcDmoYFS1eHNW37acHvXP7Q7eTUdfg2F0JY1KoSN6QJGJmlMFrGQU1zYv+BIzhcj+gpTcaKT/dj9D1tYY/TIPXaEV0h1bOBCNtXmFuOCapFIGdbGTKXBazfD95xM1836QzSfSbNW7gEvy1ein88/TJ++fJdWARVZxxRSKBWaL3pinLcMOksfPDpl7xj1546OaPFYkHLjAx079GDO3fujC5dunDHjh2pWfPmSApWP42G0tLS0KJFC2zbVn8UoGmazTZu3NgYQNYpBeCywsLWpmlq0Rzbr1+4pyknJwdPPPEEenTvjj59+6Jjx45ISEgIh2yE15Bz6BD27NlzUgGcl19ApSVepCcnQnMGyrxLNmGwhIQES4YQAoY0MaBTK/z+9YeY/8cqtGzWBOeeNgiyqpp/iK4ZZpk00Kl1M1xz+UX46LPpdM+jT6GwuBhdu3TAMy+9iQ2btpDVasX548cAur92il2ICAvDRO8u7cPGb53egmx2K/SDpQG93Sqq2zUxgxgw871A80bYunsPdH/9eefuIh1/vLcPp93WBqpdCfhjQwpL1zbI1ZQZuMoVRcG2NFt+DGwcg/v3xSO3XkWywgVN0/DCQ3dh5Jr1+GP5Srz9329w73WTYZZXhIG3ZpqhlEBsjA3XXHIhPTD1+TqfY/To0fj666/hcDgoCuZc57c2mw0tW7aMCsDMMra0tLTlKQdgv9/fMRqxXlVVdO/eLeyzTZs2Ytq0aVXvukXzFty5c2f07NmT+/fvT7169USzZs1hsVhqnLcZ5WUnt3a2x+3GA/98g5OdTtjdAu0apXCb5DRqmZTGKY4YshmAbGKBYhUwvD50y2iKbu0mASxh+vwRgi6r9dtKd6xiGnjj8btRXu7C19/PxpPPv1K18hs3TsObzz2Gs0b0ZdPtpoiW6Mrd3efDhOH98Mozj+I/X3yDFs2a4sWH74CFTLhNWZWCV53RTMQMkBbIC/5j5fqo56U424OFb+7FsCmt4IjXYHplBD9RTUE3KF5XSiMciK46uLm0KpPozhuvYbtNI8OlQ/r86NetHa69/CK89f5H/Nwrb9OZIwejU/NkmLoRYW8I8Zd7fTh7zHBMfemNOq3Sh3JyYLFoUeCW6gV2p86d8PPP9TdjkJJhGEZ7AL+dMgAOKuXto/GqN2nSlFu3bh02IytXrgqbk+zsbMrOzq7qZxMbG4uMjAx07dYNffv0wcCBA9G5cxds3LDhpFuhmRlffTOr1htMjU+gds3TMapnL5w7eSz6iiYQNsD0+8GeYCZOxBSiGuIfAJYSMYrAZ69OxYhB/TBz9jxyud0Y0q83br9qErdtnkpHAy9ztcOJdD/uvvI83HLRObAoCkjqML0+qEk2+MDBhmPBcUwG2VVY0mNg+k1s2LK9znmwxqqISbLAU2bAXewHGCg+6MGCf+3GsBtaIbmVA36PrOFv5tqLnWu0HiVgz9LqwJEPv/yGzhzRD05FwJQS7PXgoSlX4vuf51P2wUO464kX8cN/XoFFyOqgn7AaLoEdSpoG2jZLRft2bbBh4+aIz5SVlYVDh3KQkZER5rQ7mtRXVlqG7IMHkZGRjpiY6lLn3bp2i3o9+f3+VifMynqCFjlZrdZFfr9/eH3Hjhk9hn9Z8EvYdSdMOJt/+mn2Md1Ls2bN2OPxUM2wv5NBIi4ZSkpLsN8LWZYPWVEEmNV6psVq4VGDB+GWay+j8UP7QiMTpt8fofdZdUBIVVRSWK1kgrDZAEkwASgCgN8H0zBrtHOJwAhq8DkK1Y0BCIuAsbMU5s6yoC2JQA6NLP2TgcZO5OWVc+eRE6mwuLjW8EmtHBg2pRVsDhWGX8JV6Ed+lgu5OyqQv9cF3W2g61mN0W5YUlUKYQT/QlUxutC0aq/LwJynd0AagN1mhcvtwdWXTuJpzz9M5HVDMkO12zHzl2W46IY7wVLy0w/fi0dvuZxMt/sonaQYij0Gl90zFV/MnFXnu/3llwU8ZsxoiiBRIi8vD5mZe7Fly1besmULduzYQXv27EFeXh7P/uknGjN6dNXxq1avwuBBg9k0zXrXsdPp+Mbt9lx4IizRJ4QDj+zSxcmMqCKwunfvHvaAXq8P27dvO+aN5NChQ39ZgIdIzIA2/h6wHqhoQZ5yoPAg9INbYGZvhL8sn+b99jvm/fY7Ro0YhqfuuxVDe3WC6XGF1UOuVFWr0MbhzQgZDNPjCaYrBAqu17bk1RGbUbMTIAKuOFisgCmRV1yG/VyGQ7Y89uaXkNvlhdcuIOcQrJoFh/LzEQm8ANB6cBLsMRp0twkiIC7FivgmNrQbkgS/10TJQQ8KstxwFeuITbbWKGsTkkkV8hzMgGoRKM52w/BLpKYk4/V/TsVNdz+Ij7+YSSnJSXjx/pvBHhdMrweTzhiKDXdN4RfffJ+27doTXkU3ZIOonuBA64ymTY6eALRxwwYaOnQIcnJysG37NmzatAlbNm/B1q1bceDAgbpqq9HWrVsRCuBWLVshMTExqnJOumE0llIKIpKnBIBdDkcCc3Tlc76d9S0XFBag/4D+1LZNW/j9fhw8eBCnMsmSHJiuskDdKEGQ9lhQejcoLXtD0d2Qh3aAt/8G48BG/Pb7Epy+cjUevfd2PHjjJRCGH9I0q/sehfQ7qh0bHIbtGlbccDjU5LahXygWDVAt2Jp5AD/9thy/LVmOjVu3Iy8vH2bdhRbq3BA1uxIIZwzqraaJQPQZAQICSS2dSG0bA9OQkAbX2X+dQ7RgIBAyWZAV0E9bNGuKi88ZDb/3MVx9+4N46Y1/c7O0ZNx5zSQyKyogPW48ffvVNOmsMWiekgDp89QIKY2gbzNDU49eNeqlf72Eaf/5D7KzD+BY4uk31MiaS05ORseOHTg/P79exsISTXr06GEH4DolAHzo0KFUZm4UzbH79u2jffv24dNPPw28RKFASvOUBjCXFwDuYsCZCEBCMAdEaFMHQFAyugMte0LN2Ql95XR48zLx6LMvYf+hw3jnqXshZM2QxuqOg3WJgFTFk8OLmIdVVwvrzRAo2C6cMVi9ZTde+eC/+GHOL+EGHM0OEdeIyR4DCAtVVYcnQOZmgn2RjT1F+93I6N2ouswrh/phGWwAbNQs0lM74KRG0BaYgYpgg+7WrVoCfi+uPHcMZx24HU+++DrdP/VFJCUl8eUTRpHhcoH8fvRs1QQcLORX7X3mmh1nqnZHQUfP18nNzUXucURt7c3ci0CDV1FZTRX9+w/AkiX19zOT0owxDCP2lAEwmWZCNCV06ngYnOrEpg7Oy4JomxKMew4NZJaBQnNgoEk7aOc8DFr9NYyNc/HBx5+hReNUPHbblTBdrrAugooQ1bWlRYiIyaGrnANrhGWw3pUMKfoRkm5IDFVR4CcNT7/+EV5+6314PAEwKo3bQW3VB9S4HSgmGWR1EIQCWWl8JAEBhm/6wzDrAPChjaXoflbjqn7CQGhdg/D2p6FW9soo0LC8p5BDKtMOAcBhdzCYyXS78PhtV1JObgG//8nndP1dD5GmvsiTxwwi0++DoZu1gkbCbQsUMNQFE459hnFS1kRW1j54PD6y2+0oLStFXiB8NioMCCHiTdNMAXDklAAwVLXFiQwPOyVBnLMN1H4QGH6ARIjbMygOMoF1XyANbvClLBQL+df9gOdeewdnjRmG3p1aVYHP59VxpKSMC0rKcOhIPnkMCb/XA1d5BQzTZKfTTnaHA6qqoklyIpISG3FijJPiY+xQNCXQ1VvXIU0JBkNRFJQYAtf/43F888NPAeC26gOt99mgpIyA6GuaYGmCpQGYRnU7NKFAluXCLK17LZXn+bB3eRG3H55MusesYTELF+apShUN5vdGapUc3HykZBj+gBpo0ZSANZmJ2OfDa0/cQ0VlFfh61veY//syumj8cJDPj0i+5VALMoUGmsv6k/ePl/Jyc3H55ZejsLCQ9+3bT/n5+XC7o2OopmlaDh8+bD8h0DsRgxQUFMQeZx7v34aMnB1Q/B4wiTDhsNp+wlXBDNLrIqXv+VDyMtl7cAs9/9Z/cOdN12H5ylVYvXELduzei5wjuSgpKaVgl4BaKm0o2ex2pCUloknjNHTt1A4D+/TEkD7d0T69KRRNgdvjx6W33Y85vywEVCu0wZdC7TwyWJ7WU8M9QlVLHgBI1SAPbQ9EPxyFNv94mNI6xCA2yRroZxRq+q7BDWsmRBLXmK/g2QKoSqxwe/0EEejaJKWEjfz46PkHcdFZozGsb1dIj7vG+VwjLCa8QRwBMA2Jzdt3n5T14Pf78e233x6XJ4eZyWl1JpSh7NQAsM1mifH7/f+nAczlBeC8vUCTjgxp1EjE4xBmRCBVA9iE0rg9mQe3YOZ3szHzu1oJKGSz2eF0xqBRfDwlJiWwRQvopYZhwO12IT+/AH6/H+Xl5bT/4CHsP3gIK9asw7T/TofD6UT/3j1w0fnn8NZtOykAXgssY6ZAtOwB6XMFrdk1Q1M5rCYBMWBk1V9d0e82sXTaPgyf0gaOeBWGj8M6F3Ml+2OuBdpKjlxdaSNwnFAEHPEaSg56kJebB2nIKkHcNE04BeHC0weDdX+gphaqW6mCQtSISrG+eluCUARnHs6jbTt2nnJriYhAgpqcMhzYotkaAxX4v07m3tVQW3Qj9hkhdYorpWgBaDbAVw65+XcYOxZDFh+qOjfGGYMOHTugd+9e6Nq1Kzp16oSWGRmIiYmF3W5HjNNBqqahMrPG5/OiosIFwzSQk5ODvLw8rF+/AcuXL8e6dev48OHDtGjJMixasqwKoZZ+50O06Qt2lQIkUDsWlRHW209RwUXZkLnRhaOW5njx2+u7MfCqDKS2dQYCNySHF8YMtTRTtcUqVLviyhpXNgUJLezI2VqG7Xv2oMTl5kYWEWiCFjQRwecL97UFG6pXFwio2RM5+HhWG81f+mtYKeJThhkwo8xVZjtlAGxKM+b/JGKFCBMtzX3robpKQBZ7SGUMAJqNYfjI3DgHxuZ5YFfAnxobG4sRI0Zg4nnnYdSI4UhPz4AaRbNpRVXhUGPgcAamtWnTQKndM88M1HHKz8+jP/74AzNnfs0///xzVdEDc+8qUGI6U/NOBN0XlqNbVeM4JJxSaBYYm+cHdOooqaLAj9/e2IvO49LQfkQyLHYBw8fBRoyh1UY4oqNKqAShCvhcBvYtykf2hoCOmpNzGBt2ZtJpvTrC8PuruHTNzaHSzkIRZQpUlfnyG8DH02edmtIcM7xe7wnB3glprUIkJhmG3v3/DnAVqG0GwDL2DkD3QRYEqzQafpAtBqJZF7Cpg4QCstjBB7eQPv9tmHuWA7oXLVq0wF133YW3334bt912G3r36oWExEQIRQkRulF3dUkg8udB66rT6USnTp1wwQUX0IUXXkh2mw1btm6Fp+gIzN1LCX4vRPPOYKGEhE5SWBQJqRqQvw/+5V+GtUGNagFKRt6uCmSvL6lq62mNVaFYBEgICIVAItDuRKgE1UIglaD7JfIyK7BzQT7Wf52D/auL4aswqxa1UDVMHD8q0E4mzG1WrQxUZzmFFnoP7dxAUJxOfDN/KV5/78NTdolZLJbfDMNY9qexd0J2AVWdbhrG5L87bsnqhNKqD0SX0aCkdECaIGlCn/MKzMMBXYocjWC5YCrIHguSEvrKGQEuhoAz/84778SNN96I1NTU6AERYpmNZFmNhrZs2YIHHnigKqBeNOkIyxm3AJo9wGFD4xsIIFLh/+F5yLw9AXfWn3DnqVaBxAwHEtMdiE2zwupUoVgIhk/CW66jIt+P0sNelBz0wFtWt1vH6XRiyQ+foVebZjB9eoSNLjgvlVIEhTasCcyXoqnIc+kYcs7l2JOZdcqutZiYmEcqKiqe+59zYCKCEOJSKWWnk/SsUlOUCmZoOElldERaG6i9z4U2+BKIdoMBixMw/QHOpCgQ6d3B+9YFAh10L4ShQ03OgH/eGzD3BhIxzjvvPHz11Vc477zzwhtiRbmL1qzaXz94wzXc1NRUTJ58EQzDwNKlS8HlBZC5e6G0GxRscRpSgM7qhLH8S5hZgSKC1tNuhtbnHJBQwBVFgO49thdkMlyFfhRkupCzuQwH1pZg/6piZK8rweEt5SjMcqMi3x+hLlY46bqOHZnZuGjiWbCIQK+nsLI9ofNE4RnGRIFWqh7FhmvueQLLVh5/gcRAL6aTG6lrt9uX+ny+Rf9zAAshoKrqZaZpdjgRD+ZQLdzUGa/7Wc67qnV/9ZrWg9bkUMm5hS73aSZHVzAgqpekqFDb9Ic69Eoovc8FpbQECQUwdRDLalGNJWBzQm3SCWbmKsDUIQsPwNj+O2TpEcTGxuKVV17BS//6F5KTkmpVGDmhuhOOniCtKAKjR49GSkoK5s2bB1leAC4vgtq2P2AagUVvdcBc+x2M9QGruNrtDCg9zwSsTlCr3lDaD4ZwxIMLswHD95dzpv0HspGdX8pnjR1FGgW6NoY2k6gZmVb5L8VmRYUUuO6+qfjm+x//1D3YNOv3Q1q0e+6a5v1GFxmeTUxkWoUa72fzhMU6OByOZV6v99dTggNrqnpZMMfxmMipWRBvsbtsirrm9g7DE7skNXvj/JbdXn+118SxL5xzxxnnONOoW3zagDtXfvecJtT+hjR7nhDLXXp3WMbcEhCV7fGAGWjVGW4JCe7FRIHAh9hkKGntIPetCyxsU0fTJk3w7bffYtKkSVU7NkWrmUTAuNvthnYUI1e0W0K/fv2QlJSMOXPmQBZlg1QVSkZPECSMlTNhrPshMA9tB0IbflXgeaQMSB2KCtG0I7S2A8AF+8DlhX85iDdu3kq79h/BkEEDEJ8QByHNqrYplfpvINBKQLFoEA4n1uzcj8tvexBz5v85TBAIqkJP75nyzYqBQtx0e//JI69u3okvSO+RsrIi59qbWg0YxcCOcsNbmGiLSfNIHfI4QG2z2pZ5fd4F/3MdWBDBYrH84PX5zq4P6BahHEl2xO28Ir33wK0VuQ/e2GZAendn2rnpvdt2wbb8nw3IpeqYMU+VLJhzyJS4nAUMVdKsRu0GtI59dfzkCp/xzp81TmmDLoHSdQzY1AFDR3VFxjrK+lS6GRUF5HPB980TYHcpMlq2wvffzYpYkTAa/lvzmFdffRXvv/8+v/vvf1Nebi5inE5kZmXxlClTSFGOb5+988678MYbrwOKCuvI62DsWALzUKBqhNppBNShV4ClGTR0hVh12QQUFQoY/tn/gnFkN/4XlJGRjjtuuAoTxwxHyyZJEIpAVfy2yXB5/diWlY1Pv/kJH38+AxUVf96VqQihm6rsWnHB80N03Zj6WpdHW9695ZlZFlU7bO8/7G7f0oXZVmejifkVpc3L/K4XL1vz1eP9E1s8taEwm9YUH/SbUrb0m0a9DRPi4+P/WVpa+vD/HMBEBFVVv9V1/byjigyaFU8NnfTavQv/+4B+0UsHNYt2o24Yh126d6EpPO0hbbeZ0hyVNmvqwIILp64D6Hs/Ke9YpLnPqdkuSPrmkTyvYayWzMfXTUK1wHLaTaDW/QCfOyCE1Sy3TBHLqgcMJKoF/p/+BZmzHWmNG2P27J/Qt0/vYwZuJPr5558xYcIEdOvWDRkZGbxy5SpcdumlePW1V/HZZ5/RsfQ8Dr0Hl8uFocOGYsP6DdXvyxYLbcCFUDoMC3Sd4BD/amiIBweitKj0CDzfPhVoKn4sIqKFkOYgNHcQ4h0CmmBogqCbDN0EDlUwDlRIFLrr515xcfHo2a0zenTtBIfDCQY4MzOLtu7ag92798Iw9BNnHVbUA37TaFtw/jNvEmTbpG8fP73o/Kd2MfCSn81lFohFhR5vpySH/VEBtEma9cQEz6QXsiwW9dGSuJitV815f+UPWWss9QI4Nvap0vLyJ/60NPmn9TJmSCnrnUGv4YchubemqP7c857YC59vdLbV9mBzndzStPWQMFcKIW7aMumJGEhaLYQY2HTmI1MLLnjqoNvnG+rW9edURcmTptn4OHYZaMOugWjdD+wNSSqgoC4lRBDMMlzHCUb7wGKHsfZ7yJztsFqt/MknH1NN8EaYmMi5gjWszJmZWbjpppuYmenZ557Dh//5D0zTwFXXXI1PPv2Enn76aZx77kTExDij2iiohlX3Xy+9hHHjxsMwDIikFrCMvweISYD0B0Ms66ocQgw2dFBSCyhN2sPI3nLUx7WqQM80FSObqhiUoqB9PKGJleAUgBYaMx28nIeBfB9jezljaa6J77N0bMqLbAkvKyvF4qXLsXjp8j+zT0Zp06EdQpJOQG9BPH/feQ83ZnATycZ6IZQ+kkVe+7n/LCg4/6leuuT5eRMfb+4y/QnlPtd6xYzpUOIrt0SHGzohBoYT0htJVZV6HYmSGTuKj7TVTcMuFbGSoPTu+dk/XAAOM1F/j4YNEMLaSCrtSNBCKWUXnjRJAdMGIZT+ANxWRdl1XPfXuD3UdgMAb0WVBAbVBmg2kDTArmKwpywAOosd0KzVrYiECi4+CGNDIEngiccfp7FnjK3tBkKN9kn1JncE1uDi3xfh4MGDdMMNN2DCWWexrutUWFhIcXFxuPXWW7Fz50589dUX0bujatDo0WMwceLEwPemCdhjAb8nJM6CI55dVaCGAYpNrvOa3VIUPDXYhhUXxOD3cQ48313DuakCnTQgVjKgM3Q/Q/cj8NsH6H7AYjCaK8DYRIGnumhYOsGB789yYERztT6WfFLNwwxsMD+RThDaGqysdKpaJ5DwkUPsVCAGQKHtMyZN0kBIZ4HVJtBVQvqTErBvZ9mB3tmu6CrE+I0TE3t8QgBst9qiUj4OleWn4bn5bSQbaxncmp94QmXQekHUrzD+8CECiiwCvbymsZGZk/LNbq0ly+Vg2ZGZhSLUDcel17TqHeiKQASoVhAkeNcS6HNfg2/mo/DNeATemY/AO/Mx6PPfAmeuhgABmhWkqjDXzAIMP/oPGIC77r776CsqtNxTFK6ISZMnY8kfS/DWW28BAE2aPBk9e/Zgh91OU6ZMQfv27fnw4SNRreC6yt3de+89UFUVXJIDmbMDUCxHlQ6qo7YAUi01dORAXfsz22j47qwYLJ3gxGOdLOhpIyj+IFglQwcQ1qSjsp9oZf4xASYA3WT4dcCmM5+TomD+GXZ6f5Qdqc6/vqMOEUEqWIvfPmwrQFYdvIkhhgJ8IPnzqWXM6MmQ6waYnZuDEetnuZVI9CemA/T+VPeB0qKuue76QzcJABt8QjjwiSpqF01PUM6pKFJ2ZW7tk+Tj1WzluNJt1paSzRUEfrB8ZxPmVN5OoEH+QnyhJcNFCvU3vPpyVaVU3PVduh/6muNKW7Q3AiAhLDbIrA3wr5oBWXI4bG3BMMAVPpgVBTCz1kAkNofW9zwgLgVm1joIIfD444/DbrfXJ60fmyXe6cTQIUOr/n3lFVdg8uRJZLMGQmXXrFlDVqstGs5RRydgoH//ARg0aBCWLFkCuXc1RPOuQQNejR2hUuxnAhQFUFQYO36Hvm9d1aFntrHgwR4WDEkUEAbDMCV0szoLiKl2hRAg2P0wGDFV2aWCuZrXM0C6yRAm4YZWKgY1duLq37xYe8T4ywAsSOi61Nd7XcUjGFy0s9A41CVF6SvBm7ZMuiUGktuzIZ+ykWhnMrv2FOFI12TqzuAdzCzeHHJxe4/uiwYw0DTN9J0AN90J4cAejyeaiHHKKSvCjrzsfkm9uuxhKct0NgdIkusApHVvrDYBY6kA9Wn1+1QvgXayycPcVv8OAnuNvMw+pol1hGOvI0SmD6RaYa75Dr75r0OWHEajRo1w7XXX46uvpmPNmrVYs3YtPvn0U1xy6WWIiYmBLDoI3/w34ZvzGsCMbj16YMyY049blD0WOdBWBVhGbGzs0UufRqEUCiEweXIgUM48uAXwu2t19qyujs6BOlruUujz3oJ/wb/BnnL0SFXw/QQnfhhlx7A4gvQFjFEcWq2+sncTA5oANIWgaQShEjwCKGZGvsmoIIDUwHeaEt7VgcHw64yuVuDnsXaclq7+hQCmw/Bjn8/0DSbw1lG/TzUJ3BmSlyWjcSsCLAR9I4MHQlDWqN+nGgKisylpJV5albq7vCCdo2N4iI+PPyHZPydkdpjIR1Es3FLdg/3lhT2Upy7y510wdYdkHpLv9fzc2Obwm1J2N025RCjitl2XPREHL9YL5kFtZr5QWnj+k3tcfvdQXdfnBAxZOCZDlpm7B0L3wb/2ewDA5MkX4Zlnnka7du3C1n7v3r1x5RVXYMuWLXjowQcx+6efwAGdhi+aNBlWi1Z17OHDOThwIBumKdGkaRO0atmylih7TMy4xgk1y8DTn1QKx44dC4fDwe6KQkLhASC1DSANhObvMgBhcUJmrYF/8SdgTylsKnBfbxvu7ayhEQGGT0KvumhIPSpmqEQgjeBjxi4XY2WRifX5JrYXS2SVS/j0gC3EphFaxgv0T1EwvpmKgYkCFgkYkgOVQgDoJpAqGF+OsmPcXA/W5558TkwC24Uk3ZSyJ8A/7jnv3hQpkSIEr7VIs4eEyE2d9dyR/POe7GsCmw9OfDAJ4CaqMNYaezZ32ll8JKqkHmaGwcYJKQR3QjhwYnx8MYn6h5LM2FOS29ZcKGOkxBrB6Nf9p+dLmeV+MPdVoG9nlrZYr+hkCLmUgZYHJt1tB2iFyTyQALcCccyGLGPXcviXfwUAuOPOO/Hll19UNlej0GaeldS1a1d8O2sWbr/ttqp3W9kBYtFvv+HCCy9E9+49MHDgQAwZMhg9unfH+PHjsWLFyno5IkeJQjrBVptWrVqhW7Cgvnl4J0hRqytjVlbRsDhgbvgJvvlvgT2l6Jys4KcJMXi6qwVxJqAbCMsOqtRkNAFoFkKmwXhpt44Rcz3c+1sXrl3gwZsb/VhwwMDeYomDFRI5LkZmicTC/QaeX+PDyB9cOP0XD2YeMQGNoInqUEldAqkEfDLKhkT7ydeJFUHrzefzYomopQle5aCYjkSkQ3fsZKEOIGAbP/EEgagTQa60kDWDWFKiBbt2Fuf0zHYVR6tyshGd1PrXANjrdu+PVi/dUXw4FbOnd2LwChC1XDPhCRuIVhJT/5RZzx4BOFcjZZAOXsskYmKQ1tYAr2SgnXyPHQDWHuv9samDpYnzzz8fr77yKkTIZhNeJK4aYpqm4fU33sC1110LAJgxYzqdccZYjB4zBt988w0KCgpgs9nQqFECysvLMXfuXIwdOxa/LVxYu4JMBDByHVDmY+CuXMdpHNFToGLY0GEEAPLIHoT1VQJDaDYYSz+Hf8V0gCUu7GDBr2c5cFoCQdeDJW5Du5KBA8C1CqzzSNy4yod+s1y4f4kXKw+bpBBhUFMVd/W24sMxDvx+rgNLL3Bi6fkOzBrvwGMDrBjaTIVCwOKDBibPc2PyEi8OmAiAOLgL6iajmxP45yD7yeW+RDCZVmL7jI4QsJBVrlcgBhLoYMoPD5RLyX1Nk1flbENzAZEiwKtB1IuBArRH0d6S3D45UQJYEcKblprqPmUAbI+Lq1CEElU6y8GKQrE5d9+AOFjWC8DZTENrBq8EqAueeJKYsFFKc9hBlB0icBlY7y5JrGNGPFZ/0J4EVh9PoHlcXBz++c/nIUS1e4Tr4XdEhNdefQ1du3ZFRUUFfvllPqSUmDhxIr6dNQubNm7C5s2bMG/ePHTt2hVlZaW47fbba0UEURQsl6PlthzxWIoG9AMHDAhIQoXZgNcd8IcTAxYHjBUzYGwOdMK4p48VXwy1IZUZfiMsEz+waJigWQR26YTrV3oxZJYbH2z2o9jD6JWm4F9D7Vh7vhO/j3Pg1V4WXNNCwfAEBYNjBAbHKZjYWMFTXS1YNNaOJefFYHKHgOt01m4dZ/zkwmYvQ1OqQWz4gWtbqxjbUjt53JeEz0/+jeUVJb3ZlPlvdcARIgwSLDcsm3S3ncCtAFqnmqKTBHu2FGIfgwYyiW3q00/L/Z7ijmX+6BoOSsmlhhB5pwyAU1Kc+QCXROVKqijG3rK8vrZmPQ4RKSVCoX6GEIslIbFkhy2dGMuZudu8znE+EmKbZBq2I8bcS4Rif1lRLy/p6wXRMStEY8eO5fbt21UVRkStRiWROWJsbCyeeeZZEBE3a94cM7/+GrNmzcJ5EyeiXft2aN68Oc444wx89tnniImJwbZt27BkyeJwjsgRFaGqq/JRZGsO/lfzvo/VaAYAHTt1gtVqBXtKwRWFgeJ8Fjvkjt+hbwykIT420IZ/9bJC+GWg93dY2daA0cmjEp7b7sfgWRX4z2Y/vDpjaHMV089yYMlZDtzbXkUHG4F0huEHDDMgDhsc/G0GjeA6MDCGMH2YFV+Ns3OTGIFdxRLn/+JBpg6oImARZxBUnTG1rxV29eSI0kKhI/DhoG4Yg5nl5uCTd5eMVS19ca0kk12QdTMLGsjA/lG/T/USRE8TWGc8vTRtf3lBu2jfg6IqnowMm+eUAbCua6VEFJVVrdTnxs6SIx0t75ztM6SxS5FKf3d5/j4h2W34/D0MBWshRONL1iIRLNcQqN+oT6Z6QbTLZfJA+JGpkMg51ns87bTRISnfkYBS98I499xz8MeSJbT0j6W48IILIh7To0d3dOsWqGmwbNnyME4YSWAITX6gkH7BXFmFIqR+FNXIbzrefJgWLVoE8pSZIcvyQZoVXHgQ+rJAoMj9fW14qkugUZkMubdKqVnTgLVuxhnz3HhkmRdFHka3VAXTz3RiwTgHJqcpsBkMwwiAlaur3yCCZwmSAJ0DuRQXNVXpp7McSI8V2FNk4sY/vPAKruoXrUtgQCOBs1ufHKu0AO0kIh0kekrwmhsyrQmCKdkQWKup6EkKlWwu8hwhk/sDWBfkyhlCobXI3dVuZ1leXNTiOihn/vyNpw6At27d6haKcija4/cWH27r/9poxCRXElGf9nPf9AGUyQoPLGfvFhAj0YLOILHMhGx1+PKXnKYpVzGbfYjIrwjafKz3mJScFFGArasUJIdyRwCDhwxBRsbRu8c0ig80p4i2wn/1NcLF9qrKqFy3UYv52I1ccXFxaNUq0FeLi7JBigZ96Rdg3Yvz2lrwbA8LTH9o3ayqxQ3VQpi2z8CYH1xYnmPArhEeHWjD7xMcmJwmoPoldAOQfHT5gLnm0wf+r+tALydh2kgbrArw634d7+01WdUqgz8CUV23dLVCFScewCSwVk6XMQpRC2ax0uHlrkRkuIV7B4ToK5l35aduYyZ0ZpIrmvsT2hLBoai8aUfO3l57S6IvDq+qap4QQp4yABZCSItFjbpI9YHyokQsn9WepVgN4taHbnzCAWCNgDLo85n/LNQYuXZF65kEy3KVTYtW4euik7lcAG3lazvj5HEYsqR57PMVyoHqtXTrBg5kZwMA2rfvEB2n5LqDLygCUmsGNh0PdezYMTBMaS5wYCPMnG1ItBGe72eFqjNkWHw0QQHB0ID7Nvhww0IPSryMbikK5p/twNNdNMTrAeu0jGhh4wjIDXRIVAL+x7CNSNcZp6cquK2HFQDw+kYfFRgCla3gDQkMbiQwoPGJ5cJBA9ZyzJ/WAQyrX8itrMs+QnJWm5kvlEJikIVpZTelZZpGSNKk2KAJ2RcsihLaPZq9q6KoX46r5FgW1u4TlVd8QgDMzBAQUdfvzCrNo/U5u/rEqbRWATmb5ltaJzMWxEjZ4clJd1uLFGzbAOOsFvaS9DKQVwg5SLfQaiayY92CzoaUK47VkHWs1QmPVVydMXMmtm/fBpvNhmHDh0XkjHPnzsWDDz6ImTNnwjTNqEDIFJ7Cv3XrVsyYMZO3btl6XO8qNTWNALAsyoZ/baDo23VdLGjvAHTJwUJyAS4siOHWgKtX+PDy2kDU0KQOGhaMd2BonIDuB0yqMWMUyl3Da3lVBov4iHBIr22VZyJInXFXZw2pDsK+Uom5OToUpdp4p4FxRccTa8xSSHj8wr/BXVoyhMHFe4pwRIE5uABm5mWX3d/cTqJNI8aijh5LexuTK0HdvEUjpT8Im7WnVbnPVdy9LMoqJhRIv808caL/CSLNas2MFlS5rhIcys/uYxsal5Np+PKeUY3rR6jeQY9DT24v7b+PMPVhl5rGGQUVWPqzIpJimPusltuyTeYjFV5XX1MztygkjkmHWL9+XUROxvUZhJiiGHs97rr7LkgpMXnyZHTp3LkW/j/++GOceeaZeOGFFzB58mQ88+yz9TDn2lvHN998g8GDB+OiiybTgIEDeNoHHxzVfcQRDVkdGQCZRYdg5OyCVQEua6WBdYRFUykg6JrAdUt9+GqbP6gjW/HFMDtSEXDvhJvBw5WOQNgzh4OaCZoKPLPFj97fuZDlltA0QKMARyZmmBJobgXOahUA6ZxsM7hKg6VmDeCcZgoax5w4OZqIDsCLHL/u68/MW0YummqqQKcHBE/4yautvxD+pNbCc+vtCj80X3rL+xlterPEAAebS/TZRlx2eUF6tBw1UIJK7jrlAExE26Jtl1jm9+D1ksPnJi4vWDpO0VNfEeada0l78HViNZ/Ufi5GQrkECIq6ghk6y+6TZ840Ad7k133D4cUhIjqmimVr1qxh05Rcn85Yq8lYPfjNzy/AlVdeify8PDRv3hxPPf10xOE+/OjDsBjuD//zn6PqyjUNV4Zh4JlnnqmSJFwuFz05dSpKSkq4znuPMK7TGZ4l0D5BQfsYglnDWa1owBMbfZix0w9BwPNDbHihpwXCz9Croq+qj+caSkelBC0AqBQMq7QAFQQszDGR72F8eVjiuyMmNnkZuiBoStAbL4HRTQNFDDYUGHBVYpgAkxlNLISrO1pOGICFoC2ChMngHsy8wn3uP5rkM2dsJLKbEMmLIUWR0CZ+qilnXK5y270qlp+uenp219yXnfnJkx+vKsyJPwacVCQmxu8/5QCclJSUpShKabTGm9VleclMjj4+Vm2sS1gME04GTL8Em8xEDJXB21iHi2RG2YQnkpl5FbPZh5khCOuO5f62b9+GrKy99QK2bndP5B32xRdfwJYtW2C1WvHBtA84Iz0drBswcoug51frRXGx4e9Y0zSuT2IJ/dY0zVpqgGEYgdBjvw7vtn1wr9oO//7co4r9KcnJCI2a65WiwC4qARcAkKYSvjho4KWg2Pz4QBse6GSB6UMI0Gt0BKwSl6tjoVULgTWBXT7gwwMGLl3qRa9vXFgbDIt8cpkH5/3sRr9v3Rg+18Nf5JgsrAIwCd0SBBQBHHFJlOkckrZMkH7g1o7aCctYYqJV5uO/NiKS6YZiLHdIR9dsUp2FUkJjhk0SpJchvJItpiCYqrJbCjpi2LquJvW89RUFUeNIUZTcli075J5yAL7ooosKhRDRxneymb8fIiQbw5QEl0/D5La7uYXDDY9fhQBwSDIOk9LIbpHdIHgRGM1x81fpUqHfj+X1VVS48PNPc44irnJdW2adUHd7PPj+h0B9qSm33IpxY8fBs3I7St//CWUfz0PZR3NQNuM3mGVuPPTwQ2japCmAgG/5iSeegMPhiPr+rVYrrrzyyrDPrrnuOiSoNpR+PBeub5fAPX8Nyj6bj7Jvfof063XowKmwWqq5V8dGoppdUqBF6REDeGilD8zApPYWPNa12jodppFXRcMEfisIuJpMjbDWxXhumx+j5rrR+xsXrvvVgy936NhTIrlS+k51CqQ5CYbJWJ1r4LL5bnpysx/QGMkWQqJNwKMzSo3w1EwTATH7/t5/vrkBEcEv5XJ9x6puDGhQxEYI7rdRMHxgSEmo8FlwSYcd3CqmlNx6oAmbhsDzKn43/O5SHAOA9y5YsMB1onB3wsx5Tz31lN9ut+8C0C2aefOXF8Dud0GqdrApOdXippaJbr6i03YMaXIEP2W15tUFycjzadiqKuguxdAjNvdbzdx23V2U3UtnfakgYTLLaAtG0VdffYVbb7sVNWtMHa2Ea2X/nZrtLAHAVeHiYPc7GnfmOPCa3eT9ZS1gVSHUADD0nQdQ7vNhyBXjsHLVSmzdugXp6Rno1KlTVWeQsrJSuNxu9nl90HUd5eVlKCwsQkVFBQGMTp06oVOnTnjsscfQuXNnrFq1Ct27d8fkiy+Ga95qyLxiKA4rIAlMDGPrPrgbxSJmdO9ILowwDmxTEGZsEhrhwx06DpRKpDgIL/azVonNgf5GtXstqYIADcjyMn7Ya+KrPTpWHzZQafi3KIQhzVRMbmfBjJ1+LD1s4JlBdtzcQYM0GbtdjKnrvTQvy8Azq73olezAxOYanBrB7Qe0KkGIg4USAtFZd7RXccBlwxvrvMe9bhUhygybsd1jGlcpQE7ijKm57olPDtyuSrCfkOGsQGqily9qtwMpmoeTc/3YWtIIbmklqAqorASGz30sG/EGj8eDUw7AzAxVVdcCdEE0tlvD52G4iokbOSHBZBM639tvJZo4XJQeWwanxY8FB04HqwZWKwYuAA/u/sXzTxdMnJplmOYA+PGToorD0pDNo73HVatXYenSpRg+fHjthIM6MhCIqM5yromJCdS6dRvk5eVhznc/4PTB50PYNJaCquI1hc0C81AB9IISNG/eHM2bV99uXn4+Lr7oImRmZrLL5YLb7YZhGKTr/jCbSGpKKm/YuIGaNGmCSZMmYdKkSYHh/QbcmYdBFq3aj8MA2TTou7PBo3oiUpIJRVQTAt7oCmZ8sTvAva/qaEFLW6CCRmUPMS3ol2WDQYLgJcKiIhP/3aVjdpbORZ4Awi0KoX8zgQtaW3B6UxVdnAQTwHMrPdQ+QeG7O2lkl4BHIQxKJHw/2oGblvvwyVYf7l/mhasf4NYZdo2Q4BAQDJhm9abBAEgHXu2twaEynl91fLm1AtiHChSwlEPAvJ4nzxCFtK3zdjbBDNZY4rWRc6EowNVdN1OM1cvr8vsQVAYJAaM0F+YxcHural2HE0gn1CVus9lWCYWiMsdJgLjkCEgoUCCxr7wR7SmKJ4fqh89QuJmjgs9vs5tVg7BBMlwqOv921RM2SXItsxwEwG9R1WPypZimiffee49RO07iqMow1S0O4fzzzwcATP/mGz7kcbGiqFU94UkQhBAgpkB+XA3y+3zYunUr9u/fTwUFBeR2u8k0JZwxMRQfH0+NGjVCixYt0KNnD7JYrLUiLtk0QYasKn5eWfBCMILApYgbbS0rfPAwVQH2uhk7i01oAriotQYYAc5LAFgh3LvGh6mbdew1CZ8dMjFmnhunf+fCp9v8KPIw9UpT8OwQO1ZeGIiFvrediu42DjRGl4xH+9rw8hAb2QWwtFSi1w8uvuIPL1QGXuxnQSMrsKdE4opf3MhzS5T4GLes8GG9mxGouFsd1skApJ/xzx4WPN7ferwy9FpmJjD3NAjLIHa2LFDQbI8JWCXTsBb7YFFMgAVZFImdhcnkMbXAPJOAWRh9VqAQwmd1WDefSMydUI94amrqluLiogJpypSoAFV4AKLNAHgMC+7ttRLdU/MxfUcnHt82E1/u7Izz2+5C6/gifnfTIMon2bRvhdnGw8piFjyet7DF0c+xAsDYY7nH7777nrZt247OnTtFFItrf3L0zN6LL74Izz33LI4cOUzfbl/Nt6T3YZduUpVu7TcgEuOgJsfXGr958+ZYvWo1tu/YDlVVYbXaEBsbg8TExKCYT7DZbWgUHw8hRK2dUditUFo1hn9LJoTdWjWu9Pph65QR7L0bXmreMAxwaMM2I1zf31VqwjDBjWMEZTgIsrJ6BgBFISzONbEm14eXN3hR7g/cUaKdcGYrDVe1t2BIIsEOAkwJQw+U1qmSDCRwW3s1IC1Ixs5SEzuLTBR5mcv7S7L5GGc3t/LBCh9MRaG95YxD5RLTt/vwc6YfLw6x46aWKgxdVrn4mBimj/FEdws2F0rM2ntsFSol5Grc/0sTgBprKq2AIbvmKLDm+RR+qt8fSI8pxetrB9FtfVfxT5ntcWf/FVTis/K8Iy3JKU14C6MOQIQilIMDWg04cODAgVMTwNu2bcvVNG07YEQFYH9hDiy6ieYxFZjYfjffPn8cNhUl4o+8FvTbgab4YU87/vzMH/FDTi7vLW+htvG5+xRp5kqN1QS8OK2jlHL5sZbYcbtdeO21V/H+++/XawFm1N/ipEWLFpg8aTLe/+B9njb3W1zxwjhSth+A4fMBACuJceQ8ezBIU2tsBYF7Ts9IR3o9IZrhkkD4KM4z+sKscMPcnxsoQqUS1J5tYB/YOeysyjNycnLg81WLm3necM+fPyAokKYAglAlmmsKYUmhRFZZ4IBK8J7R0oL3h1qQYQ10cjQNwKgRuU3BzYEpEDJZKfqd31yFb7gdLWKIYuzxbI68Ap9elkjmb58wF2dxESu0spjxxiYfFuzTcfdiD/onOtHLCYQmSUkmaDrwYG8Lft6vwxdlqosgggG51ji4pQ8LGMV+uT1OMc/YZFrRJ+0QBjfNpYt+PJsrpIIjfjvNyWzJ57Vrwjf12oCF81sBvgr4ywqiB5umbv568dcntA/vCRWhpZRQVXVptMf7XaUwPS60SyhCsceKnaXxsFl1+jW7KVRVosCn0bojqRiUkoONJkNRtb7lQtlNgooqPAXDfD7feoVE+bHe55dffolt27ZFEJK5loEmmq3hpptvgkWzYMvWLfQHChF33ZmIOWcIYi4+jeKumwCtaVINAFaOXnegZqBuVLh9nFEtOlal9jntiL/sdMRefjqcZw9G3NVnIv7cYRCaWoffOo9DN7yDNewvTR2Bu6zwM9ySq7KfygDctdyLQg/joo5WfDDGCbtGyCwxkKwISJ2hmwQJVEVyVda8ipRxJQHEApjSTqMJSRLoMAzWtp2BmGTmdiPJ9EpKZuDsJIEfxzrRMVmB12D8fMgMSBYcIv8Tw5SMnrEC3ZKjL4JPJI7AwNYKv2cQGFmtvp9aojP33WAqGNE4Gxvzk7nE0KCpBuYdaAGLVacl2c3IIgykxHjApfnQdV+U1yJomvbHiQqhPCkABoCYmJilQkQ3rGHq4PI86BBwWnywCBMmEyyqrPTPQVEkJVp0bJAEP8zuXWdO9ZuMrbppDgWQpyjimFuwV1RU4Omnn4ngnUZ47HFwFdY35b169cLpZ5xOAPDGK69CJsSytVsbWNs0h7CodWrUdcVBMypbZlJ4lctQ6YBC/K5CwNKyCWy92kFrmnzUe925c1fYJV3+6uwnlkD7WIEkO6HEw9hRyhCCoGqEL/frWJdroEOigjcHWnB9KwWzz3LixcE2WAXCDDkUloJYtxVBIhD/rEsBdpcFTlMtgK88CMrAqfNzDBwoDayJ1k6qNtiF1PGVIFjAGJAaPYAVIbYAcJlkDpREa38bMUKtgOi4ixlWwXBoevAtECxKYG06VYMtigRDA4oORR1qK4SQjRo1Wnai8XbCAdw4Lm6DEEpJVJZrAErRPuwtT4VTNXBtlx3QdQu8hooKvwVd4osxqsU+ZJYmYIc0USHUdodPv9cpwcuZ0UcTChSi42pD9/XXM7Fw4cJQbz7Ce+gGfY9EtYzqHGF3vfe+e6EoChYu+o3nz5lTr4uajjpiBDd0jcOpXuNb5DHXrg3PAznokvDIQANDE4wmFmBAmgIG8N1+A1AIPgAfbg+EUz7e14oUANLHOC2BcF6aWtW3qObzEaIrQA9FAe9cBv23L0lf+T2Zm+ZBVTRoVsJ3Rwxcs8AFt84Y1ULFuS1UhOWlBFo7BgM9CC2c0S9pTVPX8ha2CBadmXnpgNiRTUuhNDsIA3uLkzGocQ53jC/lCp8Gt1+F4ddwXffN8PkVlHjsMEqOQf9VlP0tW7bcfMoDeMOuXTmaFn39Zlm4H0dcMfh4S0+6rc9KvDJiMSa0OMi3dN2MaeN+QrE3hhdmZyBX6DhMSuPGCXGdpcAfUDjd/9j3jXXmFceTmWMYBj/wwAOo8snVMUagHGr9VukRI0Zg1KhRYMn45z+fZ8Mwotm/Io4YKtDzsZjF6zmouLgYq1auDPusyMfwSq5KfBIgTAzGIc/Y7cdhP5DvZ2wrkki0EUYmBThcjgm4KdAqpVYf8qDmy0epVBCassgMEEzwjkXAuh9hhQsuTeDRLT5MmudGkYfRt7GKT0ba4QgWvgPVKCjENTa2KERaCXMFXvugJZgbGSavsgv03Cc0e4li4reDzSmnvBE+GjebHuizFhe3ycS/Ry/AxR230Mdbe5BuSujFUSfgwaKqKxYvXlxxygOYiFjTtPlR68EluXDKYkzb2gWvrBqAoc0P8FunzcF9fVbgYHkc7lo0ikoNC1WAsY8hoGtD3DA2CFNh7MzsTFZaLUg5nuY4tGbNmsqC6sfuQ6plEBG4775/QAhBS5Yspjk/zzl2hNXaPKJPZ4yGFixYgJzDh8PVCT+jzKiONZYm45zmKprGCBS4GdN26yg3AsfFWwiJVoH/7DfRe1YFblzmBRQKq0xbS0xgqrEV1XBicRUThcWqgRwWzMpnjPzZhWdX+mCYwOWdNMw+w44WStB4FcFkwcEgjzI9uvlSiLweSZtKSwv6EHNFpqV4jxTa8B0koUOizNRw2++jaWtRCq7ptpn/OfxXdE3Kw8NLRmFWdgeOMYqgV0RdxA4Wm23eidZ/TwqAASClUaP5qqJEZQv0+zxQKgogrALvbO1O535/Hi6fezZN/vl8XL3gLOx2xcOiSJhE2KQwJGFAq5lTj8Qo2j6Q6KNX+Lergo67Fftzzz2HrVu3RmGPrp/GjBmNUaNGAQD++fw/2X/U7hlRjEnHImzXT9OmTat1eoXOQYty4DomA2kacHO3QLjlvzf7kO0n2JSAK5cFY0eJRL6bsb1Iwoi4FXE1PokjaP7VxwgAmgoYKvBdvonTf3Hj/NkurM81keYU+HiME/8dakNapSu9itsSQnp9BxayYBT7oswKEmI/fL7MWMXW165Y1g+e+arHAPpsZh1MBFUwDnntuHnh6Zj847l0+ZyJmPjj+ZiR1Y4tNiJRkgNDRhfCoShKRVJS0pKTgbWTAuDeAwZsVqIMspAAUJgNoVphsTLydBstzm/KG0qTYCiAsACmqgGqhbcIFV6ndcCZ7foNn3ZoY8kD236+0WKx/L/2vjs8imr9/z1Tdram7CYhjQRCEkKAUCJI701FIjUiJKEoXhAL1+tFrxdRpChX8Yp6fyIgKkWaoQUEgQBfaghVWiAQqoSWXraf9/fHpm22ZLNJEGQ+zzMPYXbmzMyZ85n3PW87q41m9xf+zs/Ph7feeguMRqMTohBXXxT861//ApZl4fDhw2TLli2u5PQ7pCa6rxDYYPfu3ZCammpzuhktSwOTKks1UiPCq5E8NPVi4XYJxe8uGCFAyUKODuF2KcCMVgxsHyTAur4C8BSr1fyylbCVJWixYh9XRtxiBmBlNoW+v2lhaEoJ7L1R+d0PVjHgo2DgeikBPcsALyGWjbfEXHM8AZ4jQHgAI0fgjpnA6VyXCzf4SXjJV/Mv7R+y/EEGnRQzqJtRIgk/w0uAYXmgLAMsR4BIEM4Vq+FQrj/kg4CCQAlwHJjys13+mHIcd+yll1661hBca7BiuwqF4pOSkpLprhzrFRCOTI9xxGw2WG6JYZEwLGEYFjg0A9WXICl6AKr716DR3at46sENojXq6/Xe5/9nPr7zj3fsyhLilH7Exv3zQtwLsHnLZmzfvj05ePAgSKVSh+dWdSo11OsoKCiAnj17wunTp+1YYgkce0EObVUEDLTyDniWwOpsCmN+K0GeIUTGEczXU7JqgBeM7hYLQDigWcfAZNJD+YLblfxFsBvphmUlYzmAW3qENddMsPSCES7kWCSZp0AgMVqAPD3C2kuGioqYXgKBJl4sNPMg4Csn4MFZ8pWLzQilJoCrhRQeaBHuliLcK6VQa02VEFBJ5LSzXxhc9W8CRZoQBjx8gHICmACQms0EkVrM9ECA4yVgSl0CBXeyXGiagJeX1zt5eXmfPVYEDggI6Hrv3r19ZrOZrYkPgkwJHnH/RBMnIZxBC6QkHyHvNqE5N8GQmw26wntg0muBQsNBLpfDrt27oHOnzjYF5FxdrLv837SjR7FH9+7EYDDA999/D+PHj3f5o+AsJqzm821/MZvNMH78eFy+fLndUziGQPoLcmijJFbBEQQAWIHAq0cMsPhspa8z+e0RMHRoHIIZwXx2P6EHVgByXIXFnCBWoa/lkhwBIByAkQCk51FYftkEG68Y4U6J5Y16SQmMai6BN6N5iJZbHM9HCxB+zjJiSpaJXMk3QwNMHx1LTCAgUXqhzNuf8L4hCOpggiofRKmSGDkBOLMBijbOB50LC5mxLKsNDg6OvX79+oXHisBJPXtKVx85fEyvN7SsaewxhIBPxNOg1xWBMTcbDCX5YEIKDxsxbWJgz569oPb2rli/1zWa2GJsQgKsXLECwiMiIP3oUfDy8nLxLrDKNVy7vqP7MZlM8Prrr8O3337r8GoCZ5HALeXEuowsWFYhvIsE2v5SAndLKHT1Adgy9y3wDm8NQM2AxQVgWv9x5TyXVFqkWSDAsADAAlzTAqTcNsGay0Y4+IepgowqCYG3Y6UwJoyFcCkDYKJgpJYPAUcAgGcgz4R4uQTJ9RKEq4UU8s0WdZxSBIIEWAbAVwLgJScw/YAW7pZgg5CE5wWQePiA4NMYGKkScn5PBerCGBUE2QGdrrSnq8UuHhkCAwCoVKpPi4qL/gkIjw3GjBkDP/74Y0XKYTmR0ZGtxkEPXriQAU8/3RGLiorIR7M+gg9mfOD8lBoWBK/th+TO3bsw9bXX4JdffnHahqeEwLGhcmgmVJHAZY3yDIGN98wwanspNFdzkDqIR3VQS8L0TASQKcB8eg/g0V8AWa6s8gaWiVuAP/QIBx5Q2HDNBLuumyBHaxm/PnIC/UIksOGSAbxkBDJGKcEL0apEDwsADEOAWsK6LB8CplLdrQzgKLthgcDkQwb49rTukRpLhBDw9vZ+Kzc398uGugbbkA8QEOCTU1xUOh4R2ceFwGfOnAGJRAI9evSo8pUj9r92dhhdLrd9fX0gPz8fDh48SM78fgaGDx8OarXa8XyX1F7aO0q22LhhI4wdmwD799ds+PQWGHithQSUrK3RjHIE3kzTw+V8Cp91kUFnb5aYc+8CXkoHyDgM3PUTwPIcsBwBM0fgsh4hOZvCvN8N8O90A/x4wQDnHphBa0Jo6cPAm20E+KqLFMaG8bAqy4g3iijpEMBBtMpCViQAEobAAzPAuSIEmZSAQkIAzQhmSsBsRqBWGwGWJ/DZBQPMO6p75MYSx3GFwcHBb+Xk5OQ31DWYhnyAceNeOS2RcIf/rA7s3KULtomJqfV5M2fOxGU//IBW5EXHlmGwobrlqH/84x8kNLQJ5OTkwOyPZ6NWq0NSS8WHuHhEqbYUUlJS8JlBg2DosKFw8WKGS+3LOAA5VynMyq/HEQK39QBpd8zAMQTa+rIALAAv4wCgCPJL7sI5I8LG+2Z494wBev+mhdhfSuDVXaXwS6YR7pZQkPIEJraWwPY4BRweLIf3W/AQygJIAaFXsGWJhV+umQAYS79JWAJnDAi9d2ih08YS6LSlFD4+b4Ib1BLOyVR7bl4AWPOHCf51SPdI6niCRNh56dKlaw15jQZf8k2tVk/Iy8tbivhw+3jatGkwe/YcvHv3DvTu1Ytcr2UKl0KhhM2bN0GfPn1clor21O3lK5ZDYkIiAABGRbUgTz/dEbp16wrt28dCSEgIaDQ+btV41mp1cO/eXTh9+hTs3bsPduzYUS1BwzU082TgRJwcFGhd25kjALcpQMv1JVCgQ4jx5SBSTcBgBnhQSuF6MUKeFqHUaG35ivRmoIknA7uumSDMk4GzIxUgmMAiPct6hWcBUu6Z4fmtpaCWM3ByhBJCeISrBoBnfi2Fiw/MVl3tr2TgH7ECTAmXgMxMwWhG4CUMbL1nhrG/lUK+/tHjL8Mw6Ofn99ydO3d+fawJHBsb6/P777+fNhqNgQ+j4xQKBXz2+efwt1dfrdh38OBBjIsbQnJycmvVlq+vL27YuAG6dulKqlua7RuTbAlsNBohPj4eNm/eAuYqybeEEPDz88OQkFAIC2tK/P390dfXF0JCQ0EikVhJc0oR7ty9A7du3iRFRUWQmZmJd+7chevXr5HS0sp0IrlCAV27dIFOnTvjrp07yeHDNSs/4V4MnIhTVIYoVp1f8QTmZxjho3Q96BxEOLEEYEi4BLr5s9DJj4U2XgTOFVB8en0JCZQTODFMAb5s1WJ4BFgAKCIAT20qgcv5FGZ3lUPvYBYm7iqFjBwzRHoz8E1vBezPNsL/ThvgQanlznqH8vBlJym29gTy83UzTNqjhWLDo2lgEQThTKdOnTru27dP91gTmBACKpXqs8LCwrfraJepEU2aNIHFS5ZAv759bX7bu3cPxI+Kh3v379eqzUaNGuHmLVtIxw4dan2z5b8bDHq4kHERTp44Cfv3/x8eP3GCXM3KgsLCwqpmo+p/E6fCHoBIZVIIaxoG7WPbQ4/uPbBnz54kMjKy4sORkpICn332GR46dMjhbYaoGDg9VA4qtF1dgYAlWOJ4EcLOW0a4XowQKCdgYgjMP6oHnRlhXCsJLOsmAzCghaUE4UQRQsfkElBICJ4aJidNJARMSKo8JALPEfj0ohHePagDBW9ZdUFvRmjrx8LPfWUQVeZOyiwF+OSsAX46Zwmr9FcwEB/Jw7e/60FvfiS5CwQAlCrV20VFRQsexrUaHKGhoVG3bt06ZjabFQ11jW5du8GyH5ZBeHi4Q4r17dMHUvfsqXXbjUNCcNPGTdCuXVun/YUVtEM7tbQqYTSZ4E72HcjMzISrV7Pg4sWLUFxcDDdu3oSC/PyKXGAoDxhkADRqDYSEhIBUKsNmzZqRJk1CMSIykgQHBoEgdVxOxmA0worlK/CDmR+QP27Zln/hGYAdg+XQW82UVf2xDsEgULZKIGMxeeoZAs/8Wgp7bpogUsPBnsFy8AcKZqz0+d4wIsSsLwGtGeH3EUqIkhIwonVvsAQghxDovKkEr+RZKpjER0rgy05SaMRg2SoRlvsDnsCu+xTePqSH3++b4FEHx7E5Tf3D2mTeyvzjL0FgQggIgrBOp9ONaIj2ExMTYeFXX4Gnh4dD0Zhx8SI8FRuLJSUlbj1zUFAQrFu/Djp36gzVy9RU/2Dgw+xcF3ElKwumvvYabN++3ea3rkEsbB8oB5kJgCLaWW0YgQUCRSyBMfu0sDXLCGoZgV+fV0JHObFyAXEAcB8QWv1SAnk6hNMjFBAtZcBoZ+VyjgD8rgPYdsME7TUM9PNlgTFjWcICQrlbmWcI6HgCifv1sC6j5gT6d955ByUSCVm7di1kZmY+9L6Wy+XflJaWTn0Y13po7h2NxvO+VqtPQMR6s3yzLAuzZs2CBQsWWMIVyxllhzlffvkl7N69221OFRUVwZaULdi5UxcICQlxsEwpcf3LWLb85sMiudrbG0aNGgV5+fmQfvSo1W83ixAoS2BAIAtori6ECXAEQMsxkLBfB1uuGEHgCCztI4cBGktyPcsBsKwlLNNyKoFlmUbI1SH8LVoCfjyxG0VHESCAB+jux0K4lFhcQxWdYsnD5nkCN0wA8bu1mHLFWGN3vfPPf8L8+fNJnz59IGlcEnTr2g0ACN68eZPodA3vamJZtrRRo0avFhYW3n8Y7/WhCYmZM2cy8z/9dLtWp+tfT9Zt+Prrr2H06NFOOGIxKhUVF0Pbtm0g60rd15Ty8fGBFStXwMABA906vzaTfKPRCJcuZcKpUychIyMDrl27DogUCAFgGBYiIiIgJDQUWrVqCc0jm4NCobDV6YltrPbkKZNh0beLrPZLWAKbnpXBIA1jVUCTIwRKOAJJB7SQfMlC3iV95TA2iAU0UbhgIPDhMR3oKYFYPwa6+nPQ2oeFISmlkHbHCCeGK6Cd0jLHxaox02VvBypuEStWh7BIXwKcBGBPrhkm7dXD5byaJ7yjRo2ClStXAsfZlhPKunoVNiQnw6pVq/DEiRMNNu7lcvkqrVY75mF7XR4K/Pz8+hGGsUoKc2cLDw/Hw4cPo6tYu24dres1q25yuRwXffcdLW+fVvxLK/6uur+2uPXHHzh37jzatm1b5Hm+xnsnhNDmkc3pyy+/TLdv34E6nc5p+yWlJdi5c2ebdpp5MXhrrBLNiSo0JCgRk5SYk6TCIeE8AgAqJARXDlIgTlShKUGFhoke2CeUs2knxINBT4EgQwCPDZUjJinRkKBEQ4IKDYkqNDrYDIlKNCQqkSaqkL6swq97y1AhIS69k/79+2NRUZGdvqdW/9Pr9bjzt510zJgx6OXlhfU5LliW1QWEBMQ+bIMZPEwpPG/evF0Gg6G3u20MGDAAlixdAo2DG9uTWHjz5k0SFhZmtX/QoGdgx47tdtuTSCTgPG/XMV5//XWYO3cuKJVK9+VtlUMMBgN89dVX8Pnnn0N2WeK9TCaDFi1aQHh4OERHR4MgCECAgE6vw4yMDJKZmQkZGRlWc/v27dvDhAkTYOzYseDp6Wn3gmlHj0KvXr1AV22VgBEREljdXQIsBbioIzDu/7Rw5LYJAlUM/NBXBv3VLJiMFDiWwO48hAGbi0EjY+BvbQQ4dc8Ex+6aIbvYojATBuDcCCW0kJXlEkO5tCXWRr8q+cM8C5ALBN49pofFZ117L4QQSE7eAC+8EFer95eVlQVr1qyBn3/+Gc+cOVNnPsjl8pVarXbsX1L6lsPX13cA46YUfvPNN7G0tNSuVDGZTPjWtGm4c+cuq/0nTpxAQSrYtNWqVSv83//+H6YdScOmTZu6/dXt3r07nj17FuuKO3fu4DPPPFPRbuuYGPzyyy/x4qVLaDQaHZ5nNBnxypUr+P3332NcXBzK5bLyNmh0dDT+8kuyw3PHjRtn95mW9pXh4REKDPNiEACwhQ+LJ0d7IE5QoTFBicYEJeJEFb4UJUEAwLfayRAneyFOVGF2ogfuekGBn3SV4bL+ctSNK5eu5RLWVgobEpVoTFAhTlThwWEKbN+Ire17oHFxcTYKj8FgQMsqF9aofqC2VIs7duygCQkJbktllmW1gYGBbeGvjpkzZzIymWxbbTrHy8sLly5d4vANGAwGTEhIwNj2sdRgsH5hU6ZMsWqrQ4cO+NNPP2FJSUnFMcdPnMDAwEC3Sezj44uLFi2ilFKHyrOzPTk5udilSxcEAJTJZDhnzhwsKipySwM/e+YMTp4ymSoUior7e/vtf6Ber7e57uFDh5DjbFVgpYRUqK59m/B4I0GJOM5CXkOiCs0JSrw9VoW+coKEAO4bqkQc54HGBBWaE5WISSrECSrE8SqL2pxQlbzKir+N5ar6OBXqJ6pwblepyypz9Y3neTxw4IBVnxUXFeNrr03BZT8sw4KCgmq9b797s7Ky8JNPPqExMTG1mnYpFYplhBB4IhAU1OhplmV1rnSMIAi4fft2h1TIy8vD+Ph4BAC6es0aWl2qlX9R+/bti8nJyVUGsnVzaWlpGBAQUJc5EB06dChmZGTUinBmsxkTEhIQANDT0wu3bt2KtnPr2uPUqZM4cuSoivvLupJFqzdcWlqKUVFRDp9pchsplkzwtMxhEyvnsThOhSsGyBEAMMKbwfzxHmgqI2O5NK16fCWJy6RtGYlNiSrEiR54brQSn2nK1XkO+vzzz2PlR9SCFStWWO4zIhJnzZqFWVlZaDKba+y/ktJS3LZtG/bu3dsV6ZsbFhYWAU8KCCGgUCi+d+WlMAyDU6dOrTLsKr+dt27dwq7duiEAYMuWLW3U62/+9z8cOHAQ3blzp0skOHniJDZp0qROg0ij0eCn8+djcXGxS0Tbum1rxXOuXbu2xuPtGsmcPNymTZvw559/ptXV8PJTkpKSHEqaz7rLECeoqhDRQj7TRBUObGoxbL3RTkB8ubp6XEZeK4lbuRkTlYjjlVgyQYULekhRIyf1YkTieR6PHLE2bhqMBuzUqVPFMyqVSvrjjz+69G5MJhP279+/JgMiqlSKWfCkoXnz5k04jrtbLr1qejn/eu89a7KdPIktW7Ws+P2bb76xHqAU8Y8/btVKal25fKXOBC7f2rVvj+vXrXM6fzVTMw4cNBABAO3N4eyRl9Z5tk2tCPz+v//t8Bk8BIInRqoQk8pJbJGaJeM88KlGLAUA3DxYjjiuTLqWkzZBWblZkdfSFr6swh1D5NgpkK1XKzAA4KhRo2yeeMPGjRW/x8fH0+rqtN1eohSTHNgIqn00Lnfo0EEDTyI8Vaq/E+L613f+/PkUEelvO39Df3//SrdFSAjNy82zIXBtkJeXh7GxsfU+oHr27Ek3bNiA1efmiIjXr19HpVKJhBD87bffaN0o6fpvVftm4cKFTj+efUN5NExQoSmhkoSmJBVeiFdgynNy1JaTt4q0NVYlcJn0NidaDF+/xyvwxeY8MkzNUxJ3+lsQBExPP2pt6DMasVOnp2nckCFUq9XadElqaipNS0uz2v/P6dNd0g41Gs1L8KQiNjZWLgjCcVdfDsOwOHLkSFQqlVb7P/polv2BS22/qo7moWPHjK138lYdiB07dqQLFy7EGzduVFz3119/RQDAwMBAzMnNrbtwtffMNRz04Ycf1vgMX/aUVVig9YlK1Ceo0JykRBynRGOiCvWOpG+CxaeLE1V4K0GJb7cX0EMgbqnGM2bMwGeefcal40eOGmnzxMePH8P79+/b7N+2bRsqFArK8zwdOnQoTU1Nxf/+978uXUcmlf26duRIFp5kBPoF9mNZ1uguQfz8GuHNW85V5dvZ2fjT8uX44MEDu7/P+OCDepcEjja1Wo1D4uLo998vozNmWK7bq1cvG65RamsnpVVsANSuSKW1NnolJdWsJmpkDF54UYWYWElMfRmZy6WvvsJYZfkdE5WIE1R4M0GJH3cRMNiDcau/moSG4qZNmyway40b2DikcY3nSCQSPHr0aI3PvnffXvT09LSZ07qiFfI8XxgWFtYannRYDFqqRe4S4sUXRzt8QZcuXcJ3330Xw5qG4fp16+0es3LVKuQ4vqGkb40GEADAgQMH1k7C0joo11V26XQ6p1boqttzTXjUj7eox/oEayJXlbyYpER8WYWXX1Li+x0FDFS5R1yJRIIvvfQS3rh5w+r2U7amIM/X/L5GjBhBnVvpT7ntdSCEoIeXx3sgwoLw8HBfnuevutOZ/o388ejRo1YvKz09HV955ZWKr+sXC76w+zKPHDls8wX+M7aBgwa5RD7q4gTf+Zy4UrKvW7cWa2ODWNhDWmGVrkpi41iLa4lOUOKJkQqc2kaCalndLMtRUc1Rq9Xa9T68//6/XfkA0KNpaXb74PyF8zQ8PNxtzUoQhPTY2Fi5yNyqEVpq9TB3I7SahoXhyZOncOPGjfjcc8+hRCKp+O3vf/+73Zd47do1bNqkdhFYw4cPx8VLlmBwcHC9ErhNmza2/ukGRnZ2No2MjKydi0zGYMZoFdJEJZoSLHNgnKjCnEQVrh4kx2eacijl6q9f3n33XbvBF1qt1iX/7IgRI2xdQ2Yz9u7dpy7xziVBQUGdRMbaU6VlssXudmxZ5BGtOmdNSEhAsx2nfUFBAXbr1r1W89avvvqqoq0rWVk4aODAehuoMpkMz587T12Xo9Zw1edcYRO4fRu7lfnPa+2mieQRJ1lI++vzcjq5jaQi5LK+N4ZhcM1a6+Cc8v9cvny5RhWY53lMsyOFV65c6bbq7OXhMUNkq2OrtI/A8xfr4+X37t0bCwsL7Fqcx48f73I7PXr0wJMnT9m0o9PpcO7cuahSKetlsE6b9ne3JOnde/cwpk0MPvvss7hkyVKamZnp0Pecn5+PK1euxNpKXitSMIDPh/ENRtrqm6+vL164cMHu86xevbrGKYA9vzClFEePfqnWKrQgCHsHDRokiEx1gkaNGvVxNczS0daiRTRmZ2fbfemffPqpyymDs2bNwtJSrVN5mJKSgixb94AEuUJeqxTJcsydO9c6JleppG3btcOxCQn049mz6bxP5tGPZs3CkSNH1SlpoyE2qSBg69atMT4+Hie98orDfuzWvTt1lMTy5ptvumWRPn78OAqC4PK9chz3IDQ0tIXIUBdUaS8Pj5m1Ma5U3QIDA2lGRoZdvq1ZswY5rmaytWvXDg8ePOiSMrtv7z50916rbxEREXjq9GmXyXvo0GH09vZ+pEhZo3FJEGjfvn3pwoVf0nNnz6JerysPW6QREREOz5s+fbrD6UPHjh2dStNhw4ZZnfPgQQ726tWrVqq8Wq2eKLLTRUyaNImXSaUp7gwQHx9feujQIRvOHUlLQ7Va7Vw9lEhw2rRpmJeX5zA2tjo++uij+lYZ6ddff41FhUU1xFBvw0b+jR4b4iqVSpw8eTIeP37c4TMlliV12JeAbIU/uPqH9dTpU04/ZBKJBNPTLZ4Kg8GAcXFxtb33HxCRiMysBZo3bxzI83ymO4MlICAQ9+/fXxmyeOMGOvu6AwC2bt2a7t692+HgWrNmLe7Zs8dm/8B6NGZZu1Gi8J133qHr16+nJ0+dwoyMi5h+7BguX76CDhs6FFmWo48LeYcMGUJPO9AsqoarfPfdIqeBM0FBQXj16lW77SxZutTpucOHD0e9Xo9TJk+pVb9JBeFY69atvUVGuoGAAN+uHMcVuzNoNBoN7tm7B7VarVOLK8uy+Nprr2Fubq5DA/C8Tz5BlUplkyqYn5+PwcFBDU4AjuNQLpfXm6r+MLdZs2ZZeQKcTUeOpKXV2N6AAQNQrzfYNUxNmDiROpPCffv2qxV5eZ6/I8576wi1l1eiu/5hX19f7NOnj8OXFh4ejikpKU4THBITEimUpStWT0g4mp6OLMtS5/PaSLrou+/oCy+8gGq1hj5uBKzL9uHMDx3kQJX1b24e7t23D+fNm4cvvvgibdu2rUvt/nvGDLuqdH5BPrZr165+6lsxrN7Pz+8FkYH1YNRSqVQf1rf0SRo3Dm9n33YodS9cOI+tW8dUHD9u3Hgbgn/9zTc1EnJmlUF86+Yt/Pbbb7FHjx4olUr/0uTt1atXhTurevTnyVMnccqUKRgSEuK2RvLr9l+tIstolTTTuharI4Sgp6fndALitLdegIhEqVR+Xx8kDgkNxVWrVtUYf3g7+za+MmlShWtj8eLFNtpfghOjS3mAxrnz520udf/+fat0yMd5Cw5ujM2aNbPZv3LlSpvn1uv1+O6776JcLq/zdcPCwvD27dt2NadFixYhwzBuk1cul3/9xJTHeVjo37+/QiaTbanLS+/cuTNm37lTKz9rSspWjImJoenp6dUGow6jo6OdXm/QoEF2w5YXLVr0WJJVEAQa1TyKDh8+HBd8/jkeOHAA8/PzbQJjJBIe7Rmt1q1bZ2ea40cHPzcYP/30E0zZmoI7duzAJUuW4uDBg7FsVXsnxrE4ai/PGhEx7oUX3PNNS6XJST2TpCLjGgDdurX2lslkh9wdgP7+/rh4yRJqLy+4uLjYKl+46hG5ubkVtZbLrabnzp+rUQ1etWqVzYWMRpPdmsyPw/bZZ5/ZJMTfunULvb29aDUS4Hk70VOHjxzG6OhoGh0djRMmTqTr16+nt2/fdlj6a+3atahSqZze08ezZ9tc58effqTuFCkUBGFfeHi4h8i0BkTLli0bC4Jwti4Dcfjw4Vbq165du7BNTBscFR/v0E1RHStWLK9RtczJybEZlOnp6XYrQbo7F6yHdiiURZ7xEt5p3vW9e/ds+uE///mP3eNT96Ta7TedTucwcYNS20SrdWvXOX1OiSDgrl2WUsLnzp3DIXFx7lbyONu6detgkWEPAYGBgZHu+oihItyyBd2+fTtOnz7dKnspICAAv/vuO6Q1VC58/fWpTgfK1Nen2pUqb771Vr2Q18PDE/ft24f79u3DdevX4+cLPsdp06ZhXFwcdnz6aac5sz6+vti1a1ccOXIkzpw5E5OTk/FyZiZu3boVPT097T5XYtI4mz4o1eqwZcuWdq/xz2qRU66kZlAH9urhw4c7j2CLjMAFCxagj4+Pux/CS0FBQREisx4i/P39o3mev9xQ6uLw4cMdSmOTyYSdOndy6ls+ZCeuOT8/36WKEq5sr776qtNStc7qe0W1aIF//PGH3XO3b9+OHh4eNku3bNu2zYaMO3b85tA37efn56D/arH4DK0sPdRQPnCO4y5qNJrmIqP+BDRu1LhlXSWxczU4mKbu2UPtpeOp1WqHEjg2NtZuEbs1a9bUy30p5HI8d+6c07E/efJkp2pz9+7drYNXrErRbkaZTGYVFabV2iYTvPjiizWuWmHlqrODgoJC3Lt3H86ZMweXL1+ORqPJxvWUdfWq1f3U18bz/IVAkbx/ujrdnOO4iw1F4h9//MmGwLt373Z6zoIFC+yKlmeffbZe7mnM2LEuzNFX1Fwm57nnrFaosApNXLKkQup9+OGHtiV4r1yp0cBUHizzzTff4Nmz5zAvPx/z8wswI+MCbt68GadOnWoT4movVvripUso1LPfXCqVnmsW3CxcZNAjAB8fnwie58/VN3nVarXdgnmfzJvn8BxPT0+8evUqta3PlYkKhaLOkViCIGD6sWM1EjjzcqZL/tbExCRqKFs/qPpNz549GwVBgmfOnrV5njlz5tTaBRUUFIzBwcEOpWkjf3+8fv26zbWSNyTX63uVyWTHW0dEhInMeYTQvHnzJlKp9Eh9vujnnn3WLjmGDBni8Jz4+HiX8nbd3YYNHWa7HtLZszZuG6PRiE899ZRLbb7xxhv2p6BmM36/7HvUV5sOlJZqsWV0y/pLMZRI8Nlnn3WYqVS2dE7dNwIok0p3dujQwV9kzCOI2NhYH0EQttaXwaNfv370j2oSuKCw0GkIYEqVtY0qB3ypQ2ttbd1GVfOUq64yuHDhVzb735o2zeW2Z8+e43Jwy9Zt2+r8HP6N/LFfv344Z84cPHnypEOz1qZNm6y8BFCH8EiVQrGuY8eOop/3UcbgwYPlKoXiu/oicXBwMH7xxX9pYWEhLU9gcBSmFxUVZTWnLB+Mv277tX6qV1rKz1qN8RvXr6NcLqeJSUl1MpqxLIvLfljmEoHdkYiEEJw1axbduHEjPXXqlF2fMq2WXpiamooajaZeamspFIr5ixYt4kWGPAYoq+rxHsswhvpS82Jax9CdO3fiTz85DuCYMWOGzYIQZrO5Rj+mqwTbVZavXLX9mTNnVlS2rF4L6+rVqy4ZmqoYdnDjxo1OfTuXL19GlcrDrWdYvXq1y2Vwf/zxJ/TyqnvJX45ltRqN5m9ibPNjSGK12nN4lQXU6kWFDQoKclxZ8vw5m7FYWFiIQ4cNrXMAf5++fW0qbObm5mFI45Dyqpw0M/Myre4Prk3pmHLD3ZEjRxw6aT/++GO3n2HK5Mk1Svdjx4/RuLgh9TO35vmb/v7+g0Q2PMYICgqKESRCGjRwnPCQIUPQ0WIo5YamDz74AFu2bOmWJXpLyhabwf7tt99aHbN8+XLbkj+zZtU+YyskhJ4+/btdCTmqDgalDh062C1LlJeXh8nJyThs2FCUyWR1ttSXZRTtafEkrdn7FzdueapUqu/cTTFzRb3dWiVSyZlqWFpaiqmpqfj6669jeHi4S+136dLFJjCEomVR8lWrVuGn8+fjG2+8jps2b7K53p49e2rM6rE7ZYiJsVtv+r333nO/8qZchucvXKD5+fl4/MQJXLZsGSYmJmJoaJP6fBfUw8Pjv4MHDxZXTvgrgWEYUKvVSRzH36tvAjMMgx06dMAFC77Aa9euuWzNLSoqwg0bNtqstlh9S05OdnsFhgc5ORgYGFhrAkskEjxvJ5c5ZevWOlfeDAoKqpdSvLYqs+RWo0Y+8eJ89y+M0NDQKJlMtr2hYmvVajV98cXRNDk5meYXFNCajDY7d+50mnzeoUOHyuwdNxcgff755916lrVr19q0devWrUdiPSkbK7NcvjlCDM54MjBp0iReqVRO5zg2vyEHVnh4OE6fPt3Kz1kdY8aMcW65/Xm1Vb6dSxyudtB8Byl/NW3vvPOOnbWFTNixY8dHhrw8z9/XeHlNQURGHNlPGAIDA9spZLIdDTU3hoowQin279+fLlmyxCoPOTc312lpnZiYGLS3ovy2bdvokiVLaWrqHjxz5izev38fc3NzHebZHjlyxK0SM927d6f21pZ64803//TifAzDoFKh2BIRGiFWjXySMXPmTM7b2/tljuNvPIyB5+fnh0lJSfjbzp24cuUqp8f+ZMeqfP/+fatFvQRBQF9fXwwMDMQ2bdrgjGoVGxERS0pKXDaYgXVpXmqvBNG2OkZi1YPUveqrVo8Tpa6ICkRERATJ5fKvWZbVP6SBSJVOkhs6duxoV5p+9fXXzpdabRpGi4tLbKT2i6NHOy187uge9+7diyaTCS9duoSr16zBqVOnYps2bf4U4rIsq1MqlQujoqICxBErwgaEEPD19e0qewhqdU1b7z59cOnSpXjw4EHMysrC4uJiLCgowNatW9fo0jpmJylg8eLF1A0CY/v27bF9+/b1UkmyLuqyTCZLDQgI6CpamEXUCERk1Gr1CEEQTjwKqyF4eHhgaGioVZ1qqGE1hIIC66VVs7Kuokwqe6Ssx+BCQIYgCOc0Gs3YtWvXsuLItCN0xC5wjP79+yvS0tIStVrtGyaTKQoRH4v7lkgkEOAfACGhIeDt7Q2hoU1QIuHJ4sWLobCw8LHQhDiOu6mQKf7TLKLZT8ePHy8QR6MIt9GlSxeVp6fnJEEQzv/ZqvVfeSOEIM/z1708PN5v1apVI3HkiahX9OzZU+mrVo+TSqVpIpHrnbgXPT09p8XExPiJI01Eg2LRpEl8Ix+fwTKpdDvLsgaRhO4bpwRBSFOr1RNjY2M9xZEl4qHP1Ro3bvyUh9LjS57nrxMiSmVXpC3HcQ/kcvkqX1/fAZMmTRKT7EX82UQGiI6OVms0mpfkcvlGjuPyH8e1fKFhfbgGQRD2e3l5vREWFhYiuoNEPLJSOSQkpKmXl9drMplsJ8dxRU8qmVmWNUul0pOenqpZIQEh7RFRZK2IxwcMw0BUVFSkRqP5m1wu38Bx3O2GSKN7xNTjUkEQ0lQqz4+DgoKenjlzpkQcCQ0oMMQueHiSuU2bNr537tx5qri4tJ/RqO9sMpkiEVFDKX1sn4llWCPLsddYlk2XC/J93h7e+y9du3SxrIiACJHAf00gIomMjAwsLCxsr9Vq25pNpg5Gk6kFpbSx2WwWHrWgEUIIMAwDDMPksyxzleclJwRBOKpQKNIjIyMv7dq1q+RxCXQRCSyiQQgypt8YRdqltJB7RfeizAZzK0ppC5PJFAYEgswmsxoR5eUkaQiylBuWGIYxE0LyWZa7z7LMLZZlLwiccFaqkGZoNJor77///p34+HizSFiRwCJqIBQhBLp06eL94MED3+zs7CCe5/10Ol0oolnD80KIVqv1QECFhJdoqJkqDUYDoZSyAMAAAQJYKfMBCDKEMfMS3sgQkmc0mfIEXihlOCbbaDRmeyg97pXqSq9pNJocSunNYR07Fvx3/XqtSFSRwCIaiODl/37xxRfCgQMH+NTU3wml9xiFQsFSSklZxBgwRUVYxDDUz8+PdujQgS5fvlzHMIy5ikovdqgIESJEiBAhQoQIESJEiBAhQoQIESJEiBAhQoQIESJEiBAhQoQIESJEiBAhQoQIESJEiBAhQoQIESJEiBAhQoQIESJEiBAhQgQAwP8HMQu4Y7GYHlQAAAAASUVORK5CYII=";

// ---------- Brand / Company constants ----------
const WHATSAPP_NUMBER = "60149423628";
const BRAND = "TinyFootprint";
const COMPANY_NAME = "Tiny Footprint Enterprise";
const REG_NO = "202403209401 (003632231-D)";
const ADDRESS = "E-1-2, Jalan PPT 2, Pusat Perniagaan Templer, 70300 Seremban, Negeri Sembilan, Malaysia";

const SHIPPING = { west: 8, east: 15 };

const PLATFORM_LINKS = [
  { label: "Shopee Malaysia", url: "https://www.shopee.com.my/tinyfootprint" },
  { label: "Shopee Singapore", url: "https://shopee.sg/tinyfootprint.sg" },
  { label: "Lazada", url: "https://s.lazada.com.my/s.nHynN?dsource=share&laz_share_info=1529127404_100_1600_0_1529129404_null&laz_token=77ac568421c47225c696d366660115ab" },
  { label: "TikTok Shop", url: "https://vt.tiktok.com/ZSy3R3kQp/?page=TikTokShop" },
];

// ---------- Colors (derived from logo) ----------
const COLORS = {
  ink: "#111111",
  paper: "#EBEBEA",
  white: "#FFFFFF",
  orange: "#111111",
  green: "#555555",
  navy: "#333333",
  orangeSoft: "rgba(17,17,17,0.06)",
  accent: "#111111",
  mid: "#888888",
  border: "#D4D4D2",
};

const STORAGE_KEY = "products-v2";

// ---------- Helpers ----------
function formatRM(n) {
  return `RM${Number(n).toFixed(2)}`;
}
function genId() {
  return `p-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
function getBasePrice(product) {
  if (product.packs && product.packs.length) return product.packs[0].price;
  return product.price || 0;
}
function getBaseStock(product) {
  return product.stock ?? 999;
}

async function compressImage(file, maxDim = 640, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ---------- Trail divider ----------
function TrailDivider({ flip }) {
  return (
    <div style={{ width: "100%", overflow: "hidden", height: 26, opacity: 0.5 }} aria-hidden="true">
      <svg viewBox="0 0 600 28" preserveAspectRatio="none" style={{ width: "100%", height: "100%", transform: flip ? "scaleX(-1)" : "none" }}>
        <path
          d="M0 14 Q 25 2, 50 14 T 100 14 T 150 14 T 200 14 T 250 14 T 300 14 T 350 14 T 400 14 T 450 14 T 500 14 T 550 14 T 600 14"
          fill="none" stroke={COLORS.border} strokeWidth="1.5" strokeLinecap="round" strokeDasharray="1 9"
        />
      </svg>
    </div>
  );
}

// ---------- Toast ----------
function Toast({ message, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2400);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div style={{
      position: "fixed", bottom: 20, left: "50%", transform: "translateX(-50%)",
      background: COLORS.ink, color: COLORS.white, padding: "10px 18px", borderRadius: 999,
      fontSize: 13, fontFamily: "Inter, sans-serif", boxShadow: "0 6px 24px rgba(0,0,0,0.35)",
      display: "flex", alignItems: "center", gap: 8, zIndex: 200, whiteSpace: "nowrap",
    }}>
      <Check size={14} color={COLORS.orange} />
      {message}
    </div>
  );
}

// ---------- Nav ----------
function NavBar({ page, setPage, cartCount }) {
  const items = [
    { key: "home", label: "Home" },
    { key: "shop", label: "Shop" },
    { key: "cart", label: `Cart${cartCount ? ` (${cartCount})` : ""}` },
    { key: "about", label: "About" },
  ];
  return (
    <div style={{
      position: "sticky", top: 0, zIndex: 50, background: "rgba(17,17,17,0.94)",
      backdropFilter: "blur(6px)", borderBottom: "1px solid rgba(255,255,255,0.08)",
    }}>
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "12px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <button onClick={() => setPage("home")} style={{ display: "flex", alignItems: "center", gap: 9, background: "none", border: "none", cursor: "pointer", padding: 0 }}>
          <img src={LOGO_BASE64} alt={BRAND} style={{ width: 34, height: 34, borderRadius: 3 }} />
          <span style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 20, color: COLORS.white, letterSpacing: "0.15em", textTransform: "uppercase", fontWeight: 700 }}>{BRAND}</span>
        </button>
        <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
          {items.map((it) => (
            <button key={it.key} onClick={() => setPage(it.key)} style={{
              background: page === it.key ? "rgba(255,106,0,0.15)" : "none", border: "none",
              color: page === it.key ? COLORS.orange : "rgba(255,255,255,0.65)",
              fontFamily: "Inter, sans-serif", fontSize: 11, padding: "7px 12px", borderRadius: 999, cursor: "pointer", letterSpacing: "0.08em", textTransform: "uppercase",
            }}>
              {it.label}
            </button>
          ))}
          <button onClick={() => setPage("admin")} aria-label="Manage products" style={{
            background: "none", border: "none", color: page === "admin" ? COLORS.orange : "rgba(255,255,255,0.4)",
            cursor: "pointer", padding: "7px 9px", display: "flex", alignItems: "center",
          }}>
            <Settings size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------- Home Page ----------
function HomePage({ setPage, products }) {
  const featured = products.slice(0, 3);
  return (
    <div>
      <section style={{ maxWidth: 1080, margin: "0 auto", padding: "64px 20px 36px", textAlign: "center" }}>
        <img src={LOGO_BASE64} alt={BRAND} style={{ width: 96, height: 96, borderRadius: 3, marginBottom: 22 }} />
        <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12, letterSpacing: 2.5, textTransform: "uppercase", color: COLORS.green, marginBottom: 16 }}>
          BIOACTIVE CLEANUP CREWS
        </div>
        <h1 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "clamp(44px, 8vw, 82px)", lineHeight: 0.95, color: COLORS.ink, margin: "0 0 18px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "-0.01em" }}>
          Small creatures.
          Enormous work.
        </h1>
        <p style={{ fontFamily: "Inter, sans-serif", fontSize: 15.5, color: "rgba(17,17,17,0.65)", maxWidth: 460, margin: "0 auto 30px", lineHeight: 1.65 }}>
          Isopods, springtails, terrariums and everything between — cultured
          and curated by Tiny Footprint Enterprise, Malaysia.
        </p>
        <button onClick={() => setPage("shop")} style={{
          background: COLORS.orange, color: COLORS.white, border: "none", padding: "13px 28px",
          borderRadius: 999, fontFamily: "Inter, sans-serif", fontSize: 14, fontWeight: 600, cursor: "pointer", letterSpacing: 0.3,
        }}>
          Browse the catalog
        </button>
      </section>

      <TrailDivider />

      <section style={{ maxWidth: 1080, margin: "0 auto", padding: "44px 20px 16px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 22 }}>
          <h2 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 26, color: COLORS.ink, margin: 0, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em" }}>Popular Picks</h2>
          <button onClick={() => setPage("shop")} style={{ background: "none", border: "none", color: COLORS.green, fontFamily: "Inter, sans-serif", fontSize: 13, cursor: "pointer" }}>
            View all →
          </button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
          {featured.map((p) => (
            <div key={p.id} onClick={() => setPage("shop")} style={{
              background: COLORS.white, border: "1px solid rgba(17,17,17,0.08)", borderRadius: 4, padding: 16, cursor: "pointer",
            }}>
              <div style={{
                width: "100%", aspectRatio: "1.4", borderRadius: 3,
                background: p.image ? `url(${p.image}) center/cover` : "rgba(62,125,79,0.08)",
                marginBottom: 13, display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                {!p.image && <Leaf size={24} color={COLORS.green} opacity={0.45} />}
              </div>
              <div style={{ fontFamily: "Inter, sans-serif", fontSize: 9.5, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 6, fontWeight: 600 }}>{p.category}</div>
              <div style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 16, color: COLORS.ink, marginBottom: 5, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.02em" }}>{p.name}</div>
              <div style={{ fontFamily: "Inter, sans-serif", fontSize: 13.5, color: COLORS.orange, fontWeight: 600 }}>from {formatRM(getBasePrice(p))}</div>
            </div>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1080, margin: "0 auto", padding: "52px 20px 36px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 26 }}>
        {[
          { t: "Healthy stock only", d: "We hold culture back from sale until it's dense enough to ship without setback." },
          { t: "Pickup or delivery", d: "Collect at our Seremban location, or have it shipped anywhere in Malaysia." },
          { t: "Order over WhatsApp", d: "Confirm your basket and we'll sort packing, pickup, or shipping with you directly." },
        ].map((f, i) => (
          <div key={i}>
            <div style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 16, color: COLORS.ink, marginBottom: 7 }}>{f.t}</div>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 13.5, color: "rgba(17,17,17,0.55)", lineHeight: 1.6 }}>{f.d}</div>
          </div>
        ))}
      </section>

      <TrailDivider flip />

      <section style={{ maxWidth: 1080, margin: "0 auto", padding: "40px 20px 80px", textAlign: "center" }}>
        <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12, letterSpacing: 1.5, textTransform: "uppercase", color: "rgba(17,17,17,0.4)", marginBottom: 14 }}>
          ALSO FIND US ON
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
          {PLATFORM_LINKS.map((l) => (
            <a key={l.label} href={l.url} target="_blank" rel="noopener noreferrer" style={{
              display: "flex", alignItems: "center", gap: 6, background: COLORS.white, border: "1px solid rgba(17,17,17,0.12)",
              borderRadius: 2, padding: "8px 16px", fontFamily: "Inter, sans-serif", fontSize: 11.5, color: COLORS.ink, textDecoration: "none", letterSpacing: "0.05em", textTransform: "uppercase", fontWeight: 600,
            }}>
              {l.label} <ExternalLink size={11} />
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}

// ---------- Pack selector ----------
function PackPicker({ packs, selected, onSelect }) {
  return (
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
      {packs.map((pk, i) => (
        <button key={i} onClick={() => onSelect(i)} style={{
          background: selected === i ? COLORS.ink : "rgba(17,17,17,0.05)",
          color: selected === i ? COLORS.white : COLORS.ink,
          border: "none", borderRadius: 3, padding: "6px 10px", fontFamily: "Inter, sans-serif",
          fontSize: 11.5, cursor: "pointer", lineHeight: 1.3,
        }}>
          {pk.label}<br /><span style={{ fontWeight: 600 }}>{formatRM(pk.price)}</span>
        </button>
      ))}
    </div>
  );
}

// ---------- Product Detail Page ----------
function ProductDetail({ product, cart, addToCart, onBack }) {
  const hasPacks = !!(product.packs && product.packs.length > 0);
  const stock = getBaseStock(product);
  const outOfStock = stock <= 0;
  const [packIndex, setPackIndex] = useState(0);
  const activePack = product.packs ? product.packs[packIndex] : null;
  const displayPrice = activePack ? activePack.price : product.price;
  const cartKey = product.packs ? `${product.id}::${packIndex}` : product.id;
  const cartQty = cart[cartKey]?.qty || 0;

  return (
    <div style={{ maxWidth: 860, margin: "0 auto", padding: "32px 20px 80px" }}>
      {/* Back button */}
      <button onClick={onBack} style={{
        background: "none", border: "none", color: COLORS.mid, fontFamily: "Inter, sans-serif",
        fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
        marginBottom: 28, padding: 0, letterSpacing: "0.08em", textTransform: "uppercase",
      }}>
        <ChevronLeft size={14} /> Back to catalog
      </button>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        {/* Left: image */}
        <div>
          <div style={{
            width: "100%", aspectRatio: "1", borderRadius: 4,
            background: product.image ? `url(${product.image}) center/cover` : "rgba(17,17,17,0.05)",
            display: "flex", alignItems: "center", justifyContent: "center",
            border: "1px solid rgba(17,17,17,0.08)",
          }}>
            {!product.image && <Leaf size={40} color={COLORS.mid} opacity={0.3} />}
          </div>
        </div>

        {/* Right: info */}
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.14em", fontWeight: 600, marginBottom: 8 }}>
            {product.category}
          </div>
          <h1 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 32, fontWeight: 800, color: COLORS.ink, margin: "0 0 14px", textTransform: "uppercase", letterSpacing: "0.02em", lineHeight: 1.05 }}>
            {product.name}
          </h1>
          <p style={{ fontFamily: "Inter, sans-serif", fontSize: 14, color: "rgba(17,17,17,0.6)", lineHeight: 1.65, margin: "0 0 22px" }}>
            {product.desc}
          </p>

          {/* Pack selector */}
          {hasPacks && (
            <div style={{ marginBottom: 18 }}>
              <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.12em", fontWeight: 700, marginBottom: 8 }}>
                Pack size
              </div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {product.packs.map((pk, i) => (
                  <button key={i} onClick={() => setPackIndex(i)} style={{
                    background: packIndex === i ? COLORS.ink : "transparent",
                    color: packIndex === i ? COLORS.white : COLORS.ink,
                    border: `1px solid ${packIndex === i ? COLORS.ink : "rgba(17,17,17,0.2)"}`,
                    borderRadius: 2, padding: "8px 14px", fontFamily: "Inter, sans-serif",
                    fontSize: 12, cursor: "pointer", lineHeight: 1.4, textAlign: "left",
                  }}>
                    <div style={{ fontWeight: 600 }}>{pk.label}</div>
                    <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>{formatRM(pk.price)}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Price + stock */}
          <div style={{ display: "flex", alignItems: "baseline", gap: 14, marginBottom: 20 }}>
            <span style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 34, fontWeight: 800, color: COLORS.ink }}>
              {formatRM(displayPrice)}
            </span>
            {!hasPacks && (
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: COLORS.mid }}>
                per {product.unit}
              </span>
            )}
            <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: outOfStock ? COLORS.mid : "rgba(17,17,17,0.4)", marginLeft: "auto" }}>
              {outOfStock ? "OUT OF STOCK" : stock < 999 ? `${stock} IN STOCK` : "IN STOCK"}
            </span>
          </div>

          <button onClick={() => addToCart(product, packIndex)} disabled={outOfStock} style={{
            background: outOfStock ? "rgba(17,17,17,0.08)" : COLORS.ink,
            color: outOfStock ? "rgba(17,17,17,0.3)" : COLORS.white,
            border: "none", borderRadius: 3, padding: "14px 0", fontFamily: "Inter, sans-serif",
            fontSize: 13, fontWeight: 700, cursor: outOfStock ? "default" : "pointer",
            letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 10,
          }}>
            {outOfStock ? "UNAVAILABLE" : cartQty > 0 ? `ADD ANOTHER (${cartQty} IN CART)` : "ADD TO CART"}
          </button>

          <p style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: COLORS.mid, margin: 0, lineHeight: 1.5 }}>
            Order confirmed via WhatsApp. Shipping RM8 (West) / RM15 (East) or self-pickup in Seremban.
          </p>
        </div>
      </div>

      {/* Care guide — full width below */}
      {product.care && (
        <div style={{ marginTop: 40, borderTop: "1px solid rgba(17,17,17,0.1)", paddingTop: 32 }}>
          <div style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 22, fontWeight: 800, color: COLORS.ink, textTransform: "uppercase", letterSpacing: "0.03em", marginBottom: 20 }}>
            Care Guide
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: product.care.notes ? 20 : 0 }}>
            {[
              { icon: "🌡️", label: "Temperature", value: product.care.temperature },
              { icon: "💧", label: "Humidity", value: product.care.humidity },
              { icon: "🌿", label: "Substrate", value: product.care.substrate },
              { icon: "🍂", label: "Food", value: product.care.food },
            ].filter(r => r.value).map(r => (
              <div key={r.label} style={{ background: COLORS.white, border: "1px solid rgba(17,17,17,0.08)", borderRadius: 3, padding: "14px 16px" }}>
                <div style={{ fontSize: 18, marginBottom: 6 }}>{r.icon}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.1em", fontWeight: 700, marginBottom: 4 }}>{r.label}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: COLORS.ink, lineHeight: 1.45 }}>{r.value}</div>
              </div>
            ))}
          </div>
          {product.care.notes && (
            <div style={{ background: COLORS.white, border: "1px solid rgba(17,17,17,0.08)", borderRadius: 3, padding: "14px 16px" }}>
              <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.1em", fontWeight: 700, marginBottom: 6 }}>📝 Notes</div>
              <div style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: "rgba(17,17,17,0.65)", lineHeight: 1.6 }}>{product.care.notes}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ---------- Shop Page ----------
function ShopPage({ products, cart, addToCart }) {
  const [filter, setFilter] = useState("All");
  const presentCats = ["All", ...CATEGORIES.filter((c) => c !== "All" && products.some((p) => p.category === c))];
  const filtered = filter === "All" ? products : products.filter((p) => p.category === filter);
  const [packChoice, setPackChoice] = useState({});
  const [detailId, setDetailId] = useState(null);

  const detailProduct = detailId ? products.find(p => p.id === detailId) : null;

  if (detailProduct) {
    return (
      <ProductDetail
        product={detailProduct}
        cart={cart}
        addToCart={addToCart}
        onBack={() => setDetailId(null)}
      />
    );
  }

  return (
    <div style={{ maxWidth: 1080, margin: "0 auto", padding: "36px 20px 80px" }}>
      <h1 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 36, color: COLORS.ink, marginBottom: 6, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.02em" }}>The Catalog</h1>
      <p style={{ fontFamily: "Inter, sans-serif", fontSize: 14, color: "rgba(17,17,17,0.55)", marginBottom: 24 }}>
        {filtered.length} {filtered.length === 1 ? "listing" : "listings"} available
      </p>

      <div style={{ display: "flex", gap: 7, marginBottom: 28, flexWrap: "wrap" }}>
        {presentCats.map((c) => (
          <button key={c} onClick={() => setFilter(c)} style={{
            background: filter === c ? COLORS.ink : "transparent",
            border: `1px solid ${filter === c ? COLORS.ink : "rgba(17,17,17,0.18)"}`,
            color: filter === c ? COLORS.white : "rgba(17,17,17,0.55)",
            fontFamily: "Inter, sans-serif", fontSize: 11, padding: "5px 13px", letterSpacing: "0.08em", textTransform: "uppercase", borderRadius: 2, cursor: "pointer",
          }}>
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="Nothing in this category yet" body="New listings are added as stock becomes available. Check back soon." />
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(225px, 1fr))", gap: 18 }}>
          {filtered.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              cartQty={cart[p.id]?.qty || 0}
              packIndex={packChoice[p.id] || 0}
              setPackIndex={(i) => setPackChoice((s) => ({ ...s, [p.id]: i }))}
              onAdd={(packIndex) => addToCart(p, packIndex)}
              onDetail={() => setDetailId(p.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ---------- Care Guide ----------
function CareGuide({ care }) {
  const rows = [
    { icon: "🌡️", label: "Temperature", value: care.temperature },
    { icon: "💧", label: "Humidity", value: care.humidity },
    { icon: "🌿", label: "Substrate", value: care.substrate },
    { icon: "🍂", label: "Food", value: care.food },
  ];
  return (
    <div style={{ background: "rgba(17,17,17,0.04)", border: "1px solid rgba(17,17,17,0.12)", borderRadius: 3, padding: "11px 13px", marginBottom: 12 }}>
      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 9, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.14em", fontWeight: 700, marginBottom: 8 }}>
        Care Guide
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
        {rows.map(r => (
          <div key={r.label} style={{ display: "flex", gap: 7, alignItems: "flex-start" }}>
            <span style={{ fontSize: 11, minWidth: 18 }}>{r.icon}</span>
            <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(17,17,17,0.55)", lineHeight: 1.4 }}>
              <strong style={{ color: COLORS.ink, fontWeight: 600 }}>{r.label}:</strong> {r.value}
            </span>
          </div>
        ))}
        {care.notes && (
          <div style={{ display: "flex", gap: 7, alignItems: "flex-start", marginTop: 3, paddingTop: 6, borderTop: "1px solid rgba(62,125,79,0.15)" }}>
            <span style={{ fontSize: 11, minWidth: 18 }}>📝</span>
            <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(17,17,17,0.5)", lineHeight: 1.4, fontStyle: "normal" }}>{care.notes}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function ProductCard({ product, onAdd, cartQty, packIndex, setPackIndex, onDetail }) {
  const hasPacks = !!(product.packs && product.packs.length > 1);
  const stock = getBaseStock(product);
  const outOfStock = stock <= 0;
  const activePack = product.packs ? product.packs[packIndex] : null;
  const displayPrice = activePack ? activePack.price : product.price;

  return (
    <div style={{ background: COLORS.white, border: "1px solid rgba(17,17,17,0.08)", borderRadius: 4, padding: 15, display: "flex", flexDirection: "column" }}>
      <div
        onClick={onDetail}
        style={{
          width: "100%", aspectRatio: "1.3", borderRadius: 3,
          background: product.image ? `url(${product.image}) center/cover` : "rgba(17,17,17,0.05)",
          marginBottom: 13, display: "flex", alignItems: "center", justifyContent: "center",
          position: "relative", cursor: "pointer",
        }}>
        {!product.image && <Leaf size={22} color={COLORS.mid} opacity={0.35} />}
        {outOfStock && (
          <div style={{
            position: "absolute", top: 8, left: 8, background: "rgba(17,17,17,0.85)", color: COLORS.white,
            fontSize: 10, padding: "3px 8px", borderRadius: 2, fontFamily: "Inter, sans-serif", letterSpacing: 0.5, textTransform: "uppercase",
          }}>
            Sold out
          </div>
        )}
      </div>
      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 9.5, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.14em", marginBottom: 6, fontWeight: 600 }}>{product.category}</div>
      <div
        onClick={onDetail}
        style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 17, color: COLORS.ink, marginBottom: 5, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.03em", cursor: "pointer" }}
      >
        {product.name}
      </div>
      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(17,17,17,0.5)", lineHeight: 1.5, marginBottom: 10, flexGrow: 1 }}>{product.desc}</div>

      <button onClick={onDetail} style={{
        background: "none", border: "none", padding: "0 0 10px 0", fontFamily: "Inter, sans-serif",
        fontSize: 10.5, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.1em",
        cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", gap: 4,
      }}>
        VIEW DETAILS →
      </button>

      {hasPacks && <PackPicker packs={product.packs} selected={packIndex} onSelect={setPackIndex} />}

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <span style={{ fontFamily: "Inter, sans-serif", fontSize: 14.5, color: COLORS.orange, fontWeight: 600 }}>
          {formatRM(displayPrice)}
          {!hasPacks && <span style={{ fontSize: 11, color: "rgba(17,17,17,0.4)", fontWeight: 400 }}> /{product.unit}</span>}
        </span>
        <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(17,17,17,0.4)" }}>
          {stock < 999 ? `${stock} in stock` : "In stock"}
        </span>
      </div>
      <button onClick={() => onAdd(packIndex)} disabled={outOfStock} style={{
        background: outOfStock ? "rgba(17,17,17,0.06)" : COLORS.ink,
        color: outOfStock ? "rgba(17,17,17,0.3)" : COLORS.white,
        border: "none", borderRadius: 3, padding: "10px 0", fontFamily: "Inter, sans-serif", fontSize: 13, fontWeight: 600, cursor: outOfStock ? "default" : "pointer",
      }}>
        {outOfStock ? "UNAVAILABLE" : cartQty > 0 ? `ADD ANOTHER (${cartQty})` : "ADD TO CART"}
      </button>
    </div>
  );
}

function EmptyState({ title, body }) {
  return (
    <div style={{ border: "1px dashed rgba(17,17,17,0.18)", borderRadius: 4, padding: "48px 24px", textAlign: "center" }}>
      <Leaf size={22} color={COLORS.green} opacity={0.5} style={{ marginBottom: 14 }} />
      <div style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 18, color: COLORS.ink, marginBottom: 8 }}>{title}</div>
      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 13.5, color: "rgba(17,17,17,0.5)", maxWidth: 360, margin: "0 auto", lineHeight: 1.6 }}>{body}</div>
    </div>
  );
}

// ---------- Cart Page ----------
function CartPage({ cart, products, updateQty, removeFromCart, setPage }) {
  const items = Object.entries(cart)
    .map(([key, c]) => {
      const product = products.find((p) => p.id === c.productId);
      if (!product) return null;
      const pack = product.packs ? product.packs[c.packIndex] : null;
      return { key, product, pack, qty: c.qty };
    })
    .filter(Boolean);

  const subtotal = items.reduce((sum, it) => sum + (it.pack ? it.pack.price : it.product.price) * it.qty, 0);

  const [customerName, setCustomerName] = useState("");
  const [note, setNote] = useState("");
  const [region, setRegion] = useState("west");
  const [fulfillment, setFulfillment] = useState("delivery");

  const shippingFee = fulfillment === "pickup" ? 0 : SHIPPING[region];
  const total = subtotal + shippingFee;

  const handleCheckout = () => {
    if (items.length === 0) return;
    let msg = `Hi ${BRAND}! I'd like to order:\n\n`;
    items.forEach((it) => {
      const unitPrice = it.pack ? it.pack.price : it.product.price;
      const label = it.pack ? `${it.product.name} (${it.pack.label})` : it.product.name;
      msg += `• ${label} x${it.qty} (${formatRM(unitPrice * it.qty)})\n`;
    });
    msg += `\nSubtotal: ${formatRM(subtotal)}`;
    if (fulfillment === "pickup") {
      msg += `\nFulfillment: Self pickup at Seremban`;
    } else {
      msg += `\nFulfillment: Delivery (${region === "west" ? "West Malaysia" : "East Malaysia"})`;
      msg += `\nShipping fee: ${formatRM(shippingFee)}`;
    }
    msg += `\nTotal: ${formatRM(total)}`;
    if (customerName.trim()) msg += `\n\nName: ${customerName.trim()}`;
    if (note.trim()) msg += `\nNote: ${note.trim()}`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  };

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "36px 20px 80px" }}>
      <h1 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 36, color: COLORS.ink, marginBottom: 26, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.02em" }}>Your Cart</h1>

      {items.length === 0 ? (
        <>
          <EmptyState title="Your cart is empty" body="Wander over to the catalog and pick out something for the terrarium." />
          <div style={{ textAlign: "center", marginTop: 24 }}>
            <button onClick={() => setPage("shop")} style={{
              background: COLORS.orange, color: COLORS.white, border: "none", padding: "12px 26px", borderRadius: 999,
              fontFamily: "Inter, sans-serif", fontSize: 13.5, fontWeight: 600, cursor: "pointer",
            }}>
              Go to shop
            </button>
          </div>
        </>
      ) : (
        <>
          <div style={{ display: "flex", flexDirection: "column", gap: 11, marginBottom: 26 }}>
            {items.map((it) => (
              <div key={it.key} style={{
                display: "flex", alignItems: "center", gap: 13, background: COLORS.white,
                border: "1px solid rgba(17,17,17,0.08)", borderRadius: 4, padding: 13,
              }}>
                <div style={{
                  width: 52, height: 52, borderRadius: 3, flexShrink: 0,
                  background: it.product.image ? `url(${it.product.image}) center/cover` : "rgba(62,125,79,0.08)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>
                  {!it.product.image && <Leaf size={15} color={COLORS.green} opacity={0.45} />}
                </div>
                <div style={{ flexGrow: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 14.5, color: COLORS.ink, marginBottom: 2 }}>{it.product.name}</div>
                  <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(17,17,17,0.5)" }}>
                    {it.pack ? it.pack.label : it.product.unit} · {formatRM(it.pack ? it.pack.price : it.product.price)}
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 7, flexShrink: 0 }}>
                  <button onClick={() => updateQty(it.key, it.qty - 1)} style={qtyBtnStyle} aria-label="Decrease quantity"><Minus size={12} /></button>
                  <span style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: COLORS.ink, minWidth: 18, textAlign: "center" }}>{it.qty}</span>
                  <button onClick={() => updateQty(it.key, it.qty + 1)} style={qtyBtnStyle} aria-label="Increase quantity"><Plus size={12} /></button>
                  <button onClick={() => removeFromCart(it.key)} style={{ ...qtyBtnStyle, marginLeft: 4, color: COLORS.orange }} aria-label="Remove item"><Trash2 size={12} /></button>
                </div>
              </div>
            ))}
          </div>

          <div style={{ marginBottom: 20 }}>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(17,17,17,0.5)", marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.6 }}>
              Fulfillment
            </div>
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              {[{ k: "delivery", l: "DELIVERY" }, { k: "pickup", l: "SELF PICKUP — SEREMBAN" }].map((opt) => (
                <button key={opt.k} onClick={() => setFulfillment(opt.k)} style={{
                  flex: 1, background: fulfillment === opt.k ? COLORS.ink : "rgba(17,17,17,0.05)",
                  color: fulfillment === opt.k ? COLORS.white : COLORS.ink, border: "none", borderRadius: 3,
                  padding: "10px 0", fontFamily: "Inter, sans-serif", fontSize: 12.5, cursor: "pointer",
                }}>
                  {opt.l}
                </button>
              ))}
            </div>
            {fulfillment === "delivery" ? (
              <div style={{ display: "flex", gap: 8 }}>
                {[{ k: "west", l: `WEST MALAYSIA — RM${SHIPPING.west}` }, { k: "east", l: `EAST MALAYSIA — RM${SHIPPING.east}` }].map((opt) => (
                  <button key={opt.k} onClick={() => setRegion(opt.k)} style={{
                    flex: 1, background: region === opt.k ? COLORS.green : "rgba(17,17,17,0.05)",
                    color: region === opt.k ? COLORS.white : COLORS.ink, border: "none", borderRadius: 3,
                    padding: "9px 0", fontFamily: "Inter, sans-serif", fontSize: 12, cursor: "pointer",
                  }}>
                    {opt.l}
                  </button>
                ))}
              </div>
            ) : (
              <div style={{
                display: "flex", alignItems: "flex-start", gap: 8, background: "rgba(17,17,17,0.05)",
                borderRadius: 3, padding: "10px 12px", fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(17,17,17,0.65)", lineHeight: 1.5,
              }}>
                <MapPin size={14} color={COLORS.green} style={{ marginTop: 1, flexShrink: 0 }} />
                {ADDRESS}
              </div>
            )}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 22 }}>
            <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Your name (optional)" style={inputStyle} />
            <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Note — pickup time, delivery address, etc. (optional)" rows={3} style={{ ...inputStyle, resize: "vertical", fontFamily: "Inter, sans-serif" }} />
          </div>

          <div style={{ borderTop: "1px solid rgba(17,17,17,0.12)", paddingTop: 16, marginBottom: 22 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: "rgba(17,17,17,0.55)" }}>Subtotal</span>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: COLORS.ink }}>{formatRM(subtotal)}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14 }}>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: "rgba(17,17,17,0.55)" }}>
                {fulfillment === "pickup" ? "PICKUP" : "SHIPPING"}
              </span>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: COLORS.ink }}>
                {shippingFee === 0 ? "FREE" : formatRM(shippingFee)}
              </span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 14, color: "rgba(17,17,17,0.6)" }}>Total</span>
              <span style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 25, color: COLORS.ink }}>{formatRM(total)}</span>
            </div>
          </div>

          <button onClick={handleCheckout} style={{
            width: "100%", background: "#25D366", color: "#06340f", border: "none", padding: "15px 0",
            borderRadius: 3, fontFamily: "Inter, sans-serif", fontSize: 14.5, fontWeight: 700, cursor: "pointer",
          }}>
            CONFIRM ORDER VIA WHATSAPP
          </button>
          <p style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(17,17,17,0.45)", textAlign: "center", marginTop: 12 }}>
            This opens WhatsApp with your order summary pre-filled. Nothing is charged here — we'll confirm payment and shipping with you directly.
          </p>
        </>
      )}
    </div>
  );
}

const qtyBtnStyle = {
  width: 24, height: 24, borderRadius: 2, border: "1px solid rgba(17,17,17,0.15)",
  background: "transparent", color: COLORS.ink, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
};

const inputStyle = {
  width: "100%", background: COLORS.white, border: "1px solid rgba(17,17,17,0.15)", borderRadius: 3,
  padding: "11px 13px", color: COLORS.ink, fontFamily: "Inter, sans-serif", fontSize: 13.5, outline: "none", boxSizing: "border-box",
};

// ---------- About Page ----------
function AboutPage() {
  return (
    <div style={{ maxWidth: 680, margin: "0 auto", padding: "44px 20px 80px" }}>
      <img src={LOGO_BASE64} alt={BRAND} style={{ width: 72, height: 72, borderRadius: 3, marginBottom: 20 }} />
      <h1 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 34, color: COLORS.ink, marginBottom: 18, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.02em" }}>About</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 16, marginBottom: 30 }}>
        <InfoRow label="Company">{COMPANY_NAME}</InfoRow>
        <InfoRow label="Registration No.">{REG_NO}</InfoRow>
        <InfoRow label="Pickup location">{ADDRESS}</InfoRow>
        <InfoRow label="Shipping fees">West Malaysia {formatRM(SHIPPING.west)} · East Malaysia {formatRM(SHIPPING.east)} (orders via WhatsApp)</InfoRow>
      </div>

      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(17,17,17,0.5)", marginBottom: 12, textTransform: "uppercase", letterSpacing: 0.6 }}>
        Find us elsewhere
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {PLATFORM_LINKS.map((l) => (
          <a key={l.label} href={l.url} target="_blank" rel="noopener noreferrer" style={{
            display: "flex", alignItems: "center", justifyContent: "space-between", background: COLORS.white,
            border: "1px solid rgba(17,17,17,0.1)", borderRadius: 3, padding: "12px 16px",
            fontFamily: "Inter, sans-serif", fontSize: 13.5, color: COLORS.ink, textDecoration: "none",
          }}>
            {l.label} <ExternalLink size={13} color={COLORS.green} />
          </a>
        ))}
      </div>
    </div>
  );
}

function InfoRow({ label, children }) {
  return (
    <div>
      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 4, fontSize: 10, fontWeight: 700 }}>{label}</div>
      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 14, color: COLORS.ink, lineHeight: 1.5 }}>{children}</div>
    </div>
  );
}

// ---------- Admin Page ----------
function AdminPage({ products, saveProducts, showToast }) {
  const [editing, setEditing] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [search, setSearch] = useState("");

  const handleSave = (product) => {
    let next;
    if (editing === "new") {
      next = [...products, { ...product, id: genId() }];
    } else {
      next = products.map((p) => (p.id === product.id ? product : p));
    }
    saveProducts(next);
    setEditing(null);
    showToast(editing === "new" ? "Product added" : "Product updated");
  };

  const handleDelete = (id) => {
    saveProducts(products.filter((p) => p.id !== id));
    setConfirmDelete(null);
    showToast("Product removed");
  };

  const filtered = search.trim()
    ? products.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()) || p.category.toLowerCase().includes(search.toLowerCase()))
    : products;

  if (editing) {
    return <ProductEditor product={editing === "new" ? null : editing} onCancel={() => setEditing(null)} onSave={handleSave} />;
  }

  return (
    <div style={{ maxWidth: 820, margin: "0 auto", padding: "36px 20px 80px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8, flexWrap: "wrap", gap: 10 }}>
        <h1 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 34, color: COLORS.ink, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.02em", margin: 0 }}>Manage Products</h1>
        <button onClick={() => setEditing("new")} style={{
          background: COLORS.orange, color: COLORS.white, border: "none", padding: "10px 18px", borderRadius: 999,
          fontFamily: "Inter, sans-serif", fontSize: 13, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
        }}>
          <Plus size={14} /> Add product
        </button>
      </div>
      <p style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: "rgba(17,17,17,0.5)", marginBottom: 18 }}>
        {products.length} products total. Changes save automatically and appear in the shop right away.
      </p>
      <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="SEARCH BY NAME OR CATEGORY" style={{ ...inputStyle, marginBottom: 22 }} />

      {filtered.length === 0 ? (
        <EmptyState title="No products found" body="Try a different search, or add a new product." />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
          {filtered.map((p) => (
            <div key={p.id} style={{
              display: "flex", alignItems: "center", gap: 13, background: COLORS.white,
              border: "1px solid rgba(17,17,17,0.08)", borderRadius: 4, padding: 11,
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 3, flexShrink: 0,
                background: p.image ? `url(${p.image}) center/cover` : "rgba(62,125,79,0.08)",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                {!p.image && <Leaf size={13} color={COLORS.green} opacity={0.45} />}
              </div>
              <div style={{ flexGrow: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 15, color: COLORS.ink, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.03em" }}>{p.name}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(17,17,17,0.5)" }}>
                  {p.packs ? `${p.packs.length} pack option${p.packs.length > 1 ? "s" : ""} from ${formatRM(getBasePrice(p))}` : `${formatRM(p.price)} · ${p.stock} ${p.unit} in stock`} · {p.category}
                </div>
              </div>
              <button onClick={() => setEditing(p)} style={{ ...qtyBtnStyle, width: "auto", padding: "0 12px", height: 30, fontFamily: "Inter, sans-serif", fontSize: 12 }}>EDIT</button>
              {confirmDelete === p.id ? (
                <div style={{ display: "flex", gap: 6 }}>
                  <button onClick={() => handleDelete(p.id)} style={{ ...qtyBtnStyle, width: "auto", padding: "0 10px", height: 30, color: COLORS.orange, fontFamily: "Inter, sans-serif", fontSize: 12 }}>CONFIRM</button>
                  <button onClick={() => setConfirmDelete(null)} style={{ ...qtyBtnStyle, width: 30, height: 30 }}><X size={12} /></button>
                </div>
              ) : (
                <button onClick={() => setConfirmDelete(p.id)} style={{ ...qtyBtnStyle, width: 30, height: 30, color: "rgba(17,17,17,0.4)" }} aria-label="Delete product"><Trash2 size={13} /></button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const EMPTY_CARE = { temperature: "", humidity: "", substrate: "", food: "", notes: "" };

function ProductEditor({ product, onCancel, onSave }) {
  const usesPacks = !!(product?.packs);
  const [form, setForm] = useState(
    product
      ? { ...product, packs: product.packs ? product.packs.map((p) => ({ ...p })) : null, care: product.care ? { ...product.care } : null }
      : { name: "", category: "Isopod", price: "", stock: "", unit: "pcs", desc: "", image: "", packs: null, care: null }
  );
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef(null);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleFile = async (file) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { setError("Please choose an image file."); return; }
    setUploading(true);
    setError("");
    try {
      const dataUrl = await compressImage(file);
      setForm((f) => ({ ...f, image: dataUrl }));
    } catch {
      setError("Could not read that image — try a different file.");
    } finally {
      setUploading(false);
    }
  };

  const togglePackMode = () => {
    setForm((f) => {
      if (f.packs) {
        return { ...f, packs: null, price: f.packs[0]?.price ?? "", stock: f.stock || "" };
      }
      return { ...f, packs: [{ label: "1 pc", qty: 1, price: Number(f.price) || 0 }] };
    });
  };

  const updatePack = (i, key, val) => {
    setForm((f) => {
      const packs = f.packs.map((p, idx) => (idx === i ? { ...p, [key]: val } : p));
      return { ...f, packs };
    });
  };
  const addPack = () => setForm((f) => ({ ...f, packs: [...f.packs, { label: "", qty: 1, price: 0 }] }));
  const removePack = (i) => setForm((f) => ({ ...f, packs: f.packs.filter((_, idx) => idx !== i) }));

  const handleSubmit = () => {
    if (!form.name.trim()) return setError("Give the product a name.");
    if (form.packs) {
      if (form.packs.length === 0) return setError("Add at least one pack option.");
      for (const pk of form.packs) {
        if (!pk.label.trim()) return setError("Every pack needs a label.");
        if (isNaN(Number(pk.price)) || Number(pk.price) < 0) return setError("Every pack needs a valid price.");
      }
      setError("");
      onSave({
        id: product?.id, name: form.name.trim(), category: form.category, unit: form.unit || "pcs",
        desc: form.desc.trim(), image: form.image, stock: form.stock === "" ? undefined : Math.round(Number(form.stock)),
        packs: form.packs.map((pk) => ({ label: pk.label.trim(), qty: Number(pk.qty) || 1, price: Number(pk.price) })),
        care: form.care ? { ...form.care } : null,
      });
    } else {
      if (form.price === "" || isNaN(Number(form.price)) || Number(form.price) < 0) return setError("Enter a valid price.");
      if (form.stock === "" || isNaN(Number(form.stock)) || Number(form.stock) < 0) return setError("Enter a valid stock count.");
      setError("");
      onSave({
        id: product?.id, name: form.name.trim(), category: form.category, unit: form.unit || "pcs",
        desc: form.desc.trim(), image: form.image, price: Number(form.price), stock: Math.round(Number(form.stock)), packs: null,
        care: form.care ? { ...form.care } : null,
      });
    }
  };

  return (
    <div style={{ maxWidth: 580, margin: "0 auto", padding: "36px 20px 80px" }}>
      <button onClick={onCancel} style={{
        background: "none", border: "none", color: "rgba(17,17,17,0.55)", fontFamily: "Inter, sans-serif", fontSize: 13,
        cursor: "pointer", display: "flex", alignItems: "center", gap: 6, marginBottom: 22, padding: 0,
      }}>
        <ChevronLeft size={15} /> BACK TO PRODUCTS
      </button>

      <h1 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: 30, color: COLORS.ink, marginBottom: 22, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.02em" }}>
        {product ? "EDIT PRODUCT" : "NEW PRODUCT"}
      </h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <Field label="Photo">
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{
              width: 72, height: 72, borderRadius: 3, background: form.image ? `url(${form.image}) center/cover` : "rgba(62,125,79,0.08)",
              display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
            }}>
              {!form.image && <Leaf size={18} color={COLORS.green} opacity={0.45} />}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <input ref={fileRef} type="file" accept="image/*" onChange={(e) => handleFile(e.target.files?.[0])} style={{ display: "none" }} />
              <button onClick={() => fileRef.current?.click()} disabled={uploading} style={{
                background: "rgba(17,17,17,0.05)", border: "1px solid rgba(17,17,17,0.15)", color: COLORS.ink, padding: "8px 14px",
                borderRadius: 3, fontFamily: "Inter, sans-serif", fontSize: 12.5, cursor: "pointer", display: "flex", alignItems: "center", gap: 7,
              }}>
                <Upload size={13} /> {uploading ? "Processing…" : form.image ? "Replace photo" : "Upload photo"}
              </button>
              {form.image && (
                <button onClick={() => setForm((f) => ({ ...f, image: "" }))} style={{ background: "none", border: "none", color: "rgba(17,17,17,0.4)", fontSize: 11.5, cursor: "pointer", fontFamily: "Inter, sans-serif", textAlign: "left", padding: 0 }}>
                  Remove photo
                </button>
              )}
            </div>
          </div>
        </Field>

        <Field label="Name"><input value={form.name} onChange={set("name")} placeholder="e.g. Powder Blue Isopods" style={inputStyle} /></Field>

        <Field label="Category">
          <select value={form.category} onChange={set("category")} style={{ ...inputStyle, cursor: "pointer" }}>
            {CATEGORIES.filter((c) => c !== "All").map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </Field>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(17,17,17,0.04)", borderRadius: 3, padding: "10px 13px" }}>
          <span style={{ fontFamily: "Inter, sans-serif", fontSize: 12.5, color: COLORS.ink }}>Use multiple pack/quantity options</span>
          <button onClick={togglePackMode} style={{
            background: form.packs ? COLORS.ink : "rgba(17,17,17,0.15)", border: "none", borderRadius: 999, width: 38, height: 20,
            position: "relative", cursor: "pointer",
          }}>
            <div style={{ width: 16, height: 16, borderRadius: 3, background: COLORS.white, position: "absolute", top: 2, left: form.packs ? 20 : 2, transition: "left 0.15s" }} />
          </button>
        </div>

        {form.packs ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {form.packs.map((pk, i) => (
              <div key={i} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input value={pk.label} onChange={(e) => updatePack(i, "label", e.target.value)} placeholder="Label e.g. 5 +1 free" style={{ ...inputStyle, flex: 2 }} />
                <input value={pk.qty} onChange={(e) => updatePack(i, "qty", e.target.value)} type="number" min="1" placeholder="Qty" style={{ ...inputStyle, flex: 1 }} />
                <input value={pk.price} onChange={(e) => updatePack(i, "price", e.target.value)} type="number" min="0" step="0.01" placeholder="RM" style={{ ...inputStyle, flex: 1 }} />
                <button onClick={() => removePack(i)} style={{ ...qtyBtnStyle, width: 30, height: 30, flexShrink: 0 }}><X size={12} /></button>
              </div>
            ))}
            <button onClick={addPack} style={{
              background: "none", border: "1px dashed rgba(17,17,17,0.25)", color: COLORS.ink, borderRadius: 3, padding: "8px 0",
              fontFamily: "Inter, sans-serif", fontSize: 12.5, cursor: "pointer",
            }}>
              + Add pack option
            </button>
            <Field label="Stock (optional, total individual units)">
              <input value={form.stock} onChange={set("stock")} type="number" min="0" placeholder="Leave blank if untracked" style={inputStyle} />
            </Field>
          </div>
        ) : (
          <div style={{ display: "flex", gap: 12 }}>
            <Field label="Price (RM)" style={{ flex: 1 }}><input value={form.price} onChange={set("price")} type="number" min="0" step="0.01" placeholder="0.00" style={inputStyle} /></Field>
            <Field label="Stock" style={{ flex: 1 }}><input value={form.stock} onChange={set("stock")} type="number" min="0" step="1" placeholder="0" style={inputStyle} /></Field>
            <Field label="Unit" style={{ flex: 1 }}><input value={form.unit} onChange={set("unit")} placeholder="pcs / colony / pack" style={inputStyle} /></Field>
          </div>
        )}

        <Field label="Description">
          <textarea value={form.desc} onChange={set("desc")} rows={4} placeholder="Species name, care notes, what makes this worth getting…" style={{ ...inputStyle, resize: "vertical", fontFamily: "Inter, sans-serif" }} />
        </Field>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(62,125,79,0.06)", borderRadius: 3, padding: "10px 13px" }}>
          <span style={{ fontFamily: "Inter, sans-serif", fontSize: 12.5, color: COLORS.ink }}>Include care guide</span>
          <button onClick={() => setForm(f => ({ ...f, care: f.care ? null : { ...EMPTY_CARE } }))} style={{
            background: form.care ? COLORS.ink : "rgba(17,17,17,0.15)", border: "none", borderRadius: 999, width: 38, height: 20,
            position: "relative", cursor: "pointer",
          }}>
            <div style={{ width: 16, height: 16, borderRadius: 3, background: COLORS.white, position: "absolute", top: 2, left: form.care ? 20 : 2, transition: "left 0.15s" }} />
          </button>
        </div>

        {form.care && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10, background: "rgba(62,125,79,0.04)", borderRadius: 3, padding: "14px 14px 10px" }}>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: COLORS.mid, textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 2, fontSize: 10, fontWeight: 700 }}>Care Details</div>
            {[
              { key: "temperature", label: "Temperature", placeholder: "e.g. 22–28 °C" },
              { key: "humidity", label: "Humidity", placeholder: "e.g. 70–80 %" },
              { key: "substrate", label: "Substrate", placeholder: "e.g. Coco fibre + leaf litter" },
              { key: "food", label: "Food", placeholder: "e.g. Leaf litter, calcium, decaying wood" },
            ].map(({ key, label, placeholder }) => (
              <Field key={key} label={label}>
                <input value={form.care[key]} onChange={e => setForm(f => ({ ...f, care: { ...f.care, [key]: e.target.value } }))} placeholder={placeholder} style={inputStyle} />
              </Field>
            ))}
            <Field label="Notes (optional)">
              <textarea value={form.care.notes} onChange={e => setForm(f => ({ ...f, care: { ...f.care, notes: e.target.value } }))} rows={3} placeholder="Extra tips, warnings, beginner-friendliness…" style={{ ...inputStyle, resize: "vertical", fontFamily: "Inter, sans-serif" }} />
            </Field>
          </div>
        )}

        {error && (
          <div style={{ display: "flex", alignItems: "center", gap: 7, color: COLORS.orange, fontSize: 12.5, fontFamily: "Inter, sans-serif" }}>
            <AlertCircle size={14} /> {error}
          </div>
        )}

        <button onClick={handleSubmit} style={{
          background: COLORS.orange, color: COLORS.white, border: "none", padding: "13px 0", borderRadius: 3,
          fontFamily: "Inter, sans-serif", fontSize: 14, fontWeight: 600, cursor: "pointer", marginTop: 6,
        }}>
          {product ? "SAVE CHANGES" : "ADD PRODUCT"}
        </button>
      </div>
    </div>
  );
}

function Field({ label, children, style }) {
  return (
    <div style={style}>
      <label style={{ display: "block", fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(17,17,17,0.5)", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.6 }}>
        {label}
      </label>
      {children}
    </div>
  );
}

// ---------- Root App ----------
export default function App() {
  const [page, setPage] = useState("home");
  const [products, setProducts] = useState(SEED_PRODUCTS);
  const [cart, setCart] = useState({});
  const [toast, setToast] = useState(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const result = 
(() => {
  const value = localStorage.getItem(STORAGE_KEY);
  return Promise.resolve(value ? { value } : null);
})()
;
        if (result && result.value) {
          const parsed = JSON.parse(result.value);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setProducts(parsed);
          } else {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_PRODUCTS));
          }
        } else {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_PRODUCTS));
        }
      } catch (e) {
        // storage unavailable — fall back to in-memory seed data
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  const saveProducts = useCallback(async (next) => {
    setProducts(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (e) {
      // ignore
    }
  }, []);

  const showToast = (msg) => setToast(msg);

  const addToCart = (product, packIndex) => {
    const key = product.packs ? `${product.id}::${packIndex}` : product.id;
    setCart((c) => {
      const existingQty = c[key]?.qty || 0;
      const stock = getBaseStock(product);
      if (existingQty >= stock) return c;
      return { ...c, [key]: { productId: product.id, packIndex: product.packs ? packIndex : undefined, qty: existingQty + 1 } };
    });
    const label = product.packs ? `${product.name} (${product.packs[packIndex].label})` : product.name;
    showToast(`Added ${label}`);
  };

  const updateQty = (key, qty) => {
    setCart((c) => {
      if (qty <= 0) {
        const next = { ...c };
        delete next[key];
        return next;
      }
      const entry = c[key];
      const product = products.find((p) => p.id === entry.productId);
      const stock = product ? getBaseStock(product) : qty;
      return { ...c, [key]: { ...entry, qty: Math.min(qty, stock) } };
    });
  };

  const removeFromCart = (key) => {
    setCart((c) => {
      const next = { ...c };
      delete next[key];
      return next;
    });
  };

  const cartCount = Object.values(cart).reduce((sum, c) => sum + c.qty, 0);

  return (
    <div style={{ minHeight: "100vh", background: "#E8E8E6", fontFamily: "Inter, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; }
        button:focus-visible, input:focus-visible, textarea:focus-visible, select:focus-visible {
          outline: 2px solid ${COLORS.green};
          outline-offset: 2px;
        }
        ::placeholder { color: rgba(17,17,17,0.32); }
        h1, h2, h3, button, .brand-label { letter-spacing: 0.06em; }
        @media (prefers-reduced-motion: reduce) {
          * { transition: none !important; animation: none !important; }
        }
      `}</style>

      <NavBar page={page} setPage={setPage} cartCount={cartCount} />

      {!loaded ? (
        <div style={{ padding: 80, textAlign: "center", color: "rgba(17,17,17,0.4)", fontFamily: "Inter, sans-serif", fontSize: 13 }}>Loading…</div>
      ) : (
        <>
          {page === "home" && <HomePage setPage={setPage} products={products} />}
          {page === "shop" && <ShopPage products={products} cart={cart} addToCart={addToCart} />}
          {page === "cart" && <CartPage cart={cart} products={products} updateQty={updateQty} removeFromCart={removeFromCart} setPage={setPage} />}
          {page === "about" && <AboutPage />}
          {page === "admin" && <AdminPage products={products} saveProducts={saveProducts} showToast={showToast} />}
        </>
      )}

      <footer style={{ borderTop: "1px solid rgba(17,17,17,0.08)", padding: "26px 20px", textAlign: "center", fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(17,17,17,0.4)" }}>
        {COMPANY_NAME.toUpperCase()} · REG. {REG_NO}
      </footer>

      {toast && <Toast message={toast} onDone={() => setToast(null)} />}
    </div>
  );
}
